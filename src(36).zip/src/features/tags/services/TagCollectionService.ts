import { supabase } from '@/lib/supabaseClient'

export async function loadCollectedTags(): Promise<string[]> {
  const { data, error } = await supabase
    .from('tag_collections')
    .select('tags')
    .single()

  if (error) {
    if (error.code === 'PGRST116') return [] // 找不到資料時
    console.error('讀取收藏失敗:', error)
    return []
  }

  return data.tags || []
}

export async function saveCollectedTags(tags: string[]): Promise<void> {
  const { error } = await supabase.from('tag_collections').upsert([
    { tags }
  ])
  if (error) console.error('儲存收藏失敗:', error)
}
