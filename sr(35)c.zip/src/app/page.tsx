'use client'

import { useEffect, useState } from 'react'
import dynamic from 'next/dynamic'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { Fragment } from '@/features/fragments/types/fragment'
import { useTagDragManager } from '@/features/fragments/layout/useTagDragManager'
import { useDrawerWidth } from '@/features/windows/useDrawerWidth'

// 動態導入元件
const FloatingFragmentsField = dynamic(() => import('@/features/fragments/FloatingFragmentsField'), { ssr: false })
const FragmentDetailModal = dynamic(() => import('@/features/fragments/components/FragmentDetailModal'), { ssr: false })
const FloatingActionButton = dynamic(() => import('@/features/fragments/components/FloatingActionButton'), { ssr: false })
const FragmentsView = dynamic(() => import('@/features/fragments/FragmentsView'), { ssr: false })

// 書籤式 UI 元件
const BookmarkBar = dynamic(() => import('@/features/windows/BookmarkBar'), { ssr: false })
const TagsDrawer = dynamic(() => import('@/features/tags/components/TagsDrawer'), { ssr: false })
const FloatingInputBar = dynamic(() => import('@/features/input/FloatingInputBar'), { ssr: false })

// 標籤拖曳相關組件
const TagDragPreview = dynamic(() => import('@/features/fragments/components/TagDragPreview'), { ssr: false })
const DragToDeleteZone = dynamic(() => import('@/features/tags/components/DragToDeleteZone'), { ssr: false })

export default function Home() {
  // 模式狀態
  const [currentMode, setCurrentMode] = useState('float')
  const [fragment, setFragment] = useState<Fragment | null>(null)

  // 書籤式 UI 狀態
  const [isTagsDrawerOpen, setIsTagsDrawerOpen] = useState(false)
  const [isInputBarOpen, setIsInputBarOpen] = useState(false)
  const [hasInputDraft, setHasInputDraft] = useState(false)

  // 標籤拖曳管理器
  const { draggingTag, dragPosition, isDragging } = useTagDragManager()
  
  // 抽屜寬度控制
  const { width: drawerWidth, startDrag: startDrawerDrag } = useDrawerWidth({
    defaultWidth: 350,
    minWidth: 280,
    maxWidth: typeof window !== 'undefined' ? window.innerWidth * 0.5 : 500,
    storageKey: 'tags-drawer-width'
  })
  
  // 使用 store
  const { mode, load } = useFragmentsStore()

  // 檢查是否有草稿
  useEffect(() => {
    const checkDraft = () => {
      const draft = localStorage.getItem('murverse_draft')
      if (draft) {
        try {
          const parsed = JSON.parse(draft)
          const hasDraft = !!(parsed.content || parsed.tags?.length || parsed.notes?.length)
          setHasInputDraft(hasDraft)
        } catch {
          setHasInputDraft(false)
        }
      } else {
        setHasInputDraft(false)
      }
    }

    checkDraft()
    
    // 定期檢查草稿狀態
    const interval = setInterval(checkDraft, 1000)
    return () => clearInterval(interval)
  }, [])

  // 設定關閉函數
  const handleClose = () => {
    setFragment(null)
  }

  // 標籤抽屜切換
  const handleTagsToggle = () => {
    setIsTagsDrawerOpen(!isTagsDrawerOpen)
  }

  // 新增碎片窗口切換
  const handleInputToggle = () => {
    setIsInputBarOpen(!isInputBarOpen)
  }

  // 自動打開標籤抽屜（當新增碎片需要選擇標籤時）
  const handleOpenTagsFromInput = () => {
    setIsTagsDrawerOpen(true)
  }

  // 關閉新增碎片窗口
  const handleCloseInputBar = () => {
    setIsInputBarOpen(false)
  }

  // 關閉標籤抽屜
  const handleCloseTagsDrawer = () => {
    setIsTagsDrawerOpen(false)
  }

  useEffect(() => {
    load()
    setCurrentMode(mode)
    
    const unsubscribe = useFragmentsStore.subscribe(
      state => setCurrentMode(state.mode)
    )
    
    return () => {
      if (typeof unsubscribe === 'function') {
        unsubscribe()
      }
    }
  }, [load, mode])
  
  if (typeof window === 'undefined') {
    return <div>Loading...</div>
  }
  
  return (
    <>
      {/* 書籤欄 */}
      <BookmarkBar
        isTagsDrawerOpen={isTagsDrawerOpen}
        isInputBarOpen={isInputBarOpen}
        hasInputDraft={hasInputDraft}
        onTagsToggle={handleTagsToggle}
        onInputToggle={handleInputToggle}
        onTagsWidthDrag={startDrawerDrag}
      />

      {/* 標籤管理抽屜 */}
      <TagsDrawer
        isOpen={isTagsDrawerOpen}
        width={drawerWidth}
        onClose={handleCloseTagsDrawer}
      />

      {/* 主要內容區域 */}
      <div 
        className="transition-all duration-300"
        style={{ 
          marginLeft: isTagsDrawerOpen ? `${drawerWidth}px` : '56px',
          minHeight: '100vh'
        }}
      >
        {/* 背景漂浮場 */}
        {currentMode === 'float' && (
          <FloatingFragmentsField />
        )}

        {/* 清單模式 */}
        {currentMode === 'list' && (
          <FragmentsView />
        )}

        {/* 右下角切換按鈕 */}
        <FloatingActionButton />
      </div>

      {/* 新增碎片浮動窗口 */}
      <FloatingInputBar
        isOpen={isInputBarOpen}
        onClose={handleCloseInputBar}
        onOpenTags={handleOpenTagsFromInput}
      />

      {/* 詳情Modal */}
      <FragmentDetailModal fragment={fragment} onClose={handleClose} />
      
      {/* 標籤拖曳預覽 */}
      {isDragging && draggingTag && dragPosition && (
        <TagDragPreview tag={draggingTag} position={dragPosition} />
      )}
      
      {/* 標籤刪除區域 */}
      <DragToDeleteZone position="bottom-right" />
      
      {/* 全局樣式 */}
      <style jsx global>{`
        /* 拖曳目標高亮樣式 */
        .fragment-card.tag-drop-target {
          box-shadow: 0 0 0 2px rgba(201, 155, 53, 0.7) !important;
          transform: scale(1.02) !important;
          transition: all 0.2s ease !important;
        }
        
        /* 直排標籤文字修正 */
        .tag-button[style*="writing-mode: vertical-rl"] {
          white-space: normal !important;
          overflow: hidden !important;
          word-break: break-all !important;
          line-height: 1.2 !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          text-align: center !important;
        }
        
        /* 書籤文字樣式 */
        .bookmark-text {
          writing-mode: vertical-rl;
          text-orientation: mixed;
          white-space: nowrap;
        }
        
        /* 連線動畫 */
        .animate-draw {
          stroke-dasharray: 1000;
          stroke-dashoffset: 1000;
          animation: draw 0.5s ease-in-out forwards;
        }
        
        @keyframes draw {
          to {
            stroke-dashoffset: 0;
          }
        }
        
        /* 抽屜過渡動畫 */
        .drawer-transition {
          transition: transform 0.3s ease-in-out;
        }
        
        /* 書籤按鈕 hover 效果 */
        .bookmark-button:hover {
          transform: translateX(2px);
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
      `}</style>
    </>
  )
}