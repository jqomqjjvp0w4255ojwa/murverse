'use client'

import { useState, useEffect, useRef, forwardRef } from 'react'
import { useFragmentsStore } from '../../fragments/store/useFragmentsStore'
import { useGlobalTagsStore } from '../store/useGlobalTagsStore'

interface TagsDrawerProps {
  isOpen: boolean
  width: number
  onClose: () => void
}

type TagInfo = { name: string; count: number }

const TagsDrawer = forwardRef<HTMLDivElement, TagsDrawerProps>(({ isOpen, width, onClose }, ref) => {
  // Store 狀態
  const { 
    tagsWindowRef, 
    pendingTags, 
    setPendingTags, 
    addPendingTag, 
    removePendingTag,
    mode, 
    setMode
  } = useGlobalTagsStore()

  const { 
    fragments, 
    setFragments, 
    save, 
    selectedTags, 
    setSelectedTags, 
    excludedTags, 
    setExcludedTags, 
    tagLogicMode, 
    setTagLogicMode 
  } = useFragmentsStore()

  // 本地狀態
  const [search, setSearch] = useState('')
  const [allTags, setAllTags] = useState<TagInfo[]>([])
  const [onlyShowSel, setOnlyShowSel] = useState(false)
  const [sortMode, setSortMode] = useState<string>('desc_freq')
  const [searchMode, setSearchMode] = useState<'tag' | 'fragment'>('tag')
  const [editMode, setEditMode] = useState(false)
  const [selectedTagsToDelete, setSelectedTagsToDelete] = useState<string[]>([])
  const [editingTag, setEditingTag] = useState<string | null>(null)
  const [editValue, setEditValue] = useState('')

  const tagListRef = useRef<HTMLDivElement>(null)

  // 組合 ref
  const combinedRef = (node: HTMLDivElement | null) => {
    tagsWindowRef.current = node
    if (ref) {
      if (typeof ref === 'function') {
        ref(node)
      } else {
        ref.current = node
      }
    }
  }

  // 初始化標籤列表
  useEffect(() => {
    const map = new Map<string, number>()
    fragments.forEach((f: any) => f.tags.forEach((t: string) => map.set(t, (map.get(t) || 0) + 1)))
    const extra = JSON.parse(localStorage.getItem('mur_tags_global') || '[]') as string[]
    extra.forEach(t => map.set(t, map.get(t) || 0))
    setAllTags([...map.entries()].map(([name, count]) => ({ name, count })))
  }, [fragments])

  // 初始化模式
  useEffect(() => { 
    setMode('search') 
  }, [setMode])

  // 添加標籤
  const handleAddTag = () => {
    const raw = search.trim()
    if (!raw) return

    const clean = raw.replace(/^#/, '')
        
    if (!allTags.some(tag => tag.name === clean)) {
      setAllTags([...allTags, { name: clean, count: 1 }])
    }
    const stored = JSON.parse(localStorage.getItem('mur_tags_global') || '[]') as string[]
    if (!stored.includes(clean)) {
      localStorage.setItem('mur_tags_global', JSON.stringify([...stored, clean]))
    }
  
    if (mode === 'add') {
      addPendingTag(clean)
    }
  
    setSearch('')
  }

  // 選擇標籤
  const handleTagSelect = (t: string) => {
    if (editMode) return
  
    if (mode === 'add') {
      pendingTags.includes(t) ? removePendingTag(t) : addPendingTag(t)
    } else {
      const newSelected = selectedTags.includes(t)
        ? selectedTags.filter((k: string) => k !== t)
        : [...selectedTags, t]
      const newExcluded = excludedTags.filter((k: string) => k !== t)
  
      setSelectedTags(newSelected)
      setExcludedTags(newExcluded)
    }
  }

  // 排除標籤
  const handleTagExclude = (t: string) => {
    if (editMode || mode === 'add') return
  
    const newExcluded = excludedTags.includes(t)
      ? excludedTags.filter((k: string) => k !== t)
      : [...excludedTags, t]
    const newSelected = selectedTags.filter((k: string) => k !== t)
  
    setExcludedTags(newExcluded)
    setSelectedTags(newSelected)
  }

  // 重命名標籤
  const handleTagRename = (oldName: string, newName: string) => {
    newName = newName.trim()
    if (!newName || oldName === newName) {
      setEditingTag(null)
      return
    }
    
    if (allTags.some(tag => tag.name === newName && tag.name !== oldName)) {
      alert('標籤名稱已存在！')
      setEditingTag(null)
      return
    }
    
    setAllTags(allTags.map(tag => 
      tag.name === oldName ? { name: newName, count: tag.count } : tag
    ))

    const stored = JSON.parse(localStorage.getItem('mur_tags_global') || '[]') as string[]
    localStorage.setItem('mur_tags_global', JSON.stringify([
      ...stored.filter(t => t !== oldName),
      newName
    ]))

    if (mode === 'add') {
      if (pendingTags.includes(oldName)) {
        setPendingTags(pendingTags.map((t: string) => t === oldName ? newName : t))
      }
    } else {
      if (selectedTags.includes(oldName)) {
        setSelectedTags(selectedTags.map((t: string) => t === oldName ? newName : t))
      }
      if (excludedTags.includes(oldName)) {
        setExcludedTags(excludedTags.map((t: string) => t === oldName ? newName : t))
      }
    }

    const updatedFragments = fragments.map((fragment: any) => {
      if (fragment.tags.includes(oldName)) {
        return {
          ...fragment,
          tags: fragment.tags.map((t: string) => t === oldName ? newName : t),
          updatedAt: new Date().toISOString()
        }
      }
      return fragment
    })

    setFragments(updatedFragments)
    save()
    
    setEditingTag(null)
  }

  // 刪除選中的標籤
  const handleDeleteSelectedTags = () => {
    if (!selectedTagsToDelete.length || !confirm(`確定要刪除這 ${selectedTagsToDelete.length} 個標籤嗎？此操作無法撤銷。`)) return
    
    setAllTags(allTags.filter(tag => !selectedTagsToDelete.includes(tag.name)))
    
    const stored = JSON.parse(localStorage.getItem('mur_tags_global') || '[]') as string[]
    localStorage.setItem('mur_tags_global', JSON.stringify(
      stored.filter(t => !selectedTagsToDelete.includes(t))
    ))
    
    if (mode === 'add') {
      setPendingTags(pendingTags.filter((t: string) => !selectedTagsToDelete.includes(t)))
    } else {
      setSelectedTags(selectedTags.filter((t: string) => !selectedTagsToDelete.includes(t)))
      setExcludedTags(excludedTags.filter((t: string) => !selectedTagsToDelete.includes(t)))
    }
      
    const updatedFragments = fragments.map((fragment: any) => {
      if (fragment.tags.some((t: string) => selectedTagsToDelete.includes(t))) {
        return {
          ...fragment,
          tags: fragment.tags.filter((t: string) => !selectedTagsToDelete.includes(t)),
          updatedAt: new Date().toISOString()
        }
      }
      return fragment
    })
    
    setFragments(updatedFragments)
    save()
    
    setSelectedTagsToDelete([])
  }

  // 過濾並排序標籤
  const getShownTags = () => {
    return allTags
      .filter(t => {
        if (!search.trim()) return true
        return t.name.toLowerCase().includes(search.toLowerCase())
      })
      .filter(t => {
        if (editMode) return true
        return mode === 'add'
          ? true
          : (onlyShowSel ? selectedTags.includes(t.name) || excludedTags.includes(t.name) : true)
      })
      .sort((a, b) => {
        const baseMode = sortMode.replace('asc_', '').replace('desc_', '')
        const isDesc = sortMode.startsWith('desc_')
  
        if (baseMode === 'az') {
          return isDesc ? b.name.localeCompare(a.name) : a.name.localeCompare(b.name)
        } else if (baseMode === 'freq') {
          return isDesc ? b.count - a.count : a.count - b.count
        }
        return 0
      })
  }
  
  const shown = getShownTags()
  const isPos = (t: string) => mode === 'add' ? pendingTags.includes(t) : selectedTags.includes(t)
  const isNeg = (t: string) => mode === 'add' ? false : excludedTags.includes(t)

  if (!isOpen) return null

  return (
    <div
      ref={combinedRef}
      className="fixed left-0 top-0 h-full bg-white border-r border-gray-300 shadow-lg z-[20] overflow-hidden transition-all duration-300"
      style={{ 
        width: width,
        transform: isOpen ? 'translateX(0)' : 'translateX(-100%)'
      }}
    >
      <div className="h-full flex flex-col p-4 overflow-hidden">
        {/* 標題區 - 保留編輯和顯示功能，移除關閉按鈕 */}
        <div className="flex justify-between items-center mb-4 border-b border-gray-200 pb-3">
          <h3 className="text-lg font-bold text-gray-800">
            {editMode ? '✏️ 編輯標籤' : (mode === 'add' ? '✔️ 添加標籤' : '💬 搜尋碎片')}
          </h3>
          <div className="flex gap-2 items-center">
            {/* 編輯按鈕 */}
            <button
              onClick={() => setEditMode(!editMode)}
              className={`text-sm px-2 py-1 rounded ${editMode ? 'bg-blue-500 text-white' : 'text-gray-600 hover:text-black'}`}
              title={editMode ? "完成編輯" : "編輯標籤"}
            >
              {editMode ? '完成' : '✏️'}
            </button>

            {/* 過濾按鈕（顯示/隱藏已選標籤） */}
            {!editMode && (
              <button 
                onClick={() => setOnlyShowSel(!onlyShowSel)}
                className="text-sm text-gray-600 hover:text-black"
                title={onlyShowSel ? "顯示全部標籤" : "只顯示已選標籤"}
              >
                {onlyShowSel ? '👁️' : '🙈'}
              </button>
            )}
            
            {/* 移除關閉按鈕 - 改為點擊書籤收合 */}
          </div>
        </div>

        {/* 搜尋區域 */}
        <div className="mb-4 flex-shrink-0">
          <div className="flex gap-2">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="搜尋或添加標籤..."
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleAddTag()
                }
              }}
            />
            <button
              onClick={handleAddTag}
              className="px-3 py-2 bg-blue-500 text-white rounded-lg text-sm hover:bg-blue-600"
            >
              添加
            </button>
          </div>
          
          {/* 排序選擇 */}
          <div className="mt-2">
            <select
              value={sortMode}
              onChange={(e) => setSortMode(e.target.value)}
              className="text-xs px-2 py-1 border border-gray-300 rounded"
            >
              <option value="desc_freq">頻率↓</option>
              <option value="asc_freq">頻率↑</option>
              <option value="desc_az">字母↓</option>
              <option value="asc_az">字母↑</option>
            </select>
          </div>
        </div>

        {/* 編輯提示面板 */}
        {editMode && selectedTagsToDelete.length > 0 && (
          <div className="mb-4 flex-shrink-0 bg-red-50 border border-red-200 rounded-lg p-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-red-700">
                已選擇 {selectedTagsToDelete.length} 個標籤
              </span>
              <div className="flex gap-2">
                <button
                  onClick={handleDeleteSelectedTags}
                  className="text-xs px-2 py-1 bg-red-500 text-white rounded hover:bg-red-600"
                >
                  刪除
                </button>
                <button
                  onClick={() => setSelectedTagsToDelete([])}
                  className="text-xs px-2 py-1 bg-gray-500 text-white rounded hover:bg-gray-600"
                >
                  取消
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 標籤列表 */}
        <div className="flex-1 overflow-y-auto" ref={tagListRef}>
          <div className="space-y-1">
            {shown.map((tag) => (
              <div
                key={tag.name}
                className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-2 flex-1">
                  {editMode && (
                    <input
                      type="checkbox"
                      checked={selectedTagsToDelete.includes(tag.name)}
                      onChange={() => {
                        setSelectedTagsToDelete(prev => 
                          prev.includes(tag.name) 
                            ? prev.filter(t => t !== tag.name) 
                            : [...prev, tag.name]
                        )
                      }}
                      className="w-4 h-4"
                    />
                  )}
                  
                  {editingTag === tag.name ? (
                    <input
                      type="text"
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleTagRename(tag.name, editValue)
                        } else if (e.key === 'Escape') {
                          setEditingTag(null)
                        }
                      }}
                      onBlur={() => handleTagRename(tag.name, editValue)}
                      className="flex-1 px-2 py-1 border border-gray-300 rounded text-sm"
                      autoFocus
                    />
                  ) : (
                    <button
                      onClick={() => {
                        if (editMode) {
                          setEditingTag(tag.name)
                          setEditValue(tag.name)
                        } else {
                          handleTagSelect(tag.name)
                        }
                      }}
                      onContextMenu={(e) => {
                        if (!editMode && mode !== 'add') {
                          e.preventDefault()
                          handleTagExclude(tag.name)
                        }
                      }}
                      className={`
                        flex-1 text-left px-2 py-1 rounded text-sm transition-colors
                        ${isPos(tag.name) ? 'bg-blue-100 text-blue-800' : ''}
                        ${isNeg(tag.name) ? 'bg-red-100 text-red-800' : ''}
                        ${!isPos(tag.name) && !isNeg(tag.name) ? 'hover:bg-gray-100' : ''}
                      `}
                    >
                      {tag.name}
                    </button>
                  )}
                </div>
                
                <span className="text-xs text-gray-500 ml-2">
                  {tag.count}
                </span>
              </div>
            ))}
          </div>
          
          {shown.length === 0 && (
            <div className="text-center text-gray-500 py-8">
              {search ? '找不到相關標籤' : '尚無標籤'}
            </div>
          )}
        </div>
      </div>
    </div>
  )
})

TagsDrawer.displayName = 'TagsDrawer'

export default TagsDrawer