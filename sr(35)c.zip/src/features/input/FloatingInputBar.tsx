'use client'

import { useState, useEffect, useRef } from 'react'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { useTagsIntegration } from '@/features/tags/store/useTagsIntegration'
import { useGlobalTagsStore } from '@/features/tags/store/useGlobalTagsStore'
import { Fragment, Note } from '@/features/fragments/types/fragment'
import { v4 as uuidv4 } from 'uuid'
import { useFloatingWindow } from '@/features/windows/useFloatingWindow'
import InputBarHeader from './InputBarHeader'
import NotesList from './NotesList'
import TagsSelector from '@/features/tags/components/TagsSelector'
import ActionButtons from './ActionButtons'

interface FloatingInputBarProps {
  isOpen: boolean
  onClose: () => void
  onOpenTags: () => void
}

// 三種顯示模式
type DisplayMode = 'fullscreen' | 'windowed' | 'collapsed'

export default function FloatingInputBar({ isOpen, onClose, onOpenTags }: FloatingInputBarProps) {
  // 顯示模式狀態
  const [displayMode, setDisplayMode] = useState<DisplayMode>('fullscreen')
  
  // 使用浮動窗口 hook（僅在小視窗模式時）
  const {
    windowRef: inputRef,
    pos,
    isCollapsed,
    isFullScreen,
    toggleCollapse,
    toggleFullScreen,
    handleMouseDown
  } = useFloatingWindow({
    id: 'floating-input-bar',
    defaultPosition: { 
      x: typeof window !== 'undefined' ? window.innerWidth / 2 - 200 : 200, 
      y: typeof window !== 'undefined' ? window.innerHeight / 4 : 100
    }
  })

  // 從 store 獲取狀態和方法
  const { fragments, setFragments, save } = useFragmentsStore()

  const { openTagSelector: enhancedOpenTagSelector } = useTagsIntegration()
  const {
    openTagSelector,
    pendingTags, setPendingTags, clearPendingTags,
    setMode, tagsWindowRef, setConnected,
    searchMode
  } = useGlobalTagsStore()

  // 本地狀態
  const [content, setContent] = useState('')
  const [notes, setNotes] = useState<Note[]>([])
  const [hydrated, setHydrated] = useState(false)
  const [showLine, setShowLine] = useState(false)
  const [linePath, setLinePath] = useState('')
  const [animateLine, setAnimateLine] = useState(false)
  const [isAnimatingClose, setIsAnimatingClose] = useState(false)
  
  const tagButtonRef = useRef<HTMLButtonElement>(null)
  const fragmentId = useRef<string>(uuidv4())
  const totalCharCount = content.length + notes.reduce((acc, note) => acc + note.title.length + note.value.length, 0)

  // 開啟時預設為全螢幕模式
  useEffect(() => {
    if (isOpen) {
      setDisplayMode('fullscreen')
    }
  }, [isOpen])

  // 在第一次渲染後初始化模式
  useEffect(() => { 
    setMode('search') 
  }, [setMode])

  // 讀取草稿
  useEffect(() => {
    const draft = localStorage.getItem('murverse_draft')
    if (draft) {
      const parsed = JSON.parse(draft)
      setContent(parsed.content || '')
      setPendingTags(parsed.tags || [])
      setNotes(parsed.notes || [])
    }
    setHydrated(true)
  }, [setPendingTags])

  // 初始化筆記
  useEffect(() => {
    if (isOpen && notes.length === 0) {
      setNotes([{ id: uuidv4(), title: '', value: '' }])
    }
  }, [isOpen, notes.length])

  // 自動保存草稿
  useEffect(() => {
    if (hydrated) {
      localStorage.setItem('murverse_draft', JSON.stringify({
        content, tags: pendingTags, notes,
      }))
    }
  }, [content, pendingTags, notes, hydrated])

  // 監聽點擊外部（僅在小視窗模式下生效）
  useEffect(() => {
    if (!isOpen || displayMode !== 'windowed') return

    const handleClickOutside = (e: MouseEvent) => {
      const inputEl = inputRef.current
      const tagsWindowEl = tagsWindowRef.current

      if (!inputEl || !tagsWindowEl) return

      if (!inputEl.contains(e.target as Node) && !tagsWindowEl.contains(e.target as Node)) {
        setShowLine(false)
        setConnected(false)
        setMode('search')
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [isOpen, displayMode, inputRef, tagsWindowRef, setConnected, setMode])

  // 監聽搜尋模式變化
  useEffect(() => {
    if (searchMode === 'fragment' && showLine) {
      console.log('InputBar 監聽到搜尋模式變為 fragment，斷開連線')
      setShowLine(false)
      setConnected(false)
    }
  }, [searchMode, showLine, setConnected])

  // 畫連線的邏輯和動畫
  useEffect(() => {
    if (showLine && isOpen) {
      const update = () => {
        const tagButton = tagButtonRef.current
        const tagsWindow = tagsWindowRef.current
        if (tagButton && tagsWindow) {
          const b = tagButton.getBoundingClientRect()
          const w = tagsWindow.getBoundingClientRect()
          const cx = (b.left + w.left) / 2
          const cy = (b.top + w.top) / 2
          const startX = b.left + b.width / 2
          const startY = b.top + b.height / 2
          const endX = w.left + w.width / 2
          const endY = w.top + w.height / 2

          setLinePath(
            `M${startX} ${startY}
             C${cx} ${cy} ${cx} ${cy}
             ${endX} ${endY}`
          )
        }
      }

      update()
      const interval = setInterval(update, 16)

      return () => clearInterval(interval)
    }
  }, [showLine, isOpen, tagsWindowRef])

  // 提交新碎片
  const handleSubmit = () => {
    if (!content.trim()) return
    const now = new Date().toISOString()
    
    const filteredNotes = notes.filter(note => 
      note.title.trim() !== '' || note.value.trim() !== ''
    )
    
    const notesToSave = filteredNotes.length > 0 ? filteredNotes : []
  
    const newFragment: Fragment = {
      id: fragmentId.current,
      content,
      type: 'fragment',
      tags: pendingTags,
      notes: notesToSave,
      createdAt: now,
      updatedAt: now,
    }
  
    setFragments([newFragment, ...fragments])
    save()
    resetInput()
    
    fragmentId.current = uuidv4()
  }

  // 清空全部
  const handleClear = () => {
    resetInput()
  }

  // 新增筆記
  const addNote = () => {
    setNotes(prev => [...prev, { id: uuidv4(), title: '', value: '' }])
  }

  // 更新單行筆記
  const updateNote = (id: string, field: 'title' | 'value', value: string) => {
    setNotes(prev => prev.map(note =>
      note.id === id ? { ...note, [field]: value } : note
    ))
  }

  // 刪除筆記
  const deleteNote = (id: string) => {
    setNotes(prev => prev.filter(note => note.id !== id))
  }

  // 處理筆記排序
  const handleReorderNotes = (newNotes: Note[]) => {
    setNotes(newNotes)
  }

  // 重置輸入欄
  const resetInput = () => {
    setContent('')
    clearPendingTags()
    setNotes([{ id: uuidv4(), title: '', value: '' }])
    setShowLine(false)
    setConnected(false)
    localStorage.removeItem('murverse_draft')
  }

  // 處理收合（飄回書籤）
  const handleCollapse = () => {
    setIsAnimatingClose(true)
    setShowLine(false)
    setConnected(false)
    
    // 動畫完成後真正關閉
    setTimeout(() => {
      setIsAnimatingClose(false)
      setDisplayMode('collapsed')
      onClose()
    }, 300)
  }

  // 切換為小視窗模式
  const handleSwitchToWindowed = () => {
    setDisplayMode('windowed')
  }

  // 切換為全螢幕模式
  const handleSwitchToFullscreen = () => {
    setDisplayMode('fullscreen')
  }

  // 畫連線到標籤窗口
  const handleOpenTagsWindow = (e: React.MouseEvent) => {
    e.stopPropagation()
    console.log('使用增強版開啟標籤選擇器')
    
    if (searchMode === 'fragment') {
      console.log('當前為碎片搜尋模式，需要先切換回標籤模式')
    }
    
    // 自動打開標籤抽屜
    onOpenTags()
    
    enhancedOpenTagSelector()
    
    setTimeout(() => {
      setMode('add')
      
      setTimeout(() => {
        requestAnimationFrame(() => {
          const tagButton = tagButtonRef.current
          const tagsWindow = tagsWindowRef.current
          if (tagButton && tagsWindow) {
            const b = tagButton.getBoundingClientRect()
            const w = tagsWindow.getBoundingClientRect()
            const cx = (b.left + w.left) / 2
            const cy = (b.top + w.top) / 2
            setLinePath(
              `M${b.left + b.width / 2} ${b.top + b.height / 2}
               C${cx} ${cy} ${cx} ${cy}
               ${w.left + w.width / 2} ${w.top + w.height / 2}`
            )
            
            setTimeout(() => {
              window.dispatchEvent(new Event('resize'))
            }, 100)
               
            setShowLine(true)
            setConnected(true)
            setAnimateLine(true)
            setTimeout(() => setAnimateLine(false), 500)
          }
        })
      }, 100)
    }, 50)
  }

  // 移除標籤
  const removeTag = (tagToRemove: string) => {
    setPendingTags(pendingTags.filter(tag => tag !== tagToRemove))
  }

  if (!hydrated || !isOpen) return null

  // 根據顯示模式渲染不同的樣式
  const renderContent = () => (
    <div className="space-y-4">
      {/* 頂部控制區 */}
      <div className="flex justify-between items-center mb-2">
        <div className="text-sm font-medium text-gray-700 flex items-center gap-2">
          <span>📝</span>
          <span>新增碎片</span>
        </div>
        <div className="flex items-center gap-2">
          {/* 收合按鈕（飄回書籤） */}
          <button
            onClick={handleCollapse}
            className="w-6 h-6 flex items-center justify-center rounded-full text-gray-500 hover:bg-gray-100 transition-colors"
            title="收合到書籤"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 12h18M12 3l-9 9 9 9"/>
            </svg>
          </button>
          
          {/* 視窗模式切換按鈕 */}
          {displayMode === 'fullscreen' ? (
            <button
              onClick={handleSwitchToWindowed}
              className="w-6 h-6 flex items-center justify-center rounded-full text-gray-500 hover:bg-gray-100 transition-colors"
              title="切換為小視窗"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M8 3v3a2 2 0 0 1-2 2H3"></path>
                <path d="M21 8h-3a2 2 0 0 1-2-2V3"></path>
                <path d="M3 16h3a2 2 0 0 1 2 2v3"></path>
                <path d="M16 21v-3a2 2 0 0 1 2-2h3"></path>
              </svg>
            </button>
          ) : (
            <button
              onClick={handleSwitchToFullscreen}
              className="w-6 h-6 flex items-center justify-center rounded-full text-gray-500 hover:bg-gray-100 transition-colors"
              title="切換為全螢幕"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="15 3 21 3 21 9"></polyline>
                <polyline points="9 21 3 21 3 15"></polyline>
                <line x1="21" y1="3" x2="14" y2="10"></line>
                <line x1="3" y1="21" x2="10" y2="14"></line>
              </svg>
            </button>
          )}
        </div>
      </div>

      {/* 主要輸入區 */}
      <div className="flex items-center gap-2">
        <input
          className="flex-1 p-2 border border-gray-300 rounded-lg"
          placeholder="碎片內容..."
          value={content}
          onChange={e => setContent(e.target.value)}
        />
      </div>

      {/* 標籤區 */}
      <TagsSelector 
        tags={pendingTags}
        tagButtonRef={tagButtonRef}
        onOpenTagsWindow={handleOpenTagsWindow}
        onRemoveTag={removeTag}
      />

      {/* 筆記列表 */}
      <NotesList 
        notes={notes}
        isFullScreen={displayMode === 'fullscreen'}
        onUpdateNote={updateNote}
        onDeleteNote={deleteNote}
        onReorderNotes={handleReorderNotes}
        onAddNote={addNote}
      />

      {/* 操作按鈕 */}
      <ActionButtons 
        isFullScreen={displayMode === 'fullscreen'}
        totalCharCount={totalCharCount}
        clearDragActive={false}
        clearButtonRef={null}
        onSubmit={handleSubmit}
        onClear={handleClear}
        onClearDragStart={() => {}}
        onClearDragEnd={() => {}}
      />
    </div>
  )
  
  return (
    <>
      {/* 標籤連線線條 */}
      {showLine && (
        <svg
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100vw',
            height: '100vh',
            pointerEvents: 'none',
            zIndex: 1,
          }}
        >
          <path
            d={linePath}
            stroke="black"
            strokeWidth={2}
            fill="none"
            className={animateLine ? 'animate-draw' : ''}
          />
        </svg>
      )}
      
      {/* 根據顯示模式渲染不同容器 */}
      {displayMode === 'fullscreen' ? (
        /* 全螢幕模式 - 高度100%，置中，寬度維持現狀 */
        <div
          id="floating-input-bar-fullscreen"
          className={`
            fixed inset-0 z-[20] bg-white shadow-lg select-none
            ${isAnimatingClose ? 'animate-slide-to-bookmark' : ''}
            flex items-center justify-center
          `}
        >
          <div 
            className="w-full max-w-2xl h-full overflow-y-auto p-6"
            style={{ maxHeight: '100vh' }}
          >
            {renderContent()}
          </div>
        </div>
      ) : displayMode === 'windowed' ? (
        /* 小視窗模式 - 可拖曳的浮動窗口 */
        <div
          id="floating-input-bar-windowed"
          ref={inputRef}
          onMouseDown={handleMouseDown}
          onDragStart={e => e.preventDefault()}
          className={`
            fixed z-[20] bg-white border border-gray-400 rounded-2xl shadow-lg select-none p-4
            ${isAnimatingClose ? 'animate-slide-to-bookmark' : ''}
          `}
          style={{
            top: pos.y,
            left: pos.x,
            width: '400px',
            height: 'auto',
            transition: isAnimatingClose ? 'all 0.3s ease-in-out' : 'width 0.3s, height 0.3s'
          }}
        >
          {renderContent()}
        </div>
      ) : null}
      
      {/* 自定義動畫樣式 */}
      <style jsx>{`
        @keyframes slideToBookmark {
          to {
            transform: translateX(-100vw) scale(0.1);
            opacity: 0;
          }
        }
        
        .animate-slide-to-bookmark {
          animation: slideToBookmark 0.3s ease-in-out forwards;
        }
      `}</style>
    </>
  )
}