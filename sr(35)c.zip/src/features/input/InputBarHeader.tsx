'use client'

import React from 'react'

interface InputBarHeaderProps {
  isFullScreen: boolean
  onCollapse: () => void
  onToggleFullScreen: () => void
}

export default function InputBarHeader({
  isFullScreen,
  onCollapse,
  onToggleFullScreen
}: InputBarHeaderProps) {
  return (
    <div className="flex justify-between items-center mb-2">
      <div className="text-sm font-medium text-gray-700 flex items-center gap-2">
        <span>📝</span>
        <span>新增碎片</span>
      </div>
      <div className="flex items-center gap-2">
        {/* 收合按鈕（改為飄回書籤） */}
        <button
          onClick={onCollapse}
          className="w-6 h-6 flex items-center justify-center rounded-full text-gray-500 hover:bg-gray-100 transition-colors"
          title="收合到書籤"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 12h18M12 3l-9 9 9 9"/>
          </svg>
        </button>
        
        {/* 全螢幕切換按鈕 */}
        <button
          onClick={onToggleFullScreen}
          className="w-6 h-6 flex items-center justify-center rounded-full text-gray-500 hover:bg-gray-100 transition-colors"
          title={isFullScreen ? "退出全螢幕" : "全螢幕模式"}
        >
          {isFullScreen ? (
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M8 3v3a2 2 0 0 1-2 2H3"></path>
              <path d="M21 8h-3a2 2 0 0 1-2-2V3"></path>
              <path d="M3 16h3a2 2 0 0 1 2 2v3"></path>
              <path d="M16 21v-3a2 2 0 0 1 2-2h3"></path>
            </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="15 3 21 3 21 9"></polyline>
              <polyline points="9 21 3 21 3 15"></polyline>
              <line x1="21" y1="3" x2="14" y2="10"></line>
              <line x1="3" y1="21" x2="10" y2="14"></line>
            </svg>
          )}
        </button>
      </div>
    </div>
  )
}