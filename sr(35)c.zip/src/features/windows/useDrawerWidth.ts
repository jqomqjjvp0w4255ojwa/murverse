'use client'

import { useState, useCallback, useRef, useEffect } from 'react'

interface UseDrawerWidthOptions {
  defaultWidth?: number
  minWidth?: number
  maxWidth?: number
  storageKey?: string
}

export function useDrawerWidth({
  defaultWidth = 320,
  minWidth = 280,
  maxWidth = 800,
  storageKey = 'drawer-width'
}: UseDrawerWidthOptions = {}) {
  const [width, setWidth] = useState(() => {
    if (typeof window === 'undefined') return defaultWidth
    const stored = localStorage.getItem(storageKey)
    const currentMaxWidth = window.innerWidth * 0.5
    return stored ? Math.min(Math.max(parseInt(stored), minWidth), currentMaxWidth) : defaultWidth
  })
  
  const [isDragging, setIsDragging] = useState(false)
  const dragStartX = useRef(0)
  const dragStartWidth = useRef(0)

  // 更新最大寬度（當視窗大小改變時）
  useEffect(() => {
    if (typeof window === 'undefined') return
    
    const handleResize = () => {
      const newMaxWidth = window.innerWidth * 0.5
      setWidth(prev => Math.min(prev, newMaxWidth))
    }
    
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  // 儲存寬度到 localStorage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(storageKey, width.toString())
    }
  }, [width, storageKey])

  const startDrag = useCallback((e: React.MouseEvent) => {
    e.preventDefault()
    setIsDragging(true)
    dragStartX.current = e.clientX
    dragStartWidth.current = width
  }, [width])

  useEffect(() => {
    if (!isDragging) return

    const handleMouseMove = (e: MouseEvent) => {
      const deltaX = e.clientX - dragStartX.current
      const newWidth = dragStartWidth.current + deltaX
      const currentMaxWidth = typeof window !== 'undefined' ? window.innerWidth * 0.5 : maxWidth
      
      setWidth(Math.min(Math.max(newWidth, minWidth), currentMaxWidth))
    }

    const handleMouseUp = () => {
      setIsDragging(false)
    }

    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseup', handleMouseUp)

    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isDragging, minWidth, maxWidth])

  return {
    width,
    isDragging,
    startDrag,
    setWidth
  }
}