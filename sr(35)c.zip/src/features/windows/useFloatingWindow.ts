'use client'

import React, { useRef, useState, useCallback, useEffect } from 'react'

interface Position {
  x: number
  y: number
}

interface UseFloatingWindowOptions {
  id: string
  defaultPosition: Position
}

export function useFloatingWindow({ id, defaultPosition }: UseFloatingWindowOptions) {
  const windowRef = useRef<HTMLDivElement>(null)
  const [pos, setPos] = useState<Position>(() => {
    if (typeof window === 'undefined') return defaultPosition
    
    // 嘗試從 localStorage 讀取位置
    const saved = localStorage.getItem(`floating-window-${id}`)
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        return { x: parsed.x || defaultPosition.x, y: parsed.y || defaultPosition.y }
      } catch {
        return defaultPosition
      }
    }
    return defaultPosition
  })
  
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [isFullScreen, setIsFullScreen] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  
  const dragOffset = useRef<Position>({ x: 0, y: 0 })
  const isDraggingRef = useRef(false)

  // 保存位置到 localStorage
  const savePosition = useCallback((position: Position) => {
    localStorage.setItem(`floating-window-${id}`, JSON.stringify(position))
  }, [id])

  // 開始拖曳
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (!windowRef.current || isDraggingRef.current) return
    
    // 檢查是否點擊在可拖曳區域（避免點擊按鈕時觸發拖曳）
    const target = e.target as HTMLElement
    if (target.tagName === 'BUTTON' || target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
      return
    }
    
    const rect = windowRef.current.getBoundingClientRect()
    dragOffset.current = { 
      x: e.clientX - rect.left, 
      y: e.clientY - rect.top 
    }
    
    isDraggingRef.current = true
    setIsDragging(true)
  }, [])

  // 切換收合狀態
  const toggleCollapse = useCallback(() => {
    setIsCollapsed(prev => !prev)
  }, [])

  // 切換全螢幕狀態
  const toggleFullScreen = useCallback(() => {
    setIsFullScreen(prev => !prev)
  }, [])

  // 處理滑鼠移動和釋放事件
  useEffect(() => {
    if (!isDragging) return

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current) return

      const newX = e.clientX - dragOffset.current.x
      const newY = e.clientY - dragOffset.current.y
      
      // 限制在視窗邊界內
      const maxX = window.innerWidth - (windowRef.current?.offsetWidth || 0)
      const maxY = window.innerHeight - (windowRef.current?.offsetHeight || 0)
      
      const boundedX = Math.max(0, Math.min(newX, maxX))
      const boundedY = Math.max(0, Math.min(newY, maxY))
      
      setPos({ x: boundedX, y: boundedY })
    }

    const handleMouseUp = () => {
      if (!isDraggingRef.current) return
      
      isDraggingRef.current = false
      setIsDragging(false)
      
      // 保存最終位置
      savePosition(pos)
    }

    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseup', handleMouseUp)
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isDragging, pos, savePosition])

  return {
    windowRef,
    pos,
    setPos,
    isCollapsed,
    isFullScreen,
    isDragging,
    toggleCollapse,
    toggleFullScreen,
    handleMouseDown
  }
}