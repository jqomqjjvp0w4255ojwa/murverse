'use client'

import { useState } from 'react'

interface BookmarkBarProps {
  isTagsDrawerOpen: boolean
  isInputBarOpen: boolean
  hasInputDraft: boolean
  onTagsToggle: () => void
  onInputToggle: () => void
  onTagsWidthDrag: (e: React.MouseEvent) => void
}

export default function BookmarkBar({
  isTagsDrawerOpen,
  isInputBarOpen,
  hasInputDraft,
  onTagsToggle,
  onInputToggle,
  onTagsWidthDrag
}: BookmarkBarProps) {
  const [hoveredBookmark, setHoveredBookmark] = useState<string | null>(null)

  return (
    <div className="fixed left-0 top-0 h-full z-[30] flex">
      {/* 書籤欄 - L形資料夾風格 */}
      <div className="relative">
        {/* 標籤管理書籤 - L形突出效果 */}
        <div
          className={`
            absolute top-16 left-0 cursor-pointer transition-all duration-200 group
            ${isTagsDrawerOpen ? 'translate-x-1' : 'translate-x-0'}
          `}
          onClick={onTagsToggle}
          onMouseEnter={() => setHoveredBookmark('tags')}
          onMouseLeave={() => setHoveredBookmark(null)}
          style={{
            background: isTagsDrawerOpen ? '#dbeafe' : '#f3f4f6',
            clipPath: 'polygon(0 0, 85% 0, 100% 15%, 100% 85%, 85% 100%, 0 100%)',
            width: '48px',
            height: '80px',
            borderRight: isTagsDrawerOpen ? '2px solid #3b82f6' : '1px solid #d1d5db',
            boxShadow: '2px 0 4px rgba(0,0,0,0.1)'
          }}
        >
          <div 
            className="h-full flex items-center justify-center text-gray-700 font-medium text-sm"
            style={{
              writingMode: 'vertical-rl',
              textOrientation: 'mixed',
              paddingRight: '8px'
            }}
          >
            標籤
          </div>
          
          {/* 拖曳手柄（僅在展開時顯示） */}
          {isTagsDrawerOpen && (
            <div
              className="absolute right-0 top-0 bottom-0 w-2 cursor-ew-resize bg-blue-200 opacity-0 group-hover:opacity-100 transition-opacity"
              onMouseDown={onTagsWidthDrag}
              onClick={(e) => e.stopPropagation()}
              style={{ transform: 'translateX(2px)' }}
            />
          )}
          
          {/* Tooltip */}
          {hoveredBookmark === 'tags' && (
            <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 bg-black text-white text-xs px-2 py-1 rounded whitespace-nowrap z-50">
              {isTagsDrawerOpen ? '收合標籤管理' : '展開標籤管理'}
            </div>
          )}
        </div>

        {/* 新增碎片書籤 - L形突出效果 */}
        <div
          className={`
            absolute top-40 left-0 cursor-pointer transition-all duration-200
            ${isInputBarOpen ? 'translate-x-1' : 'translate-x-0'}
          `}
          onClick={onInputToggle}
          onMouseEnter={() => setHoveredBookmark('input')}
          onMouseLeave={() => setHoveredBookmark(null)}
          style={{
            background: isInputBarOpen ? '#dcfce7' : '#f3f4f6',
            clipPath: 'polygon(0 0, 85% 0, 100% 15%, 100% 85%, 85% 100%, 0 100%)',
            width: '48px',
            height: '80px',
            borderRight: isInputBarOpen ? '2px solid #22c55e' : '1px solid #d1d5db',
            boxShadow: '2px 0 4px rgba(0,0,0,0.1)'
          }}
        >
          <div 
            className="h-full flex items-center justify-center text-gray-700 font-medium text-sm relative"
            style={{
              writingMode: 'vertical-rl',
              textOrientation: 'mixed',
              paddingRight: '8px'
            }}
          >
            新增
            {hasInputDraft && (
              <span 
                className="text-orange-500 absolute -right-1 top-2"
                style={{ writingMode: 'horizontal-tb' }}
              >
                ✏️
              </span>
            )}
          </div>
          
          {/* Tooltip */}
          {hoveredBookmark === 'input' && (
            <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 bg-black text-white text-xs px-2 py-1 rounded whitespace-nowrap z-50">
              {hasInputDraft ? '新增碎片（有草稿）' : '新增碎片'}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}