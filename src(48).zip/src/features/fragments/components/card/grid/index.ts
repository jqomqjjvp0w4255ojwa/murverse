// 📄 src/features/fragments/components/card/grid/index.ts

export { default as GridFragmentCard } from './GridFragmentCard'