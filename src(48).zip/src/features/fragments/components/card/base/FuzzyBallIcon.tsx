// 📄 src/features/fragments/components/card/base/FuzzyBallIcon.tsx

import React from 'react'

interface FuzzyBallIconProps {
  size?: number
  color?: string
  isHovered?: boolean
}

const FuzzyBallIcon: React.FC<FuzzyBallIconProps> = ({
  size = 16,
  color = '#d1b684',
  isHovered = false
}) => {
  const lineCount = 12
  const radius = size * 0.5
  const innerRadius = radius * 0.6 // 線條從這裡開始
  const outerRadius = radius       // 線條結束

  return (
    <div
      style={{
        width: `${size}px`,
        height: `${size}px`,
        position: 'relative',
        transform: isHovered ? 'scale(1.1)' : 'scale(1)',
        transition: 'transform 0.2s ease',
      }}
    >
      {/* 放射線條 */}
      {[...Array(lineCount)].map((_, i) => {
        const angle = (360 / lineCount) * i
        const length = outerRadius - innerRadius

        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              width: `${length}px`,
              height: '1px',
              backgroundColor: color,
              top: '50%',
              left: '50%',
              transformOrigin: `${-innerRadius}px 50%`,
              transform: `translate(${-innerRadius}px, -50%) rotate(${angle}deg)`,
              
            }}
          />
        )
      })}
    </div>
  )
}

export default FuzzyBallIcon
