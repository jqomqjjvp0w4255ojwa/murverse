// src/features/tags/store/useTagCollectionStore.ts
import { create } from 'zustand'

interface TagCollectionState {
  collectedTags: Set<string>
  addTag: (tag: string) => void
  removeTag: (tag: string) => void
  isCollected: (tag: string) => boolean
  clearAll: () => void
  getAllTags: () => string[]
}

export const useTagCollectionStore = create<TagCollectionState>((set, get) => ({
  collectedTags: new Set(),

  addTag: (tag) => {
    const updated = new Set(get().collectedTags)
    updated.add(tag)
    set({ collectedTags: updated })
  },

  removeTag: (tag) => {
    const updated = new Set(get().collectedTags)
    updated.delete(tag)
    set({ collectedTags: updated })
  },

  isCollected: (tag) => {
    return get().collectedTags.has(tag)
  },

  clearAll: () => {
    set({ collectedTags: new Set() })
  },

  getAllTags: () => {
    return Array.from(get().collectedTags)
  }
}))
