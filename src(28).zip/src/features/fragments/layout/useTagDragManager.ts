import { useState, useEffect, useCallback, useRef } from 'react'

const DRAG_THRESHOLD = 4 // 拖曳的最小位移像素才能觸發拖曳行為

export function useTagDragManager() {
  const [draggingTag, setDraggingTag] = useState<string | null>(null)
  const [dragPosition, setDragPosition] = useState<{ x: number; y: number } | null>(null)
  const isDraggingRef = useRef(false)
  const wasDraggingRef = useRef(false)

  const dragStartPos = useRef<{ x: number, y: number } | null>(null)

  // 觸發拖曳（從外部呼叫）
  const startTagDrag = useCallback((tag: string, e: React.MouseEvent) => {
    dragStartPos.current = { x: e.clientX, y: e.clientY }
    setDraggingTag(tag)
    setDragPosition({ x: e.clientX, y: e.clientY })
    // 暫不設定 isDraggingRef，等滑動超過門檻才開始拖曳
  }, [])

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!dragStartPos.current || !draggingTag) return

      const dx = e.clientX - dragStartPos.current.x
      const dy = e.clientY - dragStartPos.current.y
      const distance = Math.sqrt(dx * dx + dy * dy)

      if (!isDraggingRef.current && distance > DRAG_THRESHOLD) {
        isDraggingRef.current = true // 正式啟用拖曳
      }

      if (isDraggingRef.current) {
        setDragPosition({ x: e.clientX, y: e.clientY })
      }
    }

    const handleMouseUp = () => {
      if (isDraggingRef.current) {
        setDraggingTag(null)
        setDragPosition(null)
        isDraggingRef.current = false
        wasDraggingRef.current = true
        setTimeout(() => { wasDraggingRef.current = false }, 100)
      } else {
        // reset if not dragging
        setDraggingTag(null)
        setDragPosition(null)
        dragStartPos.current = null
      }
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)
    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [draggingTag])

  return {
    draggingTag,
    dragPosition,
    isDragging: isDraggingRef.current,
    wasDraggingRef,
    startTagDrag,
  }
}
