import React from 'react'

interface TagButtonProps {
  tag: string
  onTagClick?: (tag: string) => void
  onTagDragStart?: (e: React.MouseEvent, tag: string) => void
  style?: React.CSSProperties
}

const TagButton: React.FC<TagButtonProps> = ({
  tag,
  onTagClick,
  onTagDragStart,
  style = {},
}) => {
  return (
    <div
      className="tag-button"
      onClick={(e) => {
        e.stopPropagation()
        onTagClick?.(tag)
      }}
      onMouseDown={(e) => {
        e.preventDefault()
        e.stopPropagation()
        onTagDragStart?.(e, tag)
      }}
      style={{
        backgroundColor: '#f3e8c7',
        color: '#8d6a38',
        borderRadius: '12px',
        padding: '2px 6px',
        fontSize: '10px',
        whiteSpace: 'nowrap',
        cursor: 'grab',
        ...style,
      }}
    >
      {tag}
    </div>
  )
}

export default TagButton
