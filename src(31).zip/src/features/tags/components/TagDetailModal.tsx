'use client'

import React, { useEffect, useRef } from 'react'
import { Fragment } from '@/features/fragments/types/fragment'
import { useTagCollectionStore } from '@/features/tags/store/useTagCollectionStore'
import { TagsService } from '@/features/tags/services/TagsService'

interface TagDetailModalProps {
  tag: string
  relatedFragments: Fragment[]
  onClose: () => void
}

const TagDetailModal: React.FC<TagDetailModalProps> = ({
  tag,
  relatedFragments,
  onClose,
}) => {
  const modalRef = useRef<HTMLDivElement>(null)
  const { isCollected, addTag, removeTag } = useTagCollectionStore()
  const alreadyCollected = isCollected(tag)
  
  // 按 Escape 關閉
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }

    // 點擊外部關閉
    let lastClickTime = 0
    let clickCount = 0

    const handleClickOutside = (e: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
        const now = Date.now()
        if (now - lastClickTime < 300) {
          clickCount += 1
        } else {
          clickCount = 1
        }
        lastClickTime = now

        if (clickCount >= 2) {
          onClose()
        }
      }
    }

    document.addEventListener('keydown', handleEscape)
    document.addEventListener('mousedown', handleClickOutside)

    return () => {
      document.removeEventListener('keydown', handleEscape)
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [onClose])

  const formatDate = (dateString?: string) => {
    if (!dateString) return ''
    const date = new Date(dateString)
    return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日`
  }

  // 尋找相似標籤
  const similarTags = TagsService.findSimilarTagsByCooccurrence(tag, 5)

  return (
    
        <div 
          className="fixed inset-0 flex items-center justify-center z-[9999] p-4"
          style={{
            backgroundColor: 'rgba(0, 0, 0, 0.75)',
            backdropFilter: 'blur(4px)',
            WebkitBackdropFilter: 'blur(4px)',
            overflowY: 'auto',
          }}
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation(); // 阻止事件冒泡
          }}
        >
      <div
        ref={modalRef}
        className="bg-white rounded-2xl shadow-xl max-w-3xl w-full"
        style={{
          backgroundColor: '#fffdf7',
          border: '1px solid #e2e2e2',
          display: 'flex',
          flexDirection: 'column',
          maxHeight: '95vh',
          overflow: 'hidden',
          boxShadow: '0 10px 40px rgba(0, 0, 0, 0.3)',
          position: 'relative',
          zIndex: 10000, // 確保在所有元素上方
        }}

         onClick={(e) => {
        e.stopPropagation(); 
        }}

      >
        {/* 標題列 */}
        <div className="flex justify-between items-center px-6 py-4 border-b border-gray-200 sticky top-0 bg-[#fffdf7] z-10">
          <h3
            className="text-xl font-semibold text-gray-800 flex items-center"
            style={{
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              maxWidth: '80%',
            }}
          >
            <span className="mr-2" style={{ color: '#8d6a38' }}>🏷️</span>
            {tag}
          </h3>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (alreadyCollected) {
                  removeTag(tag)
                } else {
                  addTag(tag)
                }
              }}
              className="text-amber-600 hover:text-amber-700 flex items-center gap-1 px-3 py-1.5 rounded hover:bg-amber-50 transition-colors"
              style={{
                fontSize: '14px',
                border: alreadyCollected ? '1px solid #d4a748' : '1px dashed #d4a748',
              }}
            >
              <span>{alreadyCollected ? '⭐ 已收藏' : '☆ 收藏標籤'}</span>
            </button>
            <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation(); // 阻止事件冒泡
              onClose();
            }}
            className="text-gray-400 hover:text-gray-600 focus:outline-none"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
          </div>
        </div>

        {/* 內容區域 */}
        <div
          className="p-6 space-y-6 overflow-y-auto"
          style={{
            flex: 1,
            minHeight: 0,
          }}
        >
          {/* 標籤統計 */}
          <div className="bg-amber-50 rounded-lg p-4 flex flex-wrap gap-4">
            <div className="flex flex-col items-center justify-center bg-white rounded-lg p-3 shadow-sm min-w-[100px]">
              <div className="text-2xl font-bold text-amber-700">{relatedFragments.length}</div>
              <div className="text-xs text-gray-500">相關碎片</div>
            </div>
            
            <div className="flex flex-col items-center justify-center bg-white rounded-lg p-3 shadow-sm min-w-[100px]">
              <div className="text-2xl font-bold text-amber-700">
                {similarTags.length > 0 ? similarTags.length : 0}
              </div>
              <div className="text-xs text-gray-500">相似標籤</div>
            </div>
            
            <div className="flex flex-col items-center justify-center bg-white rounded-lg p-3 shadow-sm min-w-[100px]">
              <div className="text-2xl font-bold text-amber-700">
                {relatedFragments.length > 0 
                  ? new Date(relatedFragments[0].updatedAt).toLocaleDateString('zh-TW') 
                  : '-'}
              </div>
              <div className="text-xs text-gray-500">最近使用</div>
            </div>
          </div>

          {/* 相似標籤 */}
          {similarTags.length > 0 && (
            <div className="mb-6">
              <h4 className="text-base font-medium text-gray-700 mb-2">相似標籤</h4>
              <div className="flex flex-wrap gap-2">
                {similarTags.map(tag => (
                  <div
                    key={tag.name}
                    className="px-3 py-1.5 text-sm bg-amber-50 text-amber-700 rounded-lg flex items-center gap-1"
                  >
                    <span>{tag.name}</span>
                    <span className="text-xs bg-amber-100 px-1.5 py-0.5 rounded-full text-amber-800">
                      {tag.count}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 相關碎片列表 */}
          <div>
            <h4 className="text-base font-medium text-gray-700 mb-2 flex items-center gap-2">
              <span>相關碎片</span>
              <span className="text-xs bg-gray-100 px-2 py-0.5 rounded-full text-gray-600">
                {relatedFragments.length}
              </span>
            </h4>
            
            {relatedFragments.length > 0 ? (
              <div className="space-y-3">
                {relatedFragments.map((fragment) => (
                  <div 
                    key={fragment.id} 
                    className="bg-white rounded-lg border border-gray-100 shadow-sm p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="font-medium text-gray-800 mb-1 line-clamp-1">
                      {fragment.content.split('\n')[0]}
                    </div>
                    <div className="text-sm text-gray-600 line-clamp-2">
                      {fragment.content}
                    </div>
                    <div className="mt-2 flex gap-1 flex-wrap">
                      {fragment.tags.filter(t => t !== tag).slice(0, 5).map(t => (
                        <span 
                          key={t} 
                          className="inline-block px-2 py-0.5 text-xs bg-amber-50 text-amber-700 rounded"
                        >
                          {t}
                        </span>
                      ))}
                      {fragment.tags.length > 6 && (
                        <span className="inline-block px-2 py-0.5 text-xs bg-gray-100 text-gray-600 rounded">
                          +{fragment.tags.length - 6}
                        </span>
                      )}
                    </div>
                    <div className="mt-1 text-xs text-gray-400">
                      更新於: {formatDate(fragment.updatedAt)}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-gray-500 p-6 bg-gray-50 rounded-lg">
                沒有相關碎片
              </div>
            )}
          </div>
        </div>

        {/* 底部操作列 */}
        <div className="px-6 py-3 bg-gray-50 border-t border-gray-200 flex justify-between items-center">
          <div className="text-xs text-gray-500">
            雙擊背景關閉此視窗
          </div>
          <button
            onClick={() => {
              const isConfirmed = window.confirm(`確定要刪除標籤「${tag}」嗎？\n注意：將從所有碎片中移除此標籤。`);
              if (isConfirmed) {
                TagsService.deleteTag(tag);
                onClose();
              }
            }}
            className="text-red-600 hover:text-red-700 text-sm px-3 py-1 rounded hover:bg-red-50"
          >
            刪除標籤
          </button>
        </div>
      </div>
    </div>
  )
}

export default TagDetailModal