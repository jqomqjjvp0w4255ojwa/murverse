// src/app/page.tsx
'use client'

import { useEffect, useState } from 'react'
import dynamic from 'next/dynamic'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { Fragment } from '@/features/fragments/types/fragment'
import { useTagDragManager } from '@/features/fragments/layout/useTagDragManager'

// 動態導入組件
const TabManager = dynamic(() => import('@/features/windows/TabManager'), { ssr: false })
const DrawerTagsWindow = dynamic(() => import('@/features/tags/DrawerTagsWindow'), { ssr: false })

const FloatingFragmentsField = dynamic(() => import('@/features/fragments/FloatingFragmentsField'), { ssr: false })
const FragmentDetailModal = dynamic(() => import('@/features/fragments/components/FragmentDetailModal'), { ssr: false })
const FloatingInputBar = dynamic(() => import('@/features/input/FloatingInputBar'), { ssr: false })
const FloatingActionButton = dynamic(() => import('@/features/fragments/components/FloatingActionButton'), { ssr: false })
const GroupFrame = dynamic(() => import('@/features/windows/GroupFrame'), { ssr: false })
const FragmentsView = dynamic(() => import('@/features/fragments/FragmentsView'), { ssr: false })

// 標籤拖曳相關組件
const TagDragPreview = dynamic(() => import('@/features/fragments/components/TagDragPreview'), { ssr: false })
const DragToDeleteZone = dynamic(() => import('@/features/tags/components/DragToDeleteZone'), { ssr: false })

export default function Home() {
  // 初始設定空字串或預設值，避免服務器端渲染時的不匹配
  const [currentMode, setCurrentMode] = useState('float')
  const [fragment, setFragment] = useState<Fragment | null>(null)
  const [isClient, setIsClient] = useState(false) // ✅ 新增：客戶端狀態

  // 使用標籤拖曳管理器
  const { draggingTag, dragPosition, isDragging } = useTagDragManager()
  
  // 使用 store
  const { mode, load } = useFragmentsStore()

  // 設定關閉函數
  const handleClose = () => {
    setFragment(null)
  }

  // Tab 切換處理
  const handleTabToggle = (windowId: string, isActive: boolean) => {
    console.log(`Tab ${windowId} is now ${isActive ? 'active' : 'inactive'}`)
    // 可以在這裡添加額外的邏輯，比如記錄用戶行為等
  }

  // ✅ 修復：客戶端檢查
  useEffect(() => {
    setIsClient(true)
  }, [])

  useEffect(() => {
    // 確保只在客戶端執行
    if (!isClient) return
    
    load()
    // 同步 mode 到本地狀態
    setCurrentMode(mode)
    
    // 訂閱 mode 變化
    const unsubscribe = useFragmentsStore.subscribe(
      state => setCurrentMode(state.mode)
    )
    
    return () => {
      if (typeof unsubscribe === 'function') {
        unsubscribe()
      }
    }
  }, [isClient, load, mode]) // ✅ 添加 isClient 依賴
  
  // ✅ 修復：更好的載入狀態處理
  if (!isClient) {
    return (
      <div className="min-h-screen bg-[#f9f6e9] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto mb-4"></div>
          <p className="text-gray-600">載入中...</p>
        </div>
      </div>
    )
  }
  
  return (
    <>
      {/* Tab 管理器 - 包裝所有浮動窗口 */}
      {currentMode === 'float' && (
        <TabManager onTabToggle={handleTabToggle}>
          {/* 主內容區域 */}
          <div className="main-content-area">
            <FloatingFragmentsField />
          </div>
          
          {/* 浮動窗口 - 由 Tab 控制顯示 */}
          <FloatingInputBar />
          
          {/* 抽屜式標籤窗口 - 替代原有的浮動標籤窗口 */}
          <DrawerTagsWindow />
          
          {/* 群組框架 - 只管理浮動窗口，不包括抽屜 */}
          <GroupFrame />
        </TabManager>
      )}

      {/* 清單模式 - 保持原樣 */}
      {currentMode === 'list' && (
        <FragmentsView />
      )}

      {/* 公用組件 - 不受 Tab 影響 */}
      <FragmentDetailModal fragment={fragment} onClose={handleClose} />
      <FloatingActionButton />
      
      {/* 標籤拖曳預覽 - 在所有視圖模式下都顯示 */}
      {isDragging && draggingTag && dragPosition && (
        <TagDragPreview tag={draggingTag} position={dragPosition} />
      )}
      
      {/* 標籤刪除區域 - 只在拖曳標籤時顯示 */}
      <DragToDeleteZone position="bottom-right" />
      
      {/* 全局樣式 */}
      <style jsx global>{`
        /* 原有的拖曳目標高亮樣式 */
        .fragment-card.tag-drop-target {
          box-shadow: 0 0 0 2px rgba(201, 155, 53, 0.7) !important;
          transform: scale(1.02) !important;
          transition: all 0.2s ease !important;
        }
        
        /* 直排標籤文字修正 */
        .tag-button[style*="writing-mode: vertical-rl"] {
          white-space: normal !important;
          overflow: hidden !important;
          word-break: break-all !important;
          line-height: 1.2 !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          text-align: center !important;
        }
        
        /* 為 Tab 模式調整主內容區域 */
        .floating-fragments-container {
          transition: margin-left 0.5s ease;
        }
        
        /* 抽屜展開時為主內容留出空間 */
        .main-content-area {
          transition: margin-left 0.5s ease-out;
        }
      `}</style>
    </>
  )
}