// src/features/tags/DrawerTagsWindow.tsx
'use client'

import { useState, useEffect, useRef, forwardRef } from 'react'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { useGlobalTagsStore } from '@/features/tags/store/useGlobalTagsStore'
import { useAdvancedSearch } from '@/features/search/useAdvancedSearch'
import { useSearchStore } from '@/features/search/useSearchStore'
import { useTagDragManager } from '@/features/fragments/layout/useTagDragManager'
import { useTagCollectionStore } from '@/features/tags/store/useTagCollectionStore'
import { useSingleUserTagSync } from '@/shared/hook/useSingleUserTagSync'
import React from 'react'

// 引入原有組件
import TagsSearchBar from './components/TagsSearchBar'
import MetaTagsSelector from './components/MetaTagsSelector'
import TagLogicToggle from './components/TagLogicToggle'
import EditTagsPanel from './components/EditTagsPanel'
import TagsList from './components/TagsList'
import AdvancedSearchPanel from '../search/AdvancedSearchPanel'

// 引入特殊標籤服務和常量
import { DEFAULT_META_TAGS, MetaTag } from '@/features/tags/constants/metaTags'
import { MetaTagsService } from '@/features/tags/services/MetaTagsService'
import { SearchService } from '@/features/search/SearchService'
import { SYSTEM_TAGS, isSystemTag } from '@/features/tags/constants/systemTags'

// 定義 TagInfo 類型
type TagInfo = { name: string; count: number }

const DrawerTagsWindow = forwardRef<HTMLDivElement>((props, ref) => {
  // 抽屜狀態
  const [isOpen, setIsOpen] = useState(false)
  const [drawerWidth, setDrawerWidth] = useState(40) // vh 單位
  const [isResizing, setIsResizing] = useState(false)
  
  // 最小和最大寬度限制
  const MIN_WIDTH = 40 // vh
  const MAX_WIDTH = 50 // vw (將轉換為 vh)
  
  // 從 store 獲取狀態和方法
  const { 
    tagsWindowRef, 
    pendingTags, 
    setPendingTags, 
    addPendingTag, 
    removePendingTag,
    externalTagSelectorPosition, 
    resetExternalTagSelectorPosition,
    mode, 
    pulse, 
    setMode,
    setConnected,
    setSearchMode: tagsStoreSetSearchMode
  } = useGlobalTagsStore()

  const { 
    fragments, 
    setFragments, 
    save, 
    selectedTags, 
    setSelectedTags, 
    excludedTags, 
    setExcludedTags, 
    tagLogicMode, 
    setTagLogicMode 
  } = useFragmentsStore()

  // 本地狀態
  const [search, setSearch] = useState('')
  const [allTags, setAllTags] = useState<TagInfo[]>([])
  const [onlyShowSel, setOnlyShowSel] = useState(false)
  const [sortMode, setSortMode] = useState<string>('desc_freq')
  const [searchMode, setSearchMode] = useState<'tag' | 'fragment'>('tag')
  const [recentlyUsedTags, setRecentlyUsedTags] = useState<string[]>([])
  const [isSearchFocused, setIsSearchFocused] = useState(false)
  const [showSpecialTags, setShowSpecialTags] = useState(false)
  const [metaTags] = useState<MetaTag[]>(DEFAULT_META_TAGS)
  const [selectedMetaTags, setSelectedMetaTags] = useState<MetaTag[]>([])
  const [visibleStartIndex, setVisibleStartIndex] = useState(0)
  const [itemsPerPage, setItemsPerPage] = useState(50)
  const tagListRef = useRef<HTMLDivElement>(null)
  const [editMode, setEditMode] = useState(false)
  const [selectedTagsToDelete, setSelectedTagsToDelete] = useState<string[]>([])
  const [editingTag, setEditingTag] = useState<string | null>(null)
  const [editValue, setEditValue] = useState('')
  const [searchExecuted, setSearchExecuted] = useState(false)
  const [noResults, setNoResults] = useState(false)
  const [searchedKeyword, setSearchedKeyword] = useState('')
  const [filteredFragments, setFilteredFragments] = useState<any[]>(fragments)
  const [dropFeedback, setDropFeedback] = useState<{ visible: boolean, message: string, success: boolean }>({
    visible: false,
    message: '',
    success: false
  })

  // 標籤拖拽相關
  const { isDragging, draggingTag, isOverTagWindow } = useTagDragManager()
  const { isCollected, addTag } = useTagCollectionStore()
  const { syncAddTag, syncRemoveTags } = useSingleUserTagSync()
  const { collectedTags } = useTagCollectionStore()
  const [tagViewMode, setTagViewMode] = useState<'personal' | 'global'>('personal')
  const { globalTags, initializeFromFragments } = useGlobalTagsStore()

  // 抽屜引用
  const drawerRef = useRef<HTMLDivElement>(null)
  const resizeHandleRef = useRef<HTMLDivElement>(null)

  // 設置 tagsWindowRef
  useEffect(() => {
    tagsWindowRef.current = drawerRef.current
  }, [tagsWindowRef])

  // 合併 ref
  const combinedRef = (node: HTMLDivElement | null) => {
    drawerRef.current = node
    tagsWindowRef.current = node
    if (ref) {
      if (typeof ref === 'function') {
        ref(node)
      } else {
        ref.current = node
      }
    }
  }

  // 監聽 tab 切換事件
  useEffect(() => {
    const handleTabToggle = (event: CustomEvent) => {
      const { windowId, isActive } = event.detail
      
      if (windowId === 'tags-floating-window') {
        setIsOpen(isActive)
      }
    }
    
    const handleTabCollapse = (event: CustomEvent) => {
      const { windowId } = event.detail
      if (windowId === 'tags-floating-window') {
        setIsOpen(false)
        setConnected(false)
      }
    }
    
    globalThis.window?.addEventListener('tab-toggle', handleTabToggle as EventListener)
    globalThis.window?.addEventListener('tab-collapse', handleTabCollapse as EventListener)
    
    return () => {
      globalThis.window?.removeEventListener('tab-toggle', handleTabToggle as EventListener)
      globalThis.window?.removeEventListener('tab-collapse', handleTabCollapse as EventListener)
    }
  }, [setConnected])

  // 處理拖拽調整寬度
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return
      
      const viewportWidth = window.innerWidth
      const viewportHeight = window.innerHeight
      const newWidthPx = e.clientX
      
      // 計算新寬度，限制在最小最大值之間
      const minWidthPx = (MIN_WIDTH / 100) * viewportHeight
      const maxWidthPx = (MAX_WIDTH / 100) * viewportWidth
      
      const clampedWidthPx = Math.min(Math.max(newWidthPx, minWidthPx), maxWidthPx)
      const newWidthVh = (clampedWidthPx / viewportHeight) * 100
      
      setDrawerWidth(newWidthVh)
    }
    
    const handleMouseUp = () => {
      setIsResizing(false)
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
    }
    
    if (isResizing) {
      document.body.style.cursor = 'col-resize'
      document.body.style.userSelect = 'none'
      document.addEventListener('mousemove', handleMouseMove)
      document.addEventListener('mouseup', handleMouseUp)
    }
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isResizing])

  // 處理抽屜開關
  const toggleDrawer = () => {
    const newIsOpen = !isOpen
    setIsOpen(newIsOpen)
    
  }

  // 初始化標籤列表
  useEffect(() => {
    const map = new Map<string, number>()
    fragments.forEach((f: any) => f.tags.forEach((t: string) => map.set(t, (map.get(t) || 0) + 1)))
    const extra = JSON.parse(localStorage.getItem('mur_tags_global') || '[]') as string[]
    extra.forEach(t => map.set(t, map.get(t) || 0))
    setAllTags([...map.entries()].map(([name, count]) => ({ name, count })))
    
    setFilteredFragments(fragments)
  }, [fragments])

  // 載入最近使用的標籤
  useEffect(() => {
    try {
      const storedRecentTags = JSON.parse(localStorage.getItem('mur_recent_tags') || '[]')
      setRecentlyUsedTags(storedRecentTags)
    } catch (e) {
      console.error('Error loading recent tags from localStorage', e)
    }
  }, [])

  // 處理搜尋模式變更
  const handleSearchModeChange = (newMode: 'tag' | 'fragment', isAddMode: boolean) => {
    console.log(`搜尋模式變更: ${newMode}, 是否為添加模式: ${isAddMode}`)
    
    useSearchStore.getState().setSearchMode(newMode)
    const ss = useSearchStore.getState()
    ss.setKeyword('')
    ss.setSelectedTags([])
    ss.setExcludedTags([])
    ss.setSearchResults([])

    setSearch('')

    if (newMode === 'fragment' && isAddMode) {
      console.log('執行顯式斷線操作')
      setMode('search')
      setConnected(false)
    }
  }

  const handleSetSearchMode = (mode: 'tag' | 'fragment') => {
    setSearchMode(mode)
    tagsStoreSetSearchMode(mode)
    useSearchStore.getState().setSearchMode(mode)
  
    if (mode === 'fragment') {
      setNoResults(false)
      setSearchedKeyword('')
    }
  }

  // 執行碎片搜尋邏輯（保持原有功能）
  const executeFragmentSearch = (searchText = search) => {
    const trimmed = searchText.trim()
  
    if (!trimmed) {
      console.log("🔁 沒有輸入關鍵字，顯示全部碎片")
      setFilteredFragments(fragments)
      const ss = useSearchStore.getState()
      ss.setKeyword('')
      ss.setSearchResults([])
      return
    }
  
    console.log(`執行碎片搜尋: "${trimmed}"`)
    setSearchExecuted(true)
  
    const searchStoreInstance = useSearchStore.getState()
    const currentScopes = searchStoreInstance.scopes || [searchMode]
  
    searchStoreInstance.setScopes(currentScopes)
    searchStoreInstance.setKeyword(trimmed)
    searchStoreInstance.setMatchMode('substring')
    searchStoreInstance.setTimeRange(searchStoreInstance.timeRange)
    searchStoreInstance.setSelectedTags(searchStoreInstance.selectedTags || [])
    searchStoreInstance.setExcludedTags(searchStoreInstance.excludedTags || [])
    searchStoreInstance.setTagLogicMode(searchStoreInstance.tagLogicMode || 'AND')
  
    const filtered = searchStoreInstance.executeSearch(fragments)
  
    setFilteredFragments(filtered)
    setNoResults(filtered.length === 0)
    setSearchedKeyword(trimmed)
  }

  // 其他函數保持原樣（記錄標籤使用、添加標籤、選擇標籤等）
  const recordTagUsage = (tagName: string) => {
    setRecentlyUsedTags(prev => {
      const filtered = prev.filter(t => t !== tagName)
      return [tagName, ...filtered].slice(0, 50)
    })
  
    try {
      const storedTags = JSON.parse(localStorage.getItem('mur_recent_tags') || '[]')
      const updatedTags = [tagName, ...storedTags.filter((t: string) => t !== tagName)].slice(0, 50)
      localStorage.setItem('mur_recent_tags', JSON.stringify(updatedTags))
    } catch (e) {
      console.error('Error saving recent tags to localStorage', e)
    }
  }

  const handleAddTag = () => {
    const raw = search.trim()
    if (!raw) return

    const clean = raw.replace(/^#/, '')
    if (isSystemTag(clean)) {
      setSearch('')
      return
    }
    
    if (!allTags.some(tag => tag.name === clean)) {
      setAllTags([...allTags, { name: clean, count: 1 }])
    }
    const stored = JSON.parse(localStorage.getItem('mur_tags_global') || '[]') as string[]
    if (!stored.includes(clean)) {
      localStorage.setItem('mur_tags_global', JSON.stringify([...stored, clean]))
    }
  
    if (mode === 'add') {
      addPendingTag(clean)
    }
  
    syncAddTag(clean)
    setSearch('')
  }

  const handleTagSelect = (t: string) => {
    if (mode === 'add' && isSystemTag(t)) return
    if (editMode) return
  
    recordTagUsage(t)
  
    if (mode === 'add') {
      pendingTags.includes(t) ? removePendingTag(t) : addPendingTag(t)
    } else {
      const newSelected = selectedTags.includes(t)
        ? selectedTags.filter((k: string) => k !== t)
        : [...selectedTags, t]
      const newExcluded = excludedTags.filter((k: string) => k !== t)
  
      setSelectedTags(newSelected)
      setExcludedTags(newExcluded)
  
      const ss = useSearchStore.getState()
      ss.setSelectedTags(newSelected)
      ss.setExcludedTags(newExcluded)
      ss.setTagLogicMode(tagLogicMode)
      ss.setKeyword('')
      ss.setScopes(['fragment'])
      const results = ss.executeSearch(fragments)
      setFilteredFragments(results)
    }
  }

  const handleTagExclude = (t: string) => {
    if (editMode || mode === 'add') return
  
    const newExcluded = excludedTags.includes(t)
      ? excludedTags.filter((k: string) => k !== t)
      : [...excludedTags, t]
    const newSelected = selectedTags.filter((k: string) => k !== t)
  
    setExcludedTags(newExcluded)
    setSelectedTags(newSelected)
  
    const ss = useSearchStore.getState()
    ss.setSelectedTags(newSelected)
    ss.setExcludedTags(newExcluded)
    ss.setTagLogicMode(tagLogicMode)
    ss.setKeyword('')
    ss.setScopes(['fragment'])
    const results = ss.executeSearch(fragments)
    setFilteredFragments(results)
  }

  // 獲取標籤狀態
  const isPos = (t: string) => mode === 'add' ? pendingTags.includes(t) : selectedTags.includes(t)
  const isNeg = (t: string) => mode === 'add' ? false : excludedTags.includes(t)

  // 過濾並排序標籤
  const getShownTags = () => {
    const tokens = SearchService.parseSearchQuery(search, 'substring')
    
    return allTags
      .filter(t => {
        if (!tokens.length) return true
  
        return tokens.some(token => {
          const tag = t.name.toLowerCase()
          const val = token.value.toLowerCase()
  
          if (token.type === 'include' || token.type === 'text') {
            return tag.includes(val)
          } else if (token.type === 'exact') {
            return tag === val
          } else if (token.type === 'wildcard') {
            return tag.includes(val.replace(/\*/g, ''))
          }
          return false
        })
      })
      .filter(t => {
        if (editMode) return true
        return mode === 'add'
          ? true
          : (onlyShowSel ? selectedTags.includes(t.name) || excludedTags.includes(t.name) : true)
      })
      .sort((a, b) => {
        const baseMode = sortMode.replace('asc_', '').replace('desc_', '')
        const isDesc = sortMode.startsWith('desc_')
  
        if (baseMode === 'az') {
          return isDesc ? b.name.localeCompare(a.name) : a.name.localeCompare(b.name)
        } else if (baseMode === 'freq') {
          return isDesc ? b.count - a.count : a.count - b.count
        } else if (baseMode === 'recent') {
          const aIndex = recentlyUsedTags.indexOf(a.name)
          const bIndex = recentlyUsedTags.indexOf(b.name)
          const aRecentIndex = aIndex === -1 ? Number.MAX_SAFE_INTEGER : aIndex
          const bRecentIndex = bIndex === -1 ? Number.MAX_SAFE_INTEGER : bIndex
          return isDesc ? bRecentIndex - aRecentIndex : aRecentIndex - bRecentIndex
        }
        return 0
      })
  }
  
  const shown = getShownTags()

  return (
    <>
      {/* 抽屜內容 */}
      <div
      id="tags-floating-window"
        ref={combinedRef}
        className={`
          fixed left-0 top-0 h-screen z-40
          transition-transform duration-500 ease-out
          ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
        style={{
          width: `${drawerWidth}vh`,
          background: 'linear-gradient(145deg, #f9f6e9 0%, #f0ead2 100%)',
          borderRight: '1px solid rgba(0, 0, 0, 0.1)',
          boxShadow: isOpen ? '0.25rem 0 1.25rem rgba(0, 0, 0, 0.1)' : 'none'
        }}
      >
        {/* 抽屜內容區域 */}
        <div className="h-full overflow-hidden flex flex-col">
          {/* 標題區域 */}
          <div className="p-4 border-b border-gray-200" style={{ borderBottomColor: 'rgba(0, 0, 0, 0.1)' }}>
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-1 text-base font-semibold text-gray-700">
                <span>{mode === 'add' ? '✔️' : '💬'}</span>
                <span>標籤</span>
              </div>
              
              {!editMode && (
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setEditMode(!editMode)}
                    className="w-6 h-6 flex items-center justify-center rounded-full text-gray-500 hover:bg-gray-100"
                    title="編輯模式"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                    </svg>
                  </button>
                  
                  {searchMode === 'tag' && !editMode && (
                    <button
                      onClick={() => setOnlyShowSel(!onlyShowSel)}
                      className={`w-6 h-6 flex items-center justify-center rounded-full text-gray-500 hover:bg-gray-100 ${onlyShowSel ? 'bg-gray-200' : ''}`}
                      title="只顯示已選擇"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="9 11 12 14 22 4"></polyline>
                        <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                      </svg>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* 搜尋與過濾區域 */}
            <div className="mb-4">
              <div className="relative">
                <TagsSearchBar
                  search={search}
                  setSearch={setSearch}
                  editMode={editMode}
                  searchMode={searchMode}
                  setSearchMode={handleSetSearchMode}
                  sortMode={sortMode}
                  setSortMode={setSortMode}
                  onAddTag={handleAddTag}
                  onFocus={() => !editMode && setIsSearchFocused(true)}
                  onBlur={() => !editMode && setTimeout(() => setIsSearchFocused(false), 200)}
                  selectedMetaTags={selectedMetaTags}
                  onRemoveMetaTag={(tagId) => setSelectedMetaTags(prev => prev.filter(tag => tag.id !== tagId))}
                  isAddMode={mode === 'add'}
                  onSearchModeChange={handleSearchModeChange}
                  onSearch={() => searchMode === 'fragment' && executeFragmentSearch()}
                  allTagNames={allTags.map(tag => tag.name)}
                />
                
                {searchMode === 'fragment' && (
                  <button
                    onClick={() => executeFragmentSearch()}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1.5 text-gray-600 hover:text-blue-600"
                    title="執行搜尋"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  </button>
                )}
              </div>

              {/* 特殊標籤選擇器 */}
              {isSearchFocused && !editMode && searchMode === 'tag' && (
                <MetaTagsSelector
                  metaTags={metaTags}
                  selectedMetaTags={selectedMetaTags}
                  onAddMetaTag={(tag) => {
                    setSelectedMetaTags(prev => {
                      if (prev.some(t => t.id === tag.id)) {
                        return prev.filter(t => t.id !== tag.id)
                      }
                      return [...prev, tag]
                    })
                    
                    const filtered = MetaTagsService.filterFragmentsByMetaTag(fragments, tag.id)
                    console.log(`添加特殊標籤: ${tag.name}，找到 ${filtered.length} 個相關碎片`)
                    setShowSpecialTags(false)
                  }}
                />
              )}

              {/* 邏輯切換 */}
              {!editMode && searchMode === 'tag' && (
                <TagLogicToggle
                  tagLogicMode={tagLogicMode}
                  setTagLogicMode={setTagLogicMode}
                  mode={mode}
                  pendingTags={pendingTags}
                  setPendingTags={setPendingTags}
                  selectedTags={selectedTags}
                  setSelectedTags={setSelectedTags}
                  excludedTags={excludedTags}
                  setExcludedTags={setExcludedTags}
                />
              )}
            </div>
          </div>
          
          {/* 編輯提示面板 */}
          {editMode && (
            <div className="px-4 py-2">
              <EditTagsPanel
                selectedTagsToDelete={selectedTagsToDelete}
                onDeleteTags={() => {
                  if (!selectedTagsToDelete.length || !confirm(`確定要刪除這 ${selectedTagsToDelete.length} 個標籤嗎？此操作無法撤銷。`)) return
                  syncRemoveTags(selectedTagsToDelete)
                  
                  setAllTags(allTags.filter(tag => !selectedTagsToDelete.includes(tag.name)))
                  
                  const stored = JSON.parse(localStorage.getItem('mur_tags_global') || '[]') as string[]
                  localStorage.setItem('mur_tags_global', JSON.stringify(
                    stored.filter(t => !selectedTagsToDelete.includes(t))
                  ))
                  
                  if (mode === 'add') {
                    setPendingTags(pendingTags.filter((t: string) => !selectedTagsToDelete.includes(t)))
                  } else {
                    setSelectedTags(selectedTags.filter((t: string) => !selectedTagsToDelete.includes(t)))
                    setExcludedTags(excludedTags.filter((t: string) => !selectedTagsToDelete.includes(t)))
                  }
                  
                  const updatedFragments = fragments.map((fragment: any) => {
                    if (fragment.tags.some((t: string) => selectedTagsToDelete.includes(t))) {
                      return {
                        ...fragment,
                        tags: fragment.tags.filter((t: string) => !selectedTagsToDelete.includes(t)),
                        updatedAt: new Date().toISOString()
                      }
                    }
                    return fragment
                  })
                  
                  setFragments(updatedFragments)
                  save()
                  setSelectedTagsToDelete([])
                }}
                onCancelSelection={() => setSelectedTagsToDelete([])}
              />
            </div>
          )}
          
          {/* 標籤列表或進階搜尋 */}
          <div className="flex-1 overflow-y-auto">
            {searchMode === 'tag' ? (
              <TagsList
                ref={tagListRef}
                isFullScreen={false}
                editMode={editMode}
                mode={mode}
                tags={allTags}
                itemsPerPage={itemsPerPage}
                totalTagsCount={shown.length}
                shown={shown}
                selectedTagsToDelete={selectedTagsToDelete}
                editingTag={editingTag}
                editValue={editValue}
                sortMode={sortMode}
                onScroll={() => {
                  if (!tagListRef.current) return
                  
                  const { scrollTop, scrollHeight, clientHeight } = tagListRef.current
                  
                  if (scrollHeight - scrollTop - clientHeight < 100) {
                    setItemsPerPage(prev => prev + 30)
                  }
                }}
                onTagSelect={handleTagSelect}
                onTagExclude={handleTagExclude}
                onTagSelectionToggle={(tagName) => {
                  setSelectedTagsToDelete(prev => 
                    prev.includes(tagName) 
                      ? prev.filter(t => t !== tagName) 
                      : [...prev, tagName]
                  )
                }}
                onSetEditingTag={setEditingTag}
                onEditValueChange={setEditValue}
                onTagRename={(oldName, newName) => {
                  newName = newName.trim()
                  if (!newName || oldName === newName) {
                    setEditingTag(null)
                    return
                  }
                  
                  if (allTags.some(tag => tag.name === newName && tag.name !== oldName)) {
                    alert('標籤名稱已存在！')
                    setEditingTag(null)
                    return
                  }
                  
                  setAllTags(allTags.map(tag => 
                    tag.name === oldName ? { name: newName, count: tag.count } : tag
                  ))

                  const stored = JSON.parse(localStorage.getItem('mur_tags_global') || '[]') as string[]
                  localStorage.setItem('mur_tags_global', JSON.stringify([
                    ...stored.filter(t => t !== oldName),
                    newName
                  ]))

                  if (mode === 'add') {
                    if (pendingTags.includes(oldName)) {
                      setPendingTags(pendingTags.map((t: string) => t === oldName ? newName : t))
                    }
                  } else {
                    if (selectedTags.includes(oldName)) {
                      setSelectedTags(selectedTags.map((t: string) => t === oldName ? newName : t))
                    }
                    if (excludedTags.includes(oldName)) {
                      setExcludedTags(excludedTags.map((t: string) => t === oldName ? newName : t))
                    }
                  }

                  const updatedFragments = fragments.map((fragment: any) => {
                    if (fragment.tags.includes(oldName)) {
                      return {
                        ...fragment,
                        tags: fragment.tags.map((t: string) => t === oldName ? newName : t),
                        updatedAt: new Date().toISOString()
                      }
                    }
                    return fragment
                  })

                  setFragments(updatedFragments)
                  save()
                  
                  setEditingTag(null)
                }}
                isPos={isPos}
                isNeg={isNeg}
              />
            ) : (
              <div className="p-4">
                <AdvancedSearchPanel
                  onSearch={(results) => {
                    console.log('搜尋結果：', results)
                    setFilteredFragments(results)
                  }}
                  noResults={noResults}
                  searchedKeyword={searchedKeyword}
                  onResetNoResults={() => {
                    setNoResults(false)
                    setSearchedKeyword('')
                  }}
                  onClearLocalSearch={() => setSearch('')}
                />
              </div>
            )}
          </div>
          
          {/* 右側拖拽調整手柄 */}
          <div
            ref={resizeHandleRef}
            className="absolute right-0 top-0 w-1 h-full cursor-col-resize bg-transparent hover:bg-gray-300 transition-colors z-50"
            onMouseDown={() => setIsResizing(true)}
            style={{
              background: isResizing ? 'rgba(0, 0, 0, 0.2)' : 'transparent'
            }}
          >
            <div className="w-full h-full flex items-center justify-center">
              <div className="w-0.5 h-8 bg-gray-400 rounded-full opacity-0 hover:opacity-100 transition-opacity" />
            </div>
          </div>
        </div>
      </div>
      
      {/* 標籤拖放接收區域 */}
      {isDragging && draggingTag && (
        <div
          className="absolute inset-0 z-50"
          style={{
            borderRadius: 'inherit',
            border: '2px dashed rgba(160, 120, 80, 0.5)',
            backgroundColor: isOverTagWindow 
              ? (isCollected(draggingTag) ? 'rgba(255, 200, 120, 0.2)' : 'rgba(100, 255, 150, 0.2)') 
              : 'transparent',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            pointerEvents: 'none',
            backdropFilter: isOverTagWindow ? 'blur(2px)' : 'none',
            transition: 'all 0.2s ease',
          }}
        >
          {isOverTagWindow && (
            <div 
              style={{
                backgroundColor: isCollected(draggingTag) ? '#f8d58c' : '#a0d9a0',
                color: isCollected(draggingTag) ? '#8d6a38' : '#2e6b2e',
                padding: '0.5rem 1rem',
                borderRadius: '1.25rem',
                fontWeight: 'bold',
                boxShadow: '0 2px 12px rgba(0,0,0,0.1)',
                animation: 'pulse 1.5s infinite',
              }}
            >
              {isCollected(draggingTag) ? '此標籤已在您的收藏中' : '拖放以加入您的標籤庫'}
            </div>
          )}
        </div>
      )}

      {/* 拖放操作反饋訊息 */}
      {dropFeedback.visible && (
        <div 
          style={{
            position: 'absolute',
            top: '0.625rem',
            left: '50%',
            transform: 'translateX(-50%)',
            backgroundColor: dropFeedback.success ? 'rgba(60, 179, 113, 0.9)' : 'rgba(255, 165, 0, 0.9)',
            color: 'white',
            padding: '0.5rem 1rem',
            borderRadius: '1.25rem',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
            fontSize: '0.875rem',
            zIndex: 60,
            animation: 'fadeInOut 3s ease-in-out',
          }}
        >
          {dropFeedback.message}
        </div>
      )}
    </>
  )
})

DrawerTagsWindow.displayName = 'DrawerTagsWindow'

export default DrawerTagsWindow