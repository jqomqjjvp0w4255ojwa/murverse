'use client'

import { useRef, useState, useEffect, useCallback } from 'react'
import { useGroupsStore } from '@/features/windows/useGroupsStore'
import { useDragStore } from '@/features/interaction/useDragStore'
import { 
  getDistance, 
  isRectOverlap, 
  isTooFarFromGroup, 
  GROUP_DISTANCE_THRESHOLD 
} from '@/features/windows/groupUtils'

// 設定閾值常數
const PROXIMITY_THRESHOLD = GROUP_DISTANCE_THRESHOLD * 0.3 
const SEPARATION_THRESHOLD = GROUP_DISTANCE_THRESHOLD * 0.4 
const CHECK_THROTTLE_MS = 100 

interface Position {
  x: number;
  y: number;
}

/**
 * 群組拖曳與自動吸附 Hook
 * @param {string} id - 窗口唯一標識符
 * @param {React.RefObject<HTMLDivElement>} ref - 窗口DOM引用
 * @returns {Object} - 位置狀態和控制方法
 */
export function useGroupDragAndSnap(id: string, ref: React.RefObject<HTMLDivElement>): {
  pos: Position;
  startDrag: (e: React.MouseEvent | MouseEvent) => void;
  isDragging: boolean;
  setPos: React.Dispatch<React.SetStateAction<Position>>;
} {
  const [pos, setPos] = useState<Position>({ x: 100, y: 100 })
  const [isDragging, setIsDragging] = useState(false)
  const dragOffset = useRef<Position>({ x: 0, y: 0 })
  const isDraggingRef = useRef(false)
  const lastCheckTime = useRef(0)

  // 從 store 獲取必要的方法
  const {
    windows,
    updateWindow,
    createGroup,
    removeWindowFromGroup,
    groups,
    checkAndResolveOverlaps
  } = useGroupsStore()
  
  const { setDraggingWindowId } = useDragStore()

  /**
   * 獲取元素 DOM 矩形的工具函數
   */
  const getElementRect = useCallback((elementId: string): DOMRect | null => {
    const element = document.getElementById(elementId)
    return element ? element.getBoundingClientRect() : null
  }, [])

  /**
   * 檢查窗口是否為抽屜類型
   */
  const isDrawerWindow = useCallback((windowId: string): boolean => {
    // 抽屜窗口不參與群組邏輯
    return windowId === 'tags-floating-window'
  }, [])

  /**
   * 檢查是否需要從群組中移除窗口
   */
  const checkGroupRemoval = useCallback((): void => {
    // 抽屜窗口不參與群組邏輯
    if (isDrawerWindow(id)) return
    
    const myRect = getElementRect(id)
    if (!myRect) return
    
    const { checkAndRemoveFromGroup } = useGroupsStore.getState()
    
    checkAndRemoveFromGroup(id)
    
    const myGroup = groups.find(g => g.memberIds.includes(id))
    if (!myGroup) return
    
    const otherRects = myGroup.memberIds
      .filter(memberId => memberId !== id)
      .map(getElementRect)
      .filter((rect): rect is DOMRect => rect !== null)
    
    if (otherRects.length === 0) return

    // 檢查是否距離群組太遠
    if (isTooFarFromGroup(myRect, otherRects)) {
      console.log(`🧨 ${id} 離群組，因為距離太遠！`)
      removeWindowFromGroup(id)
    }
  }, [id, groups, getElementRect, removeWindowFromGroup, isDrawerWindow])

  /**
   * 處理特殊窗口的群組關係 - 修復版本
   * 只處理浮動窗口之間的群組關係，抽屜窗口不參與
   */
  const handleSpecialWindows = useCallback((): void => {
    // 如果當前窗口是抽屜，不處理群組邏輯
    if (isDrawerWindow(id)) return
    
    // 目前只有 floating-input-bar 是真正的浮動窗口
    // tags-floating-window 是抽屜，不參與群組
    if (id !== 'floating-input-bar') return
    
    // 可以在這裡添加其他浮動窗口的特殊群組邏輯
    // 例如：floating-input-bar 與其他浮動窗口的自動群組
    
    console.log(`🔗 處理 ${id} 的特殊群組邏輯`)
  }, [id, isDrawerWindow])

  /**
   * 檢查窗口間的鄰近狀態並處理群組
   */
  const checkProximity = useCallback((): void => {
    const now = Date.now()
    if (now - lastCheckTime.current < CHECK_THROTTLE_MS) return
    lastCheckTime.current = now
    
    // 抽屜窗口不參與群組邏輯
    if (isDrawerWindow(id)) return
    
    if (!document.getElementById(id)) return
    
    const myRect = getElementRect(id)
    if (!myRect) return
    
    checkGroupRemoval()
    handleSpecialWindows()

    if (windows.length < 2) return

    for (const w of windows) {
      if (w.id === id) continue
      
      // 跳過抽屜窗口
      if (isDrawerWindow(w.id)) continue

      const otherRect = getElementRect(w.id)
      if (!otherRect) continue

      const alreadyGrouped = groups.some(
        g => g.memberIds.includes(id) && g.memberIds.includes(w.id)
      )
      
      if (alreadyGrouped) continue

      const isClose = getDistance(myRect, otherRect) < PROXIMITY_THRESHOLD
      const isOverlapping = isRectOverlap(myRect, otherRect, 20)

      if (isClose || isOverlapping) {
        try {
          console.log(`🔗 創建群組: ${id} + ${w.id}`)
          createGroup([id, w.id])
          return
        } catch (err) {
          console.warn(`群組創建失敗:`, err)
        }
      }
    }
  }, [id, windows, groups, createGroup, getElementRect, checkGroupRemoval, handleSpecialWindows, isDrawerWindow])

  /**
   * 開始拖曳操作
   */
  const startDrag = useCallback((e: React.MouseEvent | MouseEvent): void => {
    if (!ref.current || isDraggingRef.current) return
    
    // 抽屜窗口不支持拖曳
    if (isDrawerWindow(id)) return
    
    const rect = ref.current.getBoundingClientRect()
    dragOffset.current = { x: e.clientX - rect.left, y: e.clientY - rect.top }
    
    isDraggingRef.current = true
    setIsDragging(true)
    setDraggingWindowId(id)
    
    checkProximity()
  }, [ref, id, setDraggingWindowId, checkProximity, isDrawerWindow])

  // 拖曳中的定期群組檢查
  useEffect(() => {
    let checkInterval: NodeJS.Timeout | null = null
    
    if (isDragging && !isDrawerWindow(id)) {
      checkInterval = setInterval(checkProximity, CHECK_THROTTLE_MS)
    }
    
    return () => {
      if (checkInterval) clearInterval(checkInterval)
    }
  }, [isDragging, checkProximity, id, isDrawerWindow])

  // 處理滑鼠移動和釋放事件
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent): void => {
      if (!isDraggingRef.current || !ref.current) return
      if (isDrawerWindow(id)) return // 抽屜不支持拖曳

      const newX = e.clientX - dragOffset.current.x
      const newY = e.clientY - dragOffset.current.y
      
      setPos({ x: newX, y: newY })

      const rect = ref.current.getBoundingClientRect()
      updateWindow(id, {
        x: rect.left,
        y: rect.top,
        width: rect.width,
        height: rect.height,
      })
      
      const now = Date.now()
      if (now - lastCheckTime.current > CHECK_THROTTLE_MS) {
        checkProximity()
      }
    }

    const handleMouseUp = (): void => {
      if (!isDraggingRef.current) return
      
      isDraggingRef.current = false
      setIsDragging(false)
      
      if (ref.current && !isDrawerWindow(id)) {
        const rect = ref.current.getBoundingClientRect()
        updateWindow(id, { x: rect.left, y: rect.top })
      }
      
      setTimeout(() => {
        if (!isDrawerWindow(id)) {
          handleSpecialWindows()
          checkGroupRemoval()
          
          const myRect = getElementRect(id)
          if (myRect) {
            let overlappedWindowId: string | null = null
            
            for (const w of windows) {
              if (w.id === id) continue
              if (isDrawerWindow(w.id)) continue // 跳過抽屜
              
              const otherRect = getElementRect(w.id)
              if (!otherRect) continue
              
              if (isRectOverlap(myRect, otherRect, 20)) {
                overlappedWindowId = w.id
                break
              }
            }
            
            if (overlappedWindowId) {
              const alreadyGrouped = groups.some(
                g => g.memberIds.includes(id) && g.memberIds.includes(overlappedWindowId!)
              )
              
              if (!alreadyGrouped) {
                console.log(`🔗 拖曳結束時創建群組: ${id} + ${overlappedWindowId}`)
                createGroup([id, overlappedWindowId])
              }
            }
          }
          
          // 检查并解决所有窗口重叠
          checkAndResolveOverlaps()
        }
        
        setDraggingWindowId(null)
      }, 50)
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [
    id, 
    ref, 
    updateWindow, 
    createGroup, 
    groups, 
    checkProximity, 
    windows, 
    getElementRect,
    checkGroupRemoval,
    handleSpecialWindows,
    setDraggingWindowId,
    checkAndResolveOverlaps,
    isDrawerWindow
  ])

  return { pos, startDrag, isDragging, setPos }
}