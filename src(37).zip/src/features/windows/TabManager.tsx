// src/features/windows/TabManager.tsx
'use client'

import React, { useState, useRef, useEffect } from 'react'

// 簡單的圖標組件
const PlusIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-full h-full">
    <line x1="12" y1="5" x2="12" y2="19"></line>
    <line x1="5" y1="12" x2="19" y2="12"></line>
  </svg>
)

const TagIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-full h-full">
    <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
    <line x1="7" y1="7" x2="7.01" y2="7"></line>
  </svg>
)

// Tab 窗口配置
const TAB_WINDOWS = [
  {
    id: 'floating-input-bar',
    title: '碎片',
    icon: PlusIcon,
    color: '#4f46e5',
    type: 'floating' // 浮動窗口
  },
  {
    id: 'tags-floating-window', 
    title: '標籤',
    icon: TagIcon,
    color: '#059669',
    type: 'drawer' // 抽屜窗口
  }
]

interface TabManagerProps {
  children: React.ReactNode
  onTabToggle?: (windowId: string, isActive: boolean) => void
}

// 單個 Tab 書籤組件
function WindowTab({ 
  window, 
  isActive, 
  onClick, 
  tabRef 
}: {
  window: typeof TAB_WINDOWS[0]
  isActive: boolean
  onClick: () => void
  tabRef: (el: HTMLDivElement | null) => void
}) {
  const Icon = window.icon
  
  return (
    <div
      ref={tabRef}
      onClick={onClick}
      className={`
        relative cursor-pointer transition-all duration-300 ease-out
        transform hover:scale-105 group select-none
        ${isActive ? 'z-20' : 'z-10'}
      `}
      style={{
        filter: isActive ? 'drop-shadow(2px 0 8px rgba(0,0,0,0.15))' : 'none'
      }}
    >
      {/* 直長條書籤背景 - 參考圖片的書籤樣式 */}
      <div 
        className={`
          relative w-12 h-16 transition-all duration-300 ease-out
          ${isActive ? 'scale-110' : 'hover:scale-105'}
        `}
        style={{
          background: isActive 
            ? 'linear-gradient(135deg, #f0e6d2 0%, #e8d5b7 100%)' 
            : 'linear-gradient(135deg, #f9f6e9 0%, #f0ead2 100%)',
          clipPath: 'polygon(0 0, 85% 0, 100% 15%, 100% 85%, 85% 100%, 0 100%)', // 右側帶小凹槽的直條
          border: isActive ? '1px solid rgba(0, 0, 0, 0.1)' : '1px solid rgba(0, 0, 0, 0.05)',
          borderLeft: 'none',
          borderRadius: '0 4px 4px 0',
        }}
      >
        {/* 圖標和文字 */}
        <div className="absolute inset-0 flex flex-col items-center justify-center" 
             style={{ color: isActive ? '#333' : '#666' }}>
          <div className={`transition-all duration-300 ${isActive ? 'w-4 h-4 mb-0.5' : 'w-3.5 h-3.5 mb-0.5'}`}>
            <Icon />
          </div>
          <span className={`text-xs font-medium transition-all duration-300 ${isActive ? 'text-[10px]' : 'text-[9px]'}`}>
            {window.title}
          </span>
        </div>
        
        {/* 激活指示器 - 更細的線條 */}
        {isActive && (
          <div 
            className="absolute -right-0.5 top-1 w-0.5 h-4 rounded-l-full"
            style={{ backgroundColor: '#d1b684' }}
          />
        )}
      </div>
    </div>
  )
}

export default function TabManager({ children, onTabToggle }: TabManagerProps) {
  const [activeWindows, setActiveWindows] = useState<Set<string>>(new Set())
  const [drawerWidth, setDrawerWidth] = useState(40) // 抽屜寬度 (vh)
  const tabRefs = useRef<Record<string, HTMLDivElement | null>>({})
  
  // 計算 tab 位置的方法
  const getTabPosition = (windowId: string) => {
    const tabElement = tabRefs.current[windowId]
    if (!tabElement) return null
    
    const rect = tabElement.getBoundingClientRect()
    return {
      x: rect.left,
      y: rect.top,
      width: rect.width,
      height: rect.height
    }
  }
  
  // 切換窗口顯示狀態
  const handleTabClick = (window: typeof TAB_WINDOWS[0]) => {
    const isCurrentlyActive = activeWindows.has(window.id)
    const newActiveWindows = new Set(activeWindows)
    
    if (isCurrentlyActive) {
      newActiveWindows.delete(window.id)
    } else {
      newActiveWindows.add(window.id)
    }
    
    setActiveWindows(newActiveWindows)
    
    // 通知父組件 tab 狀態變化
    onTabToggle?.(window.id, !isCurrentlyActive)
    
    // 觸發自定義事件，讓窗口組件監聽
    globalThis.window?.dispatchEvent(new CustomEvent('tab-toggle', {
      detail: { 
        windowId: window.id, 
        isActive: !isCurrentlyActive,
        tabPosition: getTabPosition(window.id),
        windowType: window.type
      }
    }))
  }
  
  // 處理窗口收合回到 tab 狀態
  const handleWindowCollapse = (windowId: string) => {
    const newActiveWindows = new Set(activeWindows)
    newActiveWindows.delete(windowId)
    setActiveWindows(newActiveWindows)
    
    // 觸發收合事件
    globalThis.window?.dispatchEvent(new CustomEvent('tab-toggle', {
      detail: { 
        windowId: windowId, 
        isActive: false,
        tabPosition: getTabPosition(windowId)
      }
    }))
    
    // 同時觸發斷開連線事件
    globalThis.window?.dispatchEvent(new CustomEvent('disconnect-line', {
      detail: { windowId }
    }))
  }
  
  // 監聽抽屜寬度變化（用於調整 tab 位置）
  useEffect(() => {
    const handleDrawerResize = (event: CustomEvent) => {
      const { width } = event.detail
      setDrawerWidth(width)
    }
    
    globalThis.window?.addEventListener('drawer-resize', handleDrawerResize as EventListener)
    
    return () => {
      globalThis.window?.removeEventListener('drawer-resize', handleDrawerResize as EventListener)
    }
  }, [])
  
  // 監聽窗口收合事件
  useEffect(() => {
    const handleTabCollapse = (event: CustomEvent) => {
      const { windowId } = event.detail
      handleWindowCollapse(windowId)
    }
    
    globalThis.window?.addEventListener('tab-collapse', handleTabCollapse as EventListener)
    
    return () => {
      globalThis.window?.removeEventListener('tab-collapse', handleTabCollapse as EventListener)
    }
  }, [activeWindows])
  
  // 提供給外部獲取 tab 位置的方法
  useEffect(() => {
    // 將 getTabPosition 方法掛載到全局，供窗口組件使用
    if (typeof window !== 'undefined') {
      ;(globalThis.window as any).getTabPosition = getTabPosition
    }
    
    return () => {
      if (typeof window !== 'undefined') {
        delete (globalThis.window as any).getTabPosition
      }
    }
  }, [])
  
  return (
    <>
      {/* 左側 Tab 書籤欄 */}
      <div className="fixed left-0 top-1/4 z-50 space-y-2">
        {TAB_WINDOWS.map((window) => {
          const isActive = activeWindows.has(window.id)
          const isDrawerWindow = window.type === 'drawer'
          const currentDrawerWidth = isDrawerWindow && isActive ? drawerWidth : 0
          
          return (
            <div
              key={window.id}
              className="transition-transform duration-500 ease-out"
              style={{
                transform: isDrawerWindow && isActive 
                  ? `translateX(${currentDrawerWidth}vh)` 
                  : 'translateX(0)'
              }}
            >
              <WindowTab
                window={window}
                isActive={isActive}
                onClick={() => handleTabClick(window)}
                tabRef={(el) => tabRefs.current[window.id] = el}
              />
            </div>
          )
        })}
      </div>
      
      {/* 渲染子組件（原有的窗口內容） */}
      {children}
      
      {/* 為窗口提供 CSS 變量，用於動畫計算 */}
      <style jsx global>{`
        :root {
          --tab-area-width: 4rem;
          --drawer-width: ${drawerWidth}vh;
        }
        
        /* Tab 展開時的窗口入場動畫 */
        .window-enter {
          animation: slideInFromLeft 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .window-exit {
          animation: slideOutToLeft 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        /* 抽屜展開時的內容區域調整 */
        .main-content-area {
          transition: margin-left 0.5s ease-out;
          margin-left: calc(var(--tab-area-width) + var(--drawer-width, 0px));
        }
        
        @keyframes slideInFromLeft {
          from {
            opacity: 0;
            transform: translateX(-1.25rem) scale(0.95);
          }
          to {
            opacity: 1;
            transform: translateX(0) scale(1);
          }
        }
        
        @keyframes slideOutToLeft {
          from {
            opacity: 1;
            transform: translateX(0) scale(1);
          }
          to {
            opacity: 0;
            transform: translateX(-1.25rem) scale(0.95);
          }
        }
      `}</style>
    </>
  )
}