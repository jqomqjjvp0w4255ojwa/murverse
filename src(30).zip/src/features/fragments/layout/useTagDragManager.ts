import { useState, useEffect, useCallback, useRef } from 'react'
import { TagsService } from '@/features/tags/services/TagsService'

const DRAG_THRESHOLD = 4 // 拖曳的最小位移像素才能觸發拖曳行為

export function useTagDragManager() {
  const [draggingTag, setDraggingTag] = useState<string | null>(null)
  const [dragPosition, setDragPosition] = useState<{ x: number; y: number } | null>(null)
  const isDraggingRef = useRef(false)
  const wasDraggingRef = useRef(false)
  const [isDragging, setIsDragging] = useState(false)
  const dragStartPos = useRef<{ x: number, y: number } | null>(null)
  
  // 追蹤標籤懸停在哪個碎片上
  const dragOverFragmentRef = useRef<string | null>(null)
  
  // 追蹤原始碎片（用於避免將標籤放回原來的碎片）
  const sourceFragmentRef = useRef<string | null>(null)
  
  // 觸發拖曳（從外部呼叫）
  const startTagDrag = useCallback((tag: string, e: React.MouseEvent, fragmentId?: string) => {
    dragStartPos.current = { x: e.clientX, y: e.clientY }
    setDraggingTag(tag)
    setDragPosition({ x: e.clientX, y: e.clientY })
    sourceFragmentRef.current = fragmentId || null
    // 暫不設定 isDraggingRef，等滑動超過門檻才開始拖曳
  }, [])

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!dragStartPos.current || !draggingTag) return

      const dx = e.clientX - dragStartPos.current.x
      const dy = e.clientY - dragStartPos.current.y
      const distance = Math.sqrt(dx * dx + dy * dy)

      if (!isDraggingRef.current && distance > DRAG_THRESHOLD) {
        isDraggingRef.current = true // 正式啟用拖曳
        setIsDragging(true)
      }

      if (isDraggingRef.current) {
        setDragPosition({ x: e.clientX, y: e.clientY })
        
        // 檢查是否懸停在碎片上
        const elementsUnderMouse = document.elementsFromPoint(e.clientX, e.clientY)
        const fragmentElement = elementsUnderMouse.find(el => 
          el.classList.contains('fragment-card') && el.getAttribute('data-fragment-id')
        )
        
        // 清除之前的所有高亮
        document.querySelectorAll('.tag-drop-target').forEach(el => {
          el.classList.remove('tag-drop-target')
        })
        
        if (fragmentElement) {
          const fragmentId = fragmentElement.getAttribute('data-fragment-id')
          
          // 確認不是拖回原始碎片
          if (fragmentId && fragmentId !== sourceFragmentRef.current) {
            dragOverFragmentRef.current = fragmentId
            
            // 添加視覺反饋
            fragmentElement.classList.add('tag-drop-target')
          } else {
            dragOverFragmentRef.current = null
          }
        } else {
          dragOverFragmentRef.current = null
        }
      }
    }

    const handleMouseUp = () => {
      if (isDraggingRef.current && draggingTag) {
        // 檢查是否放置在碎片上
        if (dragOverFragmentRef.current) {
          // 添加標籤到目標碎片
          const result = TagsService.addTagToFragment(dragOverFragmentRef.current, draggingTag)
          
          // 顯示操作結果提示（可以用 toast 之類的通知）
          if (result.success) {
            console.log(`🏷️ ${result.message}`)
            // 這裡可以加入提示動畫或通知
          } else {
            console.warn(`⚠️ ${result.message || '操作失敗'}`)
          }
          
          // 清除視覺反饋
          document.querySelectorAll('.tag-drop-target').forEach(el => {
            el.classList.remove('tag-drop-target')
          })
        }
        
        // 清理狀態
        setDraggingTag(null)
        setDragPosition(null)
        isDraggingRef.current = false
        setIsDragging(false) 
        wasDraggingRef.current = true
        dragOverFragmentRef.current = null
        sourceFragmentRef.current = null
        
        // 短暫延遲後重置 wasDragging 標記（用於防止拖曳後的意外點擊）
        setTimeout(() => { 
          wasDraggingRef.current = false 
        }, 100)
      } else {
        // 重置數據，但不設置 wasDragging
        setDraggingTag(null)
        setDragPosition(null)
        dragStartPos.current = null
        dragOverFragmentRef.current = null
        sourceFragmentRef.current = null
      }
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)
    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [draggingTag])
  
  // 提供外部可接觸的狀態和方法
  return {
    draggingTag,
    dragPosition,
    isDragging: isDraggingRef.current,
    wasDraggingRef,
    startTagDrag,
    // 導出當前懸停的碎片 ID，以便外部使用
    dragOverFragmentId: dragOverFragmentRef.current,
  }
}

// 將此添加到全局 CSS 或組件樣式中
// .fragment-card.tag-drop-target {
//   box-shadow: 0 0 0 2px rgba(201, 155, 53, 0.7) !important;
//   transform: scale(1.02) !important;
//   transition: all 0.2s ease !important;
// }