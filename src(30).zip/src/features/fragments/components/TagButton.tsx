import React, { useState } from 'react'

interface TagButtonProps {
  tag: string
  onTagClick?: (tag: string, e: React.MouseEvent) => void
  onTagDragStart?: (e: React.MouseEvent, tag: string) => void
  style?: React.CSSProperties
}

const TagButton: React.FC<TagButtonProps> = ({
  tag,
  onTagClick,
  onTagDragStart,
  style = {},
}) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="tag-button"
      onClick={(e) => {
        e.stopPropagation()
        if (onTagClick) onTagClick(tag, e)
      }}
      onMouseDown={(e) => {
        e.preventDefault()
        e.stopPropagation()
        if (onTagDragStart) onTagDragStart(e, tag)
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        backgroundColor: '#f3e8c7',
        color: '#8d6a38',
        borderRadius: '12px',
        padding: '2px 6px',
        fontSize: '10px',
        whiteSpace: 'nowrap',
        cursor: 'grab',
        // 增加视觉暗示，让用户知道可拖拽
        boxShadow: isHovered ? '0 2px 4px rgba(0,0,0,0.15)' : 'none',
        transform: isHovered ? 'translateY(-1px)' : 'none',
        transition: 'all 0.15s ease',
        border: isHovered ? '1px solid #e6c677' : '1px solid transparent',
        position: 'relative',
        ...style,
      }}
    >
      {tag}
      
      {/* 拖拽提示图标 */}
      {isHovered && (
        <div
          style={{
            position: 'absolute',
            top: '-4px',
            right: '-4px',
            fontSize: '9px',
            opacity: 0.7,
            backgroundColor: '#f8f0dc',
            borderRadius: '50%',
            width: '12px',
            height: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            border: '1px solid #e6c677',
          }}
        >
          ⇄
        </div>
      )}
    </div>
  )
}

export default TagButton