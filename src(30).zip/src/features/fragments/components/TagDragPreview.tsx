// TagDragPreview.tsx - 拖拽过程中显示的预览组件

import React from 'react'

interface TagDragPreviewProps {
  tag: string
  position: { x: number; y: number }
}

const TagDragPreview: React.FC<TagDragPreviewProps> = ({ tag, position }) => {
  return (
    <div
      style={{
        position: 'fixed',
        left: position.x,
        top: position.y,
        transform: 'translate(-50%, -50%)',
        backgroundColor: '#fff4d5',
        color: '#8d6a38',
        borderRadius: '14px',
        padding: '3px 10px',
        fontSize: '12px',
        boxShadow: '0 3px 10px rgba(0, 0, 0, 0.2)',
        border: '2px solid #e6c677',
        whiteSpace: 'nowrap',
        pointerEvents: 'none',
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        gap: '4px',
        userSelect: 'none'
      }}
    >
      <span style={{ fontSize: '14px' }}>🏷️</span>
      <span>{tag}</span>
      <span 
        style={{ 
          fontSize: '10px', 
          backgroundColor: 'rgba(255, 255, 255, 0.6)',
          padding: '1px 4px',
          borderRadius: '8px',
          color: '#a06820',
          marginLeft: '2px'
        }}
      >
        拖动中...
      </span>
    </div>
  )
}

export default TagDragPreview