// 修改 TagDetailModal.tsx 中的收藏状态检查和显示

'use client'

import React, { useEffect, useRef } from 'react'
import { Fragment } from '@/features/fragments/types/fragment'
import { useTagCollectionStore } from '@/features/tags/store/useTagCollectionStore'
import { TagsService } from '@/features/tags/services/TagsService'

interface TagDetailModalProps {
  tag: string
  relatedFragments: Fragment[]
  onClose: () => void
}

const TagDetailModal: React.FC<TagDetailModalProps> = ({
  tag,
  relatedFragments,
  onClose,
}) => {
  const modalRef = useRef<HTMLDivElement>(null)
  const { isCollected, addTag, removeTag } = useTagCollectionStore()
  const alreadyCollected = isCollected(tag)
  
  // 按 Escape 关闭
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }

    // 点击外部关闭
    let lastClickTime = 0
    let clickCount = 0

    const handleClickOutside = (e: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
        const now = Date.now()
        if (now - lastClickTime < 300) {
          clickCount += 1
        } else {
          clickCount = 1
        }
        lastClickTime = now

        if (clickCount >= 2) {
          onClose()
        }
      }
    }

    document.addEventListener('keydown', handleEscape)
    document.addEventListener('mousedown', handleClickOutside)

    return () => {
      document.removeEventListener('keydown', handleEscape)
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [onClose])

  // 处理收藏/取消收藏操作
  const handleCollectionToggle = () => {
    if (alreadyCollected) {
      removeTag(tag)
    } else {
      addTag(tag)
    }
  }

  const formatDate = (dateString?: string) => {
    if (!dateString) return ''
    const date = new Date(dateString)
    return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日`
  }

  // 寻找相似标签
  const similarTags = TagsService.findSimilarTagsByCooccurrence(tag, 5)

  return (
    <div 
      className="fixed inset-0 flex items-center justify-center z-[9999] p-4"
      style={{
        backgroundColor: 'rgba(0, 0, 0, 0.75)',
        backdropFilter: 'blur(4px)',
        WebkitBackdropFilter: 'blur(4px)',
        overflowY: 'auto',
      }}
    >
      <div
        ref={modalRef}
        className="bg-white rounded-2xl shadow-xl max-w-3xl w-full"
        style={{
          backgroundColor: '#fffdf7',
          border: '1px solid #e2e2e2',
          display: 'flex',
          flexDirection: 'column',
          maxHeight: '95vh',
          overflow: 'hidden',
          boxShadow: '0 10px 40px rgba(0, 0, 0, 0.3)',
          position: 'relative',
          zIndex: 10000, // 确保在所有元素上方
        }}
      >
        {/* 标题列 */}
        <div className="flex justify-between items-center px-6 py-4 border-b border-gray-200 sticky top-0 bg-[#fffdf7] z-10">
          <h3
            className="text-xl font-semibold text-gray-800 flex items-center"
            style={{
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              maxWidth: '80%',
            }}
          >
            <span className="mr-2" style={{ color: '#8d6a38' }}>🏷️</span>
            {tag}
          </h3>
          <div className="flex items-center gap-3">
            <button
              onClick={handleCollectionToggle}
              className="text-amber-600 hover:text-amber-700 flex items-center gap-1 px-3 py-1.5 rounded hover:bg-amber-50 transition-colors"
              style={{
                fontSize: '14px',
                border: alreadyCollected ? '1px solid #d4a748' : '1px dashed #d4a748',
                backgroundColor: alreadyCollected ? 'rgba(254, 240, 199, 0.5)' : 'transparent',
              }}
            >
              <span>{alreadyCollected ? '⭐ 已收藏' : '☆ 收藏标签'}</span>
            </button>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 focus:outline-none"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>
        </div>

        {/* 内容区域 */}
        <div
          className="p-6 space-y-6 overflow-y-auto"
          style={{
            flex: 1,
            minHeight: 0,
          }}
        >
          {/* 标签收藏状态提示 */}
          {alreadyCollected && (
            <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-md">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <span className="text-amber-500 text-xl">⭐</span>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-amber-700">
                    此标签已在您的收藏中
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 其余内容保持不变 */}
          {/* 标签统计 */}
          <div className="bg-amber-50 rounded-lg p-4 flex flex-wrap gap-4">
            <div className="flex flex-col items-center justify-center bg-white rounded-lg p-3 shadow-sm min-w-[100px]">
              <div className="text-2xl font-bold text-amber-700">{relatedFragments.length}</div>
              <div className="text-xs text-gray-500">相关碎片</div>
            </div>
            
            <div className="flex flex-col items-center justify-center bg-white rounded-lg p-3 shadow-sm min-w-[100px]">
              <div className="text-2xl font-bold text-amber-700">
                {similarTags.length > 0 ? similarTags.length : 0}
              </div>
              <div className="text-xs text-gray-500">相似标签</div>
            </div>
            
            <div className="flex flex-col items-center justify-center bg-white rounded-lg p-3 shadow-sm min-w-[100px]">
              <div className="text-2xl font-bold text-amber-700">
                {relatedFragments.length > 0 
                  ? new Date(relatedFragments[0].updatedAt).toLocaleDateString('zh-TW') 
                  : '-'}
              </div>
              <div className="text-xs text-gray-500">最近使用</div>
            </div>
          </div>
          
          {/* 其余内容省略... */}
        </div>

        {/* 底部操作列 */}
        <div className="px-6 py-3 bg-gray-50 border-t border-gray-200 flex justify-between items-center">
          <div className="text-xs text-gray-500">
            双击背景关闭此窗口
          </div>
          <button
            onClick={() => {
              const isConfirmed = window.confirm(`确定要删除标签「${tag}」吗？\n注意：将从所有碎片中移除此标签。`);
              if (isConfirmed) {
                TagsService.deleteTag(tag);
                onClose();
              }
            }}
            className="text-red-600 hover:text-red-700 text-sm px-3 py-1 rounded hover:bg-red-50"
          >
            删除标签
          </button>
        </div>
      </div>
    </div>
  )
}

export default TagDetailModal