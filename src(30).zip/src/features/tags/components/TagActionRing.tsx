'use client'

import React, { useState, useEffect, useRef } from 'react'
import { useTagCollectionStore } from '@/features/tags/store/useTagCollectionStore'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { TagsService } from '@/features/tags/services/TagsService'

interface TagActionRingProps {
  tag: string
  position: { x: number; y: number }
  onClose: () => void
  onOpenDetail: (tag: string) => void
  onDeleteTag?: (tag: string) => void
}

// 定義行動選項
interface ActionOption {
  icon: string
  label: string
  action: () => void
  isDisabled?: boolean
  isHighlighted?: boolean
}

const TagActionRing: React.FC<TagActionRingProps> = ({
  tag,
  position,
  onClose,
  onOpenDetail,
  onDeleteTag
}) => {
  const { isCollected, addTag, removeTag } = useTagCollectionStore()
  const { fragments } = useFragmentsStore()
  const alreadyCollected = isCollected(tag)
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null)
  const [showConfirmDelete, setShowConfirmDelete] = useState(false)
  const ringRef = useRef<HTMLDivElement>(null)
  
  // 計算此標籤在幾個片段中出現
  const fragmentsWithTag = fragments.filter(f => f.tags.includes(tag)).length

  // 根據標籤定義選項
  const options: ActionOption[] = [
    { 
      icon: '🔍', 
      label: '詳情', 
      action: () => {
        onOpenDetail(tag)
        onClose()
      }
    },
    { 
      icon: alreadyCollected ? '⭐' : '☆', 
      label: alreadyCollected ? '已收藏' : '收藏', 
      action: () => {
        if (!alreadyCollected) {
          addTag(tag)
        } else {
          removeTag(tag)
        }
        onClose()
      },
      isDisabled: false,
      isHighlighted: !alreadyCollected
    },
    { 
      icon: '🗑️', 
      label: '刪除標籤', 
      action: () => {
        setShowConfirmDelete(true)
      },
      isHighlighted: false
    }
  ]

  // 環形佈局的半徑
  const RING_RADIUS = 80
  const OPTION_SIZE = 44
  
  // 鍵盤操作
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!options.length) return
      
      switch (e.key) {
        case 'ArrowRight':
        case 'ArrowDown':
          e.preventDefault()
          setSelectedIndex(prev => 
            prev === null ? 0 : (prev + 1) % options.length
          )
          break
        case 'ArrowLeft':
        case 'ArrowUp':
          e.preventDefault()
          setSelectedIndex(prev => 
            prev === null ? options.length - 1 : (prev - 1 + options.length) % options.length
          )
          break
        case 'Enter':
        case ' ':
          e.preventDefault()
          if (selectedIndex !== null) {
            options[selectedIndex].action()
          }
          break
        case 'Escape':
          e.preventDefault()
          if (showConfirmDelete) {
            setShowConfirmDelete(false)
          } else {
            onClose()
          }
          break
      }
    }
    
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [options, selectedIndex, showConfirmDelete, onClose])
  
  // 點擊外部關閉
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ringRef.current && !ringRef.current.contains(e.target as Node)) {
        if (showConfirmDelete) {
          setShowConfirmDelete(false)
        } else {
          onClose()
        }
      }
    }
    
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [onClose, showConfirmDelete])

  // 當確認刪除時
  const handleConfirmDelete = () => {
    if (onDeleteTag) {
      onDeleteTag(tag)
    } else {
      const result = TagsService.deleteTag(tag)
      console.log(`🗑️ ${result.message}`)
    }
    onClose()
  }

  return (
  <>
    {/* 🔽 透明遮罩層：阻擋背景互動，但不影響選單操作 */}
    <div
      style={{
        position: 'fixed',
        top: '-1000px',
        left: '-1000px',
        width: '3000px',
        height: '3000px',
        zIndex: 2499,
        backgroundColor: 'rgba(0,0,0,0.01)',
        cursor: 'default',
        pointerEvents: 'auto',
      }}
      onClick={(e) => e.stopPropagation()}
    />

    {/* 🔽 選單本體容器 */}
    <div
      ref={ringRef}
      style={{
        position: 'fixed',
        top: position.y,
        left: position.x,
        width: '0',
        height: '0',
        zIndex: 2500,
        pointerEvents: 'none',
      }}
      onClick={(e) => e.stopPropagation()}
      onMouseDown={(e) => e.stopPropagation()}
    >
      {/* 標籤提示 */}
      <div
        style={{
          position: 'absolute',
          top: '-35px',
          left: '50%',
          transform: 'translateX(-50%)',
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          padding: '4px 10px',
          borderRadius: '16px',
          fontSize: '12px',
          color: 'white',
          whiteSpace: 'nowrap',
          zIndex: 2501,
          pointerEvents: 'auto',
        }}
      >
        {`${tag} (${fragmentsWithTag}個碎片)`}
      </div>

      {/* 刪除確認視窗 */}
      {showConfirmDelete && (
        <div
          style={{
            position: 'absolute',
            top: '0',
            left: '50%',
            transform: 'translate(-50%, -150%)',
            backgroundColor: '#fff',
            padding: '15px',
            borderRadius: '12px',
            boxShadow: '0 8px 24px rgba(0, 0, 0, 0.2)',
            zIndex: 2501,
            width: '220px',
            textAlign: 'center',
            pointerEvents: 'auto',
          }}
        >
          <div style={{ color: '#333', marginBottom: '10px', fontWeight: 500 }}>
            確定要刪除標籤「{tag}」嗎？
          </div>
          <div style={{ color: '#888', fontSize: '13px', marginBottom: '15px' }}>
            將從所有碎片中移除此標籤。
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: '10px' }}>
            <button
              onClick={() => setShowConfirmDelete(false)}
              style={{
                flex: 1,
                backgroundColor: '#eee',
                border: 'none',
                padding: '8px',
                borderRadius: '8px',
                cursor: 'pointer',
              }}
            >
              取消
            </button>
            <button
              onClick={handleConfirmDelete}
              style={{
                flex: 1,
                backgroundColor: '#ff5555',
                color: 'white',
                border: 'none',
                padding: '8px',
                borderRadius: '8px',
                cursor: 'pointer',
              }}
            >
              確認刪除
            </button>
          </div>
        </div>
      )}

      {/* 環形選單選項 */}
      {options.map((option, index) => {
        // 计算环形位置
        const angle = (2 * Math.PI * index) / options.length - Math.PI / 2
        const left = Math.cos(angle) * RING_RADIUS
        const top = Math.sin(angle) * RING_RADIUS
        
        // 判断是否为选中状态
        const isSelected = selectedIndex === index
        
        return (
            <div
            key={option.label}
            onClick={(e) => {
                e.stopPropagation() // 阻止事件冒泡
                e.preventDefault() // 阻止默认行为
                option.action()
            }}
            onMouseDown={(e) => {
                e.stopPropagation() // 阻止鼠标按下事件冒泡
                e.preventDefault() // 阻止默认行为
            }}
            onMouseEnter={() => setSelectedIndex(index)}
            style={{
                /* 样式保持不变 */
            }}
            >
            <div style={{ fontSize: '16px', marginBottom: '2px' }}>{option.icon}</div>
            <div style={{ fontSize: '10px', textAlign: 'center' }}>{option.label}</div>
            </div>
        )
        })}
    </div>
  </>
)

}

export default TagActionRing