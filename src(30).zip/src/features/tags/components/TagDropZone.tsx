'use client'
// 改进 TagDropZone.tsx 来提供更明显的视觉反馈

import React, { useEffect, useRef, useState } from 'react'
import { useTagDragManager } from '@/features/fragments/layout/useTagDragManager'
import { useTagCollectionStore } from '@/features/tags/store/useTagCollectionStore'

const TagDropZone: React.FC = () => {
  const { draggingTag, isDragging } = useTagDragManager()
  const { isCollected, addTag } = useTagCollectionStore()

  const ref = useRef<HTMLDivElement>(null)
  const [isOver, setIsOver] = useState(false)
  const [showFeedback, setShowFeedback] = useState<{visible: boolean, message: string, success: boolean}>({
    visible: false,
    message: '',
    success: true
  })

  // 用滑鼠位置判断有没有进入 drop 区域
  useEffect(() => {
    const checkHover = (e: MouseEvent) => {
      if (!ref.current) return
      const rect = ref.current.getBoundingClientRect()
      const inside =
        e.clientX >= rect.left &&
        e.clientX <= rect.right &&
        e.clientY >= rect.top &&
        e.clientY <= rect.bottom
      setIsOver(inside)
    }

    if (isDragging) {
      window.addEventListener('mousemove', checkHover)
    } else {
      setIsOver(false)
    }

    return () => window.removeEventListener('mousemove', checkHover)
  }, [isDragging])

  // 放开鼠标时触发收藏
  useEffect(() => {
    const handleMouseUp = () => {
      if (!draggingTag || !isDragging) return
      if (isOver) {
        if (!isCollected(draggingTag)) {
          addTag(draggingTag)
          console.log('✅ 已收藏标签:', draggingTag)
          
          // 显示反馈讯息
          setShowFeedback({
            visible: true,
            message: `已将「${draggingTag}」加入收藏`,
            success: true
          })
          
          // 3秒后隐藏反馈
          setTimeout(() => {
            setShowFeedback(prev => ({...prev, visible: false}))
          }, 3000)
        } else {
          console.log('⚠️ 已经收藏过:', draggingTag)
          
          // 显示反馈讯息
          setShowFeedback({
            visible: true,
            message: `「${draggingTag}」已在收藏中`,
            success: false
          })
          
          // 3秒后隐藏反馈
          setTimeout(() => {
            setShowFeedback(prev => ({...prev, visible: false}))
          }, 3000)
        }
      }
    }

    window.addEventListener('mouseup', handleMouseUp)
    return () => window.removeEventListener('mouseup', handleMouseUp)
  }, [draggingTag, isDragging, isOver, isCollected, addTag])

  if (!isDragging || !draggingTag) return null

  const isAlreadyCollected = isCollected(draggingTag)

  return (
    <>
      <div
        ref={ref}
        style={{
          border: '3px dashed rgba(160, 120, 80, 0.7)', // 更粗更明显的边框
          backgroundColor: isOver 
            ? (isAlreadyCollected ? 'rgba(255, 186, 82, 0.4)' : 'rgba(144, 238, 144, 0.35)')
            : 'rgba(255, 250, 230, 0.15)',
          backdropFilter: 'blur(5px)',
          borderRadius: '16px',
          padding: '28px 40px',
          color: '#7a5d3a',
          fontSize: '16px',
          fontWeight: 600,
          zIndex: 2000,
          pointerEvents: 'auto',
          transition: 'all 0.2s ease',
          boxShadow: isOver ? '0 6px 24px rgba(0,0,0,0.2)' : '0 4px 12px rgba(0,0,0,0.1)',
          textAlign: 'center',
          position: 'relative',
          minWidth: '200px',
          transform: isOver ? 'scale(1.05)' : 'scale(1)',
        }}
      >
        {isOver ? (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
            <span style={{ fontSize: '24px' }}>
              {isAlreadyCollected ? '⚠️' : '✨'}
            </span>
            <span>
              {isAlreadyCollected ? '已收藏此标签' : '添加到收藏集'}
            </span>
          </div>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
            <span style={{ fontSize: '18px' }}>🏷️</span>
            <span>拖曳至此收藏标签</span>
          </div>
        )}
        
        {/* 显示当前拖动的标签名 */}
        <div style={{
          position: 'absolute',
          top: '-30px',
          left: '50%',
          transform: 'translateX(-50%)',
          backgroundColor: 'rgba(70, 70, 70, 0.85)',
          color: 'white',
          padding: '4px 12px',
          borderRadius: '12px',
          fontSize: '12px',
          fontWeight: 'normal',
        }}>
          {draggingTag}
        </div>
      </div>
      
      {/* 反馈讯息 */}
      {showFeedback.visible && (
        <div 
          style={{
            position: 'absolute',
            top: '-60px',
            left: '50%',
            transform: 'translateX(-50%)',
            backgroundColor: showFeedback.success ? 'rgba(60, 179, 113, 0.9)' : 'rgba(255, 165, 0, 0.9)',
            color: 'white',
            padding: '10px 20px',
            borderRadius: '20px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
            fontSize: '14px',
            fontWeight: '500',
            zIndex: 2001,
            animation: 'fade-in-out 3s ease-in-out',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span>{showFeedback.success ? '✅' : '⚠️'}</span>
            <span>{showFeedback.message}</span>
          </div>
        </div>
      )}
      
      {/* 加入动画 */}
      <style jsx global>{`
        @keyframes fade-in-out {
          0% { opacity: 0; transform: translate(-50%, 10px); }
          10% { opacity: 1; transform: translate(-50%, 0); }
          80% { opacity: 1; transform: translate(-50%, 0); }
          100% { opacity: 0; transform: translate(-50%, -10px); }
        }
      `}</style>
    </>
  )
}

export default TagDropZone