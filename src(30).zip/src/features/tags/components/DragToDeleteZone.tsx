'use client'

import React, { useEffect, useState, useRef } from 'react'
import { useTagDragManager } from '@/features/fragments/layout/useTagDragManager'
import { TagsService } from '@/features/tags/services/TagsService'

interface DragToDeleteZoneProps {
  position?: 'bottom-right' | 'top-right' | 'custom'
  customPosition?: { top?: string; right?: string; bottom?: string; left?: string }
}

const DragToDeleteZone: React.FC<DragToDeleteZoneProps> = ({
  position = 'bottom-right',
  customPosition
}) => {
  const { draggingTag, isDragging } = useTagDragManager()
  const zoneRef = useRef<HTMLDivElement>(null)
  const [isOver, setIsOver] = useState(false)
  const [deleteConfirmed, setDeleteConfirmed] = useState(false)
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  
  // 只在拖曳标签时显示
  if (!isDragging || !draggingTag) return null

  // 根据 position 参数决定预设位置
  let positionStyle: React.CSSProperties = {}
  
  switch (position) {
    case 'bottom-right':
      positionStyle = { bottom: '20px', right: '20px' }
      break
    case 'top-right':
      positionStyle = { top: '20px', right: '20px' }
      break
    case 'custom':
      if (customPosition) {
        positionStyle = { ...customPosition }
      }
      break
  }

  // 监听滑鼠移动以检测悬停状态
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!zoneRef.current) return
      
      const rect = zoneRef.current.getBoundingClientRect()
      const isInside = (
        e.clientX >= rect.left &&
        e.clientX <= rect.right &&
        e.clientY >= rect.top &&
        e.clientY <= rect.bottom
      )
      
      setIsOver(isInside)
    }
    
    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [isDragging])

  // 监听滑鼠放开事件
  useEffect(() => {
    const handleMouseUp = () => {
      if (isOver && draggingTag && !deleteConfirmed) {
        // 显示确认对话框而不是直接删除
        setShowConfirmDialog(true)
      }
    }
    
    window.addEventListener('mouseup', handleMouseUp)
    return () => window.removeEventListener('mouseup', handleMouseUp)
  }, [isOver, draggingTag, deleteConfirmed])

  // 执行删除操作
  const confirmDelete = () => {
    if (!draggingTag) return;
    
    setDeleteConfirmed(true);
    setShowConfirmDialog(false);
    
    // 显示删除确认动画
    setTimeout(() => {
      // 调用服务删除标签
      const result = TagsService.deleteTag(draggingTag);
      console.log(`🗑️ ${result.message}`);
      
      // 显示删除成功通知
      showDeleteToast(`已删除标签『${draggingTag}』`, 'success');
      
      // 重置状态
      setDeleteConfirmed(false);
    }, 500);
  };

  // 取消删除操作
  const cancelDelete = () => {
    setShowConfirmDialog(false);
  };

  // 显示删除结果通知
  const showDeleteToast = (message: string, type: 'success' | 'error') => {
    const toast = document.createElement('div');
    toast.innerText = message;
    toast.style.position = 'fixed';
    toast.style.bottom = '20px';
    toast.style.left = '50%';
    toast.style.transform = 'translateX(-50%)';
    toast.style.padding = '10px 16px';
    toast.style.borderRadius = '6px';
    toast.style.backgroundColor = type === 'success' ? '#4caf50' : '#f44336';
    toast.style.color = 'white';
    toast.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
    toast.style.zIndex = '10000';
    toast.style.animation = 'fade-slide-up 3s forwards';
    
    // 添加动画样式
    const style = document.createElement('style');
    style.textContent = `
      @keyframes fade-slide-up {
        0% { opacity: 0; transform: translate(-50%, 20px); }
        10% { opacity: 1; transform: translate(-50%, 0); }
        80% { opacity: 1; transform: translate(-50%, 0); }
        100% { opacity: 0; transform: translate(-50%, -20px); }
      }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(toast);
    
    // 自动移除
    setTimeout(() => {
      document.body.removeChild(toast);
      document.head.removeChild(style);
    }, 3000);
  };

  return (
    <>
      <div
        ref={zoneRef}
        style={{
          position: 'fixed',
          width: '60px',
          height: '60px',
          borderRadius: '50%',
          backgroundColor: isOver ? 'rgba(255, 50, 50, 0.95)' : 'rgba(255, 150, 150, 0.7)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: isOver 
            ? '0 0 20px rgba(255, 0, 0, 0.5), 0 0 10px rgba(255, 150, 150, 0.3)'
            : '0 0 10px rgba(0, 0, 0, 0.2)',
          transition: 'all 0.2s ease',
          transform: isOver ? 'scale(1.25)' : 'scale(1)',
          zIndex: 9999,
          cursor: 'pointer',
          ...positionStyle
        }}
      >
        <div
          style={{
            fontSize: deleteConfirmed ? '24px' : '22px',
            color: '#fff',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            textAlign: 'center',
          }}
        >
          {deleteConfirmed ? '✓' : '🗑️'}
        </div>
        <div style={{ 
          fontSize: '10px', 
          color: 'white',
          marginTop: '3px',
          fontWeight: isOver ? 'bold' : 'normal'
        }}>
          {isOver ? '删除标签' : '拖放至此删除'}
        </div>
      </div>

      {/* 确认删除对话框 */}
      {showConfirmDialog && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 10000,
          backdropFilter: 'blur(3px)',
        }}>
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '24px',
            boxShadow: '0 8px 30px rgba(0, 0, 0, 0.3)',
            width: '300px',
            animation: 'dialog-appear 0.3s ease',
          }}>
            <h3 style={{ 
              margin: '0 0 16px 0', 
              color: '#e53935', 
              fontSize: '18px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span>🗑️</span> 确认删除标签
            </h3>
            <p style={{ margin: '16px 0', color: '#555', fontSize: '14px' }}>
              您确定要删除标签 <strong style={{ color: '#333' }}>"{draggingTag}"</strong> 吗？此操作将从所有碎片中移除该标签。
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '24px' }}>
              <button 
                onClick={cancelDelete}
                style={{
                  padding: '8px 16px',
                  borderRadius: '6px',
                  border: '1px solid #ddd',
                  backgroundColor: '#f5f5f5',
                  color: '#555',
                  cursor: 'pointer',
                }}
              >
                取消
              </button>
              <button 
                onClick={confirmDelete}
                style={{
                  padding: '8px 16px',
                  borderRadius: '6px',
                  border: 'none',
                  backgroundColor: '#e53935',
                  color: 'white',
                  cursor: 'pointer',
                  boxShadow: '0 2px 5px rgba(229, 57, 53, 0.3)',
                }}
              >
                确认删除
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 添加动画样式 */}
      <style jsx global>{`
        @keyframes dialog-appear {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </>
  )
}

export default DragToDeleteZone