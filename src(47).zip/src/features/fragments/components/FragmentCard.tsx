'use client'

import React, { useState, useMemo, useCallback } from 'react'
import { 
  GridFragment, 
  GridPosition,
  PixelPosition 
} from '@/features/fragments/types/gridTypes'
import { gridToPixel } from '@/features/fragments/layout/useLayoutFragments'
import { truncateText, formatDate } from '@/features/fragments/utils'
import { GRID_SIZE } from '@/features/fragments/constants'
import TagButton from './TagButton'
import TagActionRing from '@/features/tags/components/TagActionRing'
import TagDetailModal from '@/features/tags/components/TagDetailModal'
import { useTagDragManager } from '@/features/fragments/layout/useTagDragManager'
import { TagsService } from '@/features/tags/services/TagsService'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { useHoverScrollbar } from '@/features/interaction/useHoverScrollbar'

// 常量定義
const MAX_TAGS_COUNT = 20
const MIN_FONT_SIZE = 12
const CONTENT_NOTE_SPACING_RATIO = 0.4
const BUTTON_HEIGHT = 22

interface FragmentCardProps {
  fragment: GridFragment
  isSelected: boolean
  isDragging: boolean
  dragPosition: PixelPosition
  isValidDragTarget: boolean
  previewPosition?: GridPosition
  validationState: 'valid' | 'invalid-but-has-fallback' | 'completely-invalid'
  onFragmentClick: (fragment: GridFragment) => void
  onDragStart: (e: React.MouseEvent, fragment: GridFragment) => void
  observerRef?: React.RefObject<HTMLDivElement>
  onTagClick?: (tag: string, fragment: GridFragment) => void
  onTagDragStart?: (e: React.MouseEvent, tag: string, fragment: GridFragment) => void
}

// 自定義 hooks (保持不變)
const useCardDimensions = (fragment: GridFragment, isDragging: boolean, dragPosition: PixelPosition, previewPosition?: GridPosition) => {
  return useMemo(() => {
    const effectivePosition = previewPosition || fragment.position
    const { top, left } = isDragging ? dragPosition : gridToPixel(effectivePosition)
    const width = fragment.size.width * GRID_SIZE
    const height = fragment.size.height * GRID_SIZE
    
    return { top, left, width, height }
  }, [fragment.position, fragment.size, isDragging, dragPosition, previewPosition])
}

const useContentCalculation = (fragment: GridFragment, width: number, height: number) => {
  return useMemo(() => {
    const { fontSize, direction } = fragment
    
    const maxVisibleChars = direction === 'horizontal'
      ? Math.max(50, Math.floor((height - 100) / (fontSize * 1.4)) * Math.floor((width - 40) / (fontSize * 0.6)))
      : Math.max(50, Math.floor((width - 80) / (fontSize * 1.6)) * Math.floor((height - 40) / (fontSize * 1.1)))
    
    const noteVisibleLines = direction === 'horizontal' ? 3 : 10
    const estimatedCharsPerLine = Math.floor((width - 40) / (fontSize * 0.6))
    const estimatedNoteChars = noteVisibleLines * estimatedCharsPerLine
    
    const contentNoteSpacing = Math.max(4, Math.min(8, Math.floor(fontSize * CONTENT_NOTE_SPACING_RATIO)))
    
    return {
      maxVisibleChars,
      estimatedNoteChars,
      contentNoteSpacing
    }
  }, [fragment.fontSize, fragment.direction, width, height])
}

const useCardStyles = (isDragging: boolean, isSelected: boolean, previewPosition?: GridPosition) => {
  const zIndex = useMemo(() => {
    if (isDragging) return 1000
    if (isSelected) return 100
    if (previewPosition) return 50
    return 1
  }, [isDragging, isSelected, previewPosition])
  
  const transitionStyle = useMemo(() => {
    if (isDragging) return 'none'
    if (previewPosition) return 'all 0.15s cubic-bezier(0.4, 0, 0.2, 1)'
    return 'transform 0.2s, box-shadow 0.2s'
  }, [isDragging, previewPosition])
  
  const boxShadow = useMemo(() => {
    if (isDragging) return '0 12px 28px rgba(0, 0, 0, 0.25)'
    if (isSelected) return '0 4px 16px rgba(0, 0, 0, 0.15)'
    if (previewPosition) return '0 6px 20px rgba(0, 0, 0, 0.12)'
    return '0 2px 8px rgba(0, 0, 0, 0.06)'
  }, [isDragging, isSelected, previewPosition])
  
  return { zIndex, transitionStyle, boxShadow }
}

// 滾動條樣式生成函數 - 使用 CSS class 而不是偽元素
const getScrollbarStyle = (hovering: boolean): React.CSSProperties => ({
  scrollbarWidth: hovering ? 'thin' : 'none',
  scrollbarColor: hovering ? '#ccc transparent' : 'transparent',
  // 使用標準的 CSS 屬性，偽元素通過 className 處理
})

// 修改後的子組件
const ContentSection = ({ 
  fragment, 
  displayedContent, 
  showMoreContent, 
  maxHeight,
  style = {},
  scrollbarBind,
  scrollbarHovering
}: {
  fragment: GridFragment
  displayedContent: string
  showMoreContent: boolean
  maxHeight: string
  style?: React.CSSProperties
  scrollbarBind?: any
  scrollbarHovering?: boolean
}) => {
  if (fragment.showContent === false) return null
  
  return (
    <div 
      {...scrollbarBind} // 綁定滾動條事件
      className={scrollbarHovering ? 'hover-scrollbar-visible' : 'hover-scrollbar-hidden'}
      style={{
        overflowWrap: 'break-word',
        overflow: showMoreContent ? 'auto' : 'hidden',
        fontSize: `${fragment.fontSize}px`,
        lineHeight: '1.4',
        color: '#333',
        maxHeight,
        display: 'block',
        paddingRight: scrollbarHovering ? '8px' : '0', // 懸浮時留空間
        transition: 'padding-right 0.2s ease',
        ...getScrollbarStyle(scrollbarHovering || false), // 動態滾動條
        ...style
      }}
    >
      {displayedContent}
    </div>
  )
}

const NotesSection = ({ 
  fragment, 
  displayedNote, 
  showMoreNote, 
  maxHeight,
  scrollbarBind,
  scrollbarHovering
}: {
  fragment: GridFragment
  displayedNote: string
  showMoreNote: boolean
  maxHeight: string
  scrollbarBind?: any
  scrollbarHovering?: boolean
}) => {
  const showNotes = fragment.showNote !== false && fragment.notes && fragment.notes.length > 0
  if (!showNotes || !displayedNote) return null
  
  return (
    <div
      {...scrollbarBind} // 綁定滾動條事件
      className={scrollbarHovering ? 'hover-scrollbar-visible' : 'hover-scrollbar-hidden'}
      style={{
        overflow: showMoreNote ? 'auto' : 'hidden',
        maxHeight,
        transition: 'max-height 0.3s ease',
        fontSize: `${Math.max(MIN_FONT_SIZE, fragment.fontSize - 2)}px`,
        color: '#666',
        paddingRight: scrollbarHovering ? '6px' : '0', // 懸浮時留空間
        ...getScrollbarStyle(scrollbarHovering || false), // 動態滾動條
      }}
    >
      {fragment.notes[0]?.title && (
        <div style={{
          fontSize: '11px',
          fontWeight: 'bold',
          color: '#333',
          marginBottom: '2px',
        }}>
          {fragment.notes[0].title}
        </div>
      )}
      <div
        style={{
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          display: '-webkit-box',
          WebkitBoxOrient: 'vertical',
          WebkitLineClamp: showMoreNote ? 'unset' : 10,
          whiteSpace: showMoreNote ? 'normal' : 'pre-line',
        }}
      >
        {displayedNote}
      </div>
    </div>
  )
}

const ControlButtons = ({ 
  needContentExpand, 
  needNoteExpand, 
  showMoreContent, 
  showMoreNote, 
  onToggleContent, 
  onToggleNote,
  isVertical = false,
  contentHovering = false,
  noteHovering = false
}: {
  needContentExpand: boolean
  needNoteExpand: boolean
  showMoreContent: boolean
  showMoreNote: boolean
  onToggleContent: (e: React.MouseEvent) => void
  onToggleNote: (e: React.MouseEvent) => void
  isVertical?: boolean
  contentHovering?: boolean
  noteHovering?: boolean
}) => {
  if (!needContentExpand && !needNoteExpand) return null
  
  const buttonStyle: React.CSSProperties = {
    border: 'none',
    background: 'rgba(255, 251, 239, 0.8)',
    color: '#666',
    fontSize: '11px',
    cursor: 'pointer',
    padding: isVertical ? '4px 2px' : '2px 6px',
    borderRadius: '4px',
    transition: 'all 0.2s ease',
    opacity: contentHovering || noteHovering ? 1 : 0.7, // 懸浮時更明顯
    ...(isVertical && {
      writingMode: 'vertical-rl',
      textOrientation: 'upright'
    })
  }
  
  const containerStyle: React.CSSProperties = isVertical 
    ? {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'flex-end',
        height: '100%',
        marginLeft: '4px',
        marginRight: '4px',
        width: '20px',
      }
    : {
        display: 'flex',
        justifyContent: 'flex-start',
        flexWrap: 'wrap',
        gap: '6px',
        height: `${BUTTON_HEIGHT}px`,
        marginTop: '6px',
        marginBottom: '6px',
      }
  
  return (
    <div style={containerStyle}>
      {needNoteExpand && (
        <button
          onClick={onToggleNote}
          style={{
            ...buttonStyle,
            marginBottom: isVertical ? '4px' : '0',
            opacity: noteHovering ? 1 : buttonStyle.opacity, // 筆記區懸浮時高亮
          }}
        >
          {showMoreNote ? '收合' : '更多'}
        </button>
      )}
      {needContentExpand && (
        <button
          onClick={onToggleContent}
          style={{
            ...buttonStyle,
            marginBottom: '0',
            opacity: contentHovering ? 1 : buttonStyle.opacity, // 內容區懸浮時高亮
          }}
        >
          {showMoreContent ? '收合' : '更多'}
        </button>
      )}
    </div>
  )
}

const TagsSection = ({ 
  tags, 
  onTagClick, 
  onTagDragStart, 
  isVertical = false 
}: {
  tags: string[]
  onTagClick: (tagName: string, e: React.MouseEvent) => void
  onTagDragStart: (e: React.MouseEvent, tagName: string) => void
  isVertical?: boolean
}) => {
  if (!tags.length) return null
  
  const containerStyle: React.CSSProperties = isVertical
    ? {
        display: 'flex',
        flexDirection: 'column',
        flexWrap: 'wrap',
        direction: 'rtl',
        gap: '4px',
        height: '100%',
        justifyContent: 'flex-start',
        overflow: 'auto',
        width: 'auto',
        minWidth: '30px',
        maxWidth: '120px',
        paddingRight: '8px',
      }
    : {
        display: 'flex',
        flexWrap: 'wrap',
        gap: '4px',
        justifyContent: 'flex-start',
        maxHeight: '60px',
        overflow: 'hidden',
        flex: 'none',
        paddingTop: '4px',
        marginTop: '5px',
      }
  
  return (
    <div style={containerStyle}>
      {tags.map(tag => (
        <TagButton
          key={tag}
          tag={tag}
          style={isVertical ? {
            writingMode: 'vertical-rl',
            textOrientation: 'upright',
            maxHeight: '60px',
            flexShrink: 0,
          } : undefined}
          onTagClick={onTagClick}
          onTagDragStart={onTagDragStart}
        />
      ))}
    </div>
  )
}

// 主組件
const FragmentCard = ({
  fragment,
  isSelected,
  isDragging,
  dragPosition,
  isValidDragTarget,
  previewPosition,
  validationState,
  onFragmentClick,
  onDragStart,
  observerRef,
  onTagClick,
  onTagDragStart,
}: FragmentCardProps) => {
  // 狀態管理
  const [showMoreContent, setShowMoreContent] = useState(false)
  const [showMoreNote, setShowMoreNote] = useState(false)
  const [clickedTag, setClickedTag] = useState<string | null>(null)
  const [tagActionPosition, setTagActionPosition] = useState<{ x: number; y: number } | null>(null)
  const [showTagDetail, setShowTagDetail] = useState(false)
  const [detailTag, setDetailTag] = useState<string | null>(null)
  
  // 外部依賴
  const { startTagDrag, wasDraggingRef } = useTagDragManager()
  const { fragments } = useFragmentsStore()
  
  // 計算相關數據
  const { top, left, width, height } = useCardDimensions(fragment, isDragging, dragPosition, previewPosition)
  const { maxVisibleChars, estimatedNoteChars, contentNoteSpacing } = useContentCalculation(fragment, width, height)
  const { zIndex, transitionStyle, boxShadow } = useCardStyles(isDragging, isSelected, previewPosition)
  
  // 內容處理
  const displayedContent = showMoreContent ? fragment.content : truncateText(fragment.content, maxVisibleChars)
  const noteText = fragment.showNote !== false && fragment.notes?.length ? fragment.notes[0]?.value || '' : ''
  const displayedNote = showMoreNote ? noteText : truncateText(noteText, estimatedNoteChars)
  const tags = fragment.tags.slice(0, MAX_TAGS_COUNT)
  
  // 判斷是否需要展開按鈕
  const needContentExpand = fragment.content.length > maxVisibleChars
  const needNoteExpand = noteText.length > estimatedNoteChars
  const needButtonSpace = needContentExpand || needNoteExpand

  // 為內容區域和筆記區域分別創建 hover scrollbar
  const contentScrollbar = useHoverScrollbar(15)
  const noteScrollbar = useHoverScrollbar(15)
  
  // 事件處理
  const handleTagClick = useCallback((tagName: string, e: React.MouseEvent) => {
    e.stopPropagation()
    
    if (wasDraggingRef.current) return
    
    if (showTagDetail) {
      setShowTagDetail(false)
      setDetailTag(null)
    }
    
    const rect = e.currentTarget.getBoundingClientRect()
    setClickedTag(tagName)
    setTagActionPosition({
      x: rect.left + rect.width / 2,
      y: rect.top
    })
    
    onTagClick?.(tagName, fragment)
  }, [wasDraggingRef, showTagDetail, onTagClick, fragment])
  
  const handleTagDragStart = useCallback((e: React.MouseEvent, tagName: string) => {
    e.stopPropagation()
    startTagDrag(tagName, e, fragment.id)
    onTagDragStart?.(e, tagName, fragment)
  }, [startTagDrag, fragment.id, onTagDragStart])
  
  const handleDeleteTag = useCallback((tagName: string) => {
    const isConfirmed = window.confirm(`確定要從所有碎片中刪除標籤「${tagName}」嗎？此操作無法撤銷。`)
    
    if (isConfirmed) {
      TagsService.deleteTag(tagName, fragments).then(result => {
        if (result.success) {
          console.log(`🗑️ ${result.message}`)
        }
      })
    }
  }, [fragments])
  
  const handleCloseTagDetail = useCallback(() => {
    setShowTagDetail(false)
    setDetailTag(null)
    setClickedTag(null)
    setTagActionPosition(null)
  }, [])
  
  const handleToggleContent = useCallback((e: React.MouseEvent) => {
    e.stopPropagation()
    setShowMoreContent(!showMoreContent)
  }, [showMoreContent])
  
  const handleToggleNote = useCallback((e: React.MouseEvent) => {
    e.stopPropagation()
    setShowMoreNote(!showMoreNote)
  }, [showMoreNote])
  
  // 渲染邏輯
  const renderVerticalLayout = () => (
    <div style={{ display: 'flex', flexDirection: 'row', height: '100%', width: '100%' }}>
      {/* 標籤區域 */}
      {fragment.showTags !== false && (
        <TagsSection 
          tags={tags} 
          onTagClick={handleTagClick} 
          onTagDragStart={handleTagDragStart} 
          isVertical 
        />
      )}
      
      {/* 控制按鈕 */}
      <ControlButtons
        needContentExpand={needContentExpand}
        needNoteExpand={needNoteExpand}
        showMoreContent={showMoreContent}
        showMoreNote={showMoreNote}
        onToggleContent={handleToggleContent}
        onToggleNote={handleToggleNote}
        isVertical
        contentHovering={contentScrollbar.hovering}
        noteHovering={noteScrollbar.hovering}
      />
      
      {/* 筆記區域 */}
      <NotesSection
        fragment={fragment}
        displayedNote={displayedNote}
        showMoreNote={showMoreNote}
        maxHeight={showMoreNote ? `${height - 80}px` : `${Math.floor((height - 100) / (fragment.fontSize * 1.4)) * fragment.fontSize * 1.4}px`}
        scrollbarBind={noteScrollbar.bind}
        scrollbarHovering={noteScrollbar.hovering}
      />
      
      {/* 主內容區域 */}
      <ContentSection
        fragment={fragment}
        displayedContent={displayedContent}
        showMoreContent={showMoreContent}
        maxHeight={showMoreContent ? `${height * 0.6}px` : `${height * 0.4}px`}
        style={{
          writingMode: 'vertical-rl',
          textOrientation: 'mixed',
          height: '100%',
          flex: '2',
          minWidth: '30%',
          marginLeft: `${contentNoteSpacing}px`,
          paddingBottom: '8px',
        }}
        scrollbarBind={contentScrollbar.bind}
        scrollbarHovering={contentScrollbar.hovering}
      />
    </div>
  )
  
  const renderHorizontalLayout = () => (
    <>
      {/* 內容容器 */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: `${contentNoteSpacing}px` }}>
        {/* 主內容 */}
        <ContentSection
          fragment={fragment}
          displayedContent={displayedContent}
          showMoreContent={showMoreContent}
          maxHeight={showMoreContent ? `${height * 0.6}px` : `${height * 0.4}px`}
          style={{
            flex: '0 1 auto',
            borderBottom: noteText ? '1px dotted #eee' : 'none',
          }}
          scrollbarBind={contentScrollbar.bind}
          scrollbarHovering={contentScrollbar.hovering}
        />
        
        {/* 筆記區域 */}
        <NotesSection
          fragment={fragment}
          displayedNote={displayedNote}
          showMoreNote={showMoreNote}
          maxHeight={showMoreNote ? `${height - 80}px` : `${Math.floor((height - 100) / (fragment.fontSize * 1.4)) * fragment.fontSize * 1.4}px`}
          scrollbarBind={noteScrollbar.bind}
          scrollbarHovering={noteScrollbar.hovering}
        />
      </div>
      
      {/* 控制按鈕 */}
      <ControlButtons
        needContentExpand={needContentExpand}
        needNoteExpand={needNoteExpand}
        showMoreContent={showMoreContent}
        showMoreNote={showMoreNote}
        onToggleContent={handleToggleContent}
        onToggleNote={handleToggleNote}
        contentHovering={contentScrollbar.hovering}
        noteHovering={noteScrollbar.hovering}
      />
      
      {/* 標籤區域 */}
      {fragment.showTags !== false && (
        <TagsSection 
          tags={tags} 
          onTagClick={handleTagClick} 
          onTagDragStart={handleTagDragStart} 
        />
      )}
    </>
  )
  
  return (
    <div
      ref={observerRef}
      data-fragment-id={fragment.id}
      onClick={() => onFragmentClick(fragment)}
      onMouseDown={(e) => onDragStart(e, fragment)}
      className={`fragment-card ${isDragging ? 'is-dragging' : ''} ${previewPosition ? 'is-previewing' : ''}`}
      style={{
        position: 'absolute',
        top: `${top}px`,
        left: `${left}px`,
        width: `${width}px`,
        height: `${height}px`,
        padding: '12px',
        backgroundColor: '#fffbef',
        borderRadius: '10px',
        boxShadow,
        border: previewPosition ? '1px solid rgba(50, 120, 200, 0.3)' : '1px solid rgba(0, 0, 0, 0.05)',
        transform: isSelected && !isDragging ? 'scale(1.02)' : 'none',
        cursor: isDragging ? 'grabbing' : 'grab',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: fragment.direction === 'vertical' ? 'row' : 'column',
        transition: transitionStyle,
        zIndex,
        opacity: isDragging ? (validationState === 'valid' ? 1 : 0.4) : 1
      }}
    >
      {fragment.direction === 'vertical' ? renderVerticalLayout() : renderHorizontalLayout()}
      
      {/* 日期顯示 */}
      {isSelected && (
        <div 
          style={{
            position: 'absolute',
            bottom: '4px',
            right: '6px',
            fontSize: '9px',
            color: '#aaa',
            writingMode: fragment.direction === 'vertical' ? 'vertical-rl' : 'horizontal-tb',
          }}
        >
          {formatDate(fragment.createdAt)}
        </div>
      )}
      
      {/* 標籤操作環 */}
      {clickedTag && tagActionPosition && (
        <TagActionRing
          tag={clickedTag}
          position={tagActionPosition}
          onClose={() => {
            setClickedTag(null)
            setTagActionPosition(null)
          }}
          onOpenDetail={(tag) => {
            setDetailTag(tag)
            setShowTagDetail(true)
            setClickedTag(null)
            setTagActionPosition(null)
          }}
          fragmentId={fragment.id}
        />
      )}

      {/* 標籤詳情彈窗 */}
      {showTagDetail && detailTag && (
        <TagDetailModal
          tag={detailTag}
          relatedFragments={TagsService.findFragmentsByTag(fragments, detailTag)}
          onClose={handleCloseTagDetail}
        />
      )}
    </div>
  )
}

export default FragmentCard