// FragmentsGridView.tsx
'use client'

import React, { useState, useMemo, useCallback, memo, useRef, useEffect } from 'react'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { Fragment } from '@/features/fragments/types/fragment'
import { 
  PixelPosition, 
  GridFragment, 
  RelevanceMap 
} from '@/features/fragments/types/gridTypes'
import FragmentDetailModal from './FragmentDetailModal'
import { 
  useLayoutFragments, 
  createDirectionMap,
  gridToPixel,
} from '@/features/fragments/layout/useLayoutFragments'
import { useDragFragment } from '@/features/fragments/layout/useDragFragment'
import { 
  GRID_SIZE,
  MAX_CONTENT_LENGTH,
  MAX_NOTE_LENGTH,
  MAX_TAGS_COUNT,
  CONTAINER_WIDTH
} from '@/features/fragments/constants'
import { truncateText, formatDate } from '@/features/fragments/utils'

type PositionsMap = Record<string, { row: number, col: number }>;

// 單個碎片卡片組件
const FragmentCard = memo(({
  fragment,
  isSelected,
  isDragging,
  dragPosition,
  isValidDragTarget,
  onFragmentClick,
  onDragStart,
  observerRef,
}: {
  fragment: GridFragment
  isSelected: boolean
  isDragging: boolean
  dragPosition: PixelPosition
  isValidDragTarget: boolean // 新增參數：拖曳目標是否有效
  onFragmentClick: (fragment: GridFragment) => void
  onDragStart: (e: React.MouseEvent, fragment: GridFragment) => void
  observerRef?: React.RefObject<HTMLDivElement>
}) => {
  const { position, size, direction, fontSize } = fragment
  const [showMoreContent, setShowMoreContent] = useState(false)
  const [showMoreNote, setShowMoreNote] = useState(false)
  
  // 計算像素位置
  const { top, left } = isDragging 
    ? dragPosition 
    : gridToPixel(position)
  
  const width = size.width * GRID_SIZE
  const height = size.height * GRID_SIZE
  
  // 確定是否顯示筆記內容
  const showNotes = fragment.showNote !== false && fragment.notes && fragment.notes.length > 0
  
  // 計算可顯示的內容長度（基於卡片尺寸）
  const maxVisibleChars = useMemo(() => {
    if (direction === 'horizontal') {
      // 橫排時，計算可見行數
      const availableHeight = height - 100; // 增加邊距，扣除標籤和邊距
      const lineHeight = fontSize * 1.4;
      const maxLines = Math.floor(availableHeight / lineHeight);
      const charsPerLine = Math.floor((width - 40) / (fontSize * 0.6));
      return Math.max(50, maxLines * charsPerLine);
    } else {
      // 豎排時，計算可見列數
      const availableWidth = width - 80; // 增加邊距，扣除標籤和邊距
      const columnWidth = fontSize * 1.6;
      const maxColumns = Math.floor(availableWidth / columnWidth);
      const charsPerColumn = Math.floor((height - 40) / (fontSize * 1.1));
      return Math.max(50, maxColumns * charsPerColumn);
    }
  }, [width, height, fontSize, direction])
  
  // 處理內容截斷
  const content = showMoreContent ? fragment.content : truncateText(fragment.content, maxVisibleChars)
  const noteText = showNotes ? fragment.notes[0]?.value || '' : ''
  const note = showMoreNote ? noteText : truncateText(noteText, Math.floor(maxVisibleChars * 0.6))
  const tags = fragment.tags.slice(0, MAX_TAGS_COUNT)
  
  // 判斷是否需要展開按鈕
  const needContentExpand = fragment.content.length > maxVisibleChars
  const needNoteExpand = noteText.length > Math.floor(maxVisibleChars * 0.6)

  return (
    <div
      ref={observerRef}
      data-fragment-id={fragment.id}
      onClick={() => onFragmentClick(fragment)}
      onMouseDown={(e) => onDragStart(e, fragment)}
      className={`fragment-card ${isDragging ? 'z-50' : isSelected ? 'z-10' : 'z-1'}`}
      style={{
        position: 'absolute',
        top: `${top}px`,
        left: `${left}px`,
        width: `${width}px`,
        height: `${height}px`,
        padding: '12px',
        backgroundColor: '#fffbef',
        borderRadius: '10px',
        boxShadow: isDragging
          ? '0 8px 24px rgba(0, 0, 0, 0.15)'
          : isSelected 
          ? '0 4px 16px rgba(0, 0, 0, 0.1)' 
          : '0 2px 8px rgba(0, 0, 0, 0.06)',
        border: isDragging 
          ? (isValidDragTarget ? '2px solid rgba(0, 200, 0, 0.5)' : '2px solid rgba(255, 0, 0, 0.5)') 
          : '1px solid rgba(0, 0, 0, 0.05)',
        transform: isSelected && !isDragging ? 'scale(1.02)' : 'none',
        cursor: isDragging ? 'grabbing' : 'grab',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: direction === 'vertical' ? 'row' : 'column',
        transition: isDragging ? 'none' : 'transform 0.2s, box-shadow 0.2s'
      }}
    >
      {direction === 'vertical' ? (
        <>
          {/* 主內容區域（右） */}
          <div 
            style={{
              writingMode: 'vertical-rl',
              textOrientation: 'mixed',
              height: '100%',
              overflowWrap: 'break-word',
              overflow: 'hidden',
              fontSize: `${fontSize}px`,
              lineHeight: '1.4',
              color: '#333',
              order: 3,
              marginLeft: '10px',
              flex: 1,
              minWidth: 0,
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            {fragment.showContent !== false && (
              <div style={{ 
                overflow: 'hidden', 
                textOverflow: 'ellipsis',
                wordBreak: 'break-all',
                flex: 1,
                marginBottom: fragment.showTags !== false && tags.length > 0 ? '20px' : '0', // 與標籤間距
              }}>
                {content}
                {needContentExpand && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      setShowMoreContent(!showMoreContent)
                    }}
                    style={{
                      border: 'none',
                      background: 'none',
                      color: '#666',
                      fontSize: '12px',
                      cursor: 'pointer',
                      padding: '2px 0',
                      writingMode: 'vertical-rl'
                    }}
                  >
                    {showMoreContent ? '收起' : '...更多'}
                  </button>
                )}
              </div>
            )}
          </div>
          
          {/* 筆記內容（中） */}
          {showNotes && note && (
            <div 
              style={{ 
                writingMode: 'vertical-rl',
                textOrientation: 'mixed',
                fontSize: `${Math.max(12, fontSize - 2)}px`, 
                color: '#666',
                height: '100%',
                overflowWrap: 'break-word',
                overflow: 'hidden',
                order: 2,
                marginLeft: '10px',
                flex: 1,
                minWidth: 0,
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              <div style={{ 
                overflow: 'hidden', 
                textOverflow: 'ellipsis',
                wordBreak: 'break-all',
                flex: 1,
                marginBottom: fragment.showTags !== false && tags.length > 0 ? '20px' : '0', // 與標籤間距
              }}>
                {fragment.notes[0]?.title && (
                  <div style={{
                    fontSize: '12px', 
                    fontWeight: 'bold', 
                    color: '#333', 
                    marginBottom: '4px'
                  }}>
                    {fragment.notes[0]?.title}
                  </div>
                )}
                {note}
                {needNoteExpand && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      setShowMoreNote(!showMoreNote)
                    }}
                    style={{
                      border: 'none',
                      background: 'none',
                      color: '#666',
                      fontSize: '11px',
                      cursor: 'pointer',
                      padding: '2px 0',
                      writingMode: 'vertical-rl'
                    }}
                  >
                    {showMoreNote ? '收起' : '...更多'}
                  </button>
                )}
              </div>
            </div>
          )}
          
          {/* 標籤區域（左） */}
          {fragment.showTags !== false && tags.length > 0 && (
            <div 
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '4px',
                height: '100%',
                order: 1,
                justifyContent: 'flex-start',
                overflow: 'hidden',
                minWidth: '30px',
                paddingRight: '8px',
              }}
            >
              {tags.map(tag => (
                <span
                  key={tag}
                  style={{
                    backgroundColor: '#f3e8c7',
                    color: '#8d6a38',
                    borderRadius: '12px',
                    padding: '6px 3px',
                    fontSize: '10px',
                    whiteSpace: 'nowrap',
                    display: 'inline-block',
                    writingMode: 'vertical-rl',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    maxHeight: '60px'
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
        </>
      ) : (
        // 橫排模式
        <>
          {/* 內容區域容器 */}
          <div 
            style={{
              flex: 1,
              minHeight: 0,
              display: 'flex',
              flexDirection: 'column',
              marginBottom: fragment.showTags !== false && tags.length > 0 ? '16px' : '0', // 確保與標籤有間距
            }}
          >
            {/* 主內容區域 */}
            <div 
              style={{
                overflowWrap: 'break-word',
                overflow: 'hidden',
                fontSize: `${fontSize}px`,
                lineHeight: '1.4',
                color: '#333',
                flex: 1,
                minHeight: 0,
              }}
            >
              {fragment.showContent !== false && (
                <div style={{ 
                  overflow: 'hidden', 
                  textOverflow: 'ellipsis',
                  wordBreak: 'break-all',
                  marginBottom: showNotes && note ? '12px' : '0',
                }}>
                  {content}
                  {needContentExpand && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        setShowMoreContent(!showMoreContent)
                      }}
                      style={{
                        border: 'none',
                        background: 'none',
                        color: '#666',
                        fontSize: '12px',
                        cursor: 'pointer',
                        padding: '2px 0',
                        display: 'block'
                      }}
                    >
                      {showMoreContent ? '收起' : '...更多'}
                    </button>
                  )}
                </div>
              )}
              
              {/* 筆記區域 */}
              {showNotes && note && (
                <div style={{ 
                  fontSize: `${Math.max(12, fontSize - 2)}px`, 
                  color: '#666',
                  overflow: 'hidden',
                }}>
                  {fragment.notes[0]?.title && (
                    <div style={{
                      fontSize: '11px', 
                      fontWeight: 'bold', 
                      color: '#333', 
                      marginBottom: '2px'
                    }}>
                      {fragment.notes[0]?.title}
                    </div>
                  )}
                  <div style={{ 
                    overflow: 'hidden', 
                    textOverflow: 'ellipsis',
                    wordBreak: 'break-all'
                  }}>
                    {note}
                    {needNoteExpand && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          setShowMoreNote(!showMoreNote)
                        }}
                        style={{
                          border: 'none',
                          background: 'none',
                          color: '#666',
                          fontSize: '11px',
                          cursor: 'pointer',
                          padding: '2px 0',
                          display: 'block'
                        }}
                      >
                        {showMoreNote ? '收起' : '...更多'}
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* 標籤區域 */}
          {fragment.showTags !== false && tags.length > 0 && (
            <div 
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '4px',
                justifyContent: 'flex-start',
                maxHeight: '60px',
                overflow: 'hidden',
                flex: 'none', // 確保標籤區不會縮放
                paddingTop: '4px', // 與內容間距
              }}
            >
              {tags.map(tag => (
                <span
                  key={tag}
                  style={{
                    backgroundColor: '#f3e8c7',
                    color: '#8d6a38',
                    borderRadius: '12px',
                    padding: '2px 6px',
                    fontSize: '10px',
                    whiteSpace: 'nowrap',
                    display: 'inline-block',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    maxWidth: '100px'
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
        </>
      )}
      
      {/* 展開碎片後才顯示日期 */}
      {isSelected && (
        <div 
          style={{
            position: 'absolute',
            bottom: '4px',
            right: '6px',
            fontSize: '9px',
            color: '#aaa',
            writingMode: direction === 'vertical' ? 'vertical-rl' : 'horizontal-tb',
          }}
        >
          {formatDate(fragment.createdAt)}
        </div>
      )}
    </div>
  )
})

FragmentCard.displayName = 'FragmentCard'

// 持久化儲存的本地緩存鍵
const STORAGE_KEY_POSITIONS = 'fragment_positions';

/**
 * 自由拖曳的碎片網格，支持智能布局和換行 - 徹底修復版本
 */

export default function FragmentsGridView({ 
  
  fragments, 
  relevanceMap = {} 
}: { 
  fragments: Fragment[], 
  relevanceMap?: RelevanceMap 
}) {
  const { setSelectedFragment } = useFragmentsStore()
  const [selectedFragment, setSelectedFragmentState] = useState<Fragment | null>(null)
  const [positions, setPositions] = useState<PositionsMap>({})
  const positionsRef = useRef<PositionsMap>({})
  const [, forceUpdate] = useState({})
  const containerRef = useRef<HTMLDivElement>(null)
  const isInitialLoadRef = useRef(true)
  
  // 使用 useMemo 創建方向映射，避免每次渲染重新計算
  const directionMap = useMemo(() => createDirectionMap(fragments), [fragments]);
  
  // 從 localStorage 加載位置信息 - 使用 useEffect 確保只在客戶端執行
  useEffect(() => {
    if (!isInitialLoadRef.current) return;
    
    try {
      const savedPositions = localStorage.getItem(STORAGE_KEY_POSITIONS);
      if (savedPositions) {
        const loadedPositions = JSON.parse(savedPositions);
        setPositions(loadedPositions);
        positionsRef.current = loadedPositions;
        console.log('從 localStorage 加載位置:', Object.keys(loadedPositions).length);
      }
    } catch (error) {
      console.error('加載位置出錯:', error);
    }
    
    isInitialLoadRef.current = false;
  }, []);
  
  // 使用 useLayoutFragments 計算網格布局
  const { gridFragments, newPositions } = useLayoutFragments(
  fragments,
  positions, 
  relevanceMap,
  directionMap
  )
  
  // 使用 useDragFragment 處理拖曳功能 - 獲取新增的 isValidDragTarget
  const { draggingId, dragPosition, handleDragStart, isDragging, isValidDragTarget } = useDragFragment(
    gridFragments,
    useCallback((updater) => {
  setPositions(prev => {
  const updatedPositions = updater(prev)

  // ✅ 過濾掉不合法的 (0,0) 寫入
  for (const [id, pos] of Object.entries(updatedPositions)) {
    if (pos.row === 0 && pos.col === 0) {
      console.warn(`🚫 阻止碎片 ${id} 被寫入為 (0,0)`)
      delete updatedPositions[id]
    }
      }

      positionsRef.current = updatedPositions

      try {
        localStorage.setItem(STORAGE_KEY_POSITIONS, JSON.stringify(updatedPositions))
        console.log('保存位置到 localStorage (拖曳):', Object.keys(updatedPositions).length)
      } catch (error) {
        console.error('保存位置出錯:', error)
      }

      forceUpdate({}) // ✅ 強制重新渲染（讓 layout 立即吃到新資料）

      return updatedPositions
    })
}, [])
  );

  // 處理碎片點擊
  const handleFragmentClick = useCallback((fragment: Fragment) => {
    if (draggingId) return // 拖曳時不觸發點擊
    
    setSelectedFragmentState(fragment)
    setSelectedFragment(fragment)
  }, [draggingId, setSelectedFragment]);

  // 關閉詳情彈窗
  const handleCloseDetail = useCallback(() => {
    setSelectedFragmentState(null)
  }, []);

  // 合併新位置到當前位置記錄
    useEffect(() => {
      setPositions(prev => {
        const updated = { ...prev }
        let hasNew = false

        for (const [id, pos] of Object.entries(newPositions)) {
          // ❌ 防止 fallback 到 (0,0) 被當作合法位置寫入
          if (!(id in prev) && !(pos.row === 0 && pos.col === 0)) {
            updated[id] = pos
            hasNew = true
          } else if (pos.row === 0 && pos.col === 0) {
            console.warn(`⚠️ 阻止新碎片 ${id} 以 (0,0) 被加入 position 記錄`)
          }
        }

        if (hasNew) {
          localStorage.setItem(STORAGE_KEY_POSITIONS, JSON.stringify(updated))
          console.log('✅ 加入新碎片位置：', updated)
          return updated
        }

        return prev
      })
    }, [newPositions])


  // 在碎片數量變化時，確保更新位置
  useEffect(() => {
    // 清理已刪除的碎片位置
    const existingIds = new Set(fragments.map(f => f.id))
    const positionIds = Object.keys(positionsRef.current)
    
    let hasChange = false
    let updatedPositions = { ...positions }
    
    for (const id of positionIds) {
      if (!existingIds.has(id)) {
        delete updatedPositions[id]
        hasChange = true
      }
    }
    
    if (hasChange) {
      setPositions(updatedPositions)
      positionsRef.current = updatedPositions
    }
  }, [fragments.length, positions])

  // 保存位置到 localStorage
    useEffect(() => {
    if (Object.keys(positions).length > 0 && !isInitialLoadRef.current) {
      const saveToLocalStorage = () => {
        try {
          // 確保深拷貝位置對象，避免引用問題
          const positionsToSave = JSON.parse(JSON.stringify(positions));
          
          localStorage.setItem(STORAGE_KEY_POSITIONS, JSON.stringify(positionsToSave));
          console.log('保存位置到 localStorage - 效果更新:', Object.keys(positionsToSave).length);
        } catch (error) {
          console.error('保存位置出錯:', error);
        }
      };
      
      // 立即保存，不使用延時
      saveToLocalStorage();
    }
  }, [positions]);

  // 計算內容區域的高度和寬度
  const { contentWidth, contentHeight } = useMemo(() => {
    if (gridFragments.length === 0) {
      return { contentWidth: CONTAINER_WIDTH, contentHeight: window.innerHeight * 0.6 };
    }
    
    let maxWidth = 0;
    let maxHeight = 0;
    
    gridFragments.forEach(fragment => {
      // 計算這個碎片的邊界
      const fragmentRight = (fragment.position.col + fragment.size.width + 1) * GRID_SIZE; // 加1確保間距
      const fragmentBottom = (fragment.position.row + fragment.size.height + 1) * GRID_SIZE; // 加1確保間距
      
      maxWidth = Math.max(maxWidth, fragmentRight);
      maxHeight = Math.max(maxHeight, fragmentBottom);
    });
    
    // 確保內容區域高度至少為容器高度
    const minHeight = window.innerHeight * 0.6;
    return { 
      contentWidth: Math.min(CONTAINER_WIDTH, maxWidth + 100), // 確保不超過容器寬度
      contentHeight: Math.max(minHeight, maxHeight + 200) // 添加更多底部空間
    };
  }, [gridFragments]);

  return (
    <div className="fragments-container">
      {/* 提示信息 */}
      <div style={{
        position: 'sticky',
        top: 0,
        zIndex: 10,
        backgroundColor: '#f9f6e9',
        padding: '8px 0',
        marginBottom: '12px',
        borderBottom: '1px solid rgba(0, 0, 0, 0.1)',
        textAlign: 'center',
        color: '#666',
        fontSize: '13px'
      }}>
        可自由拖曳碎片，無效位置時會自動回到原位置，保持間距確保易讀性
      </div>

      <div style={{
        textAlign: 'center',
        marginBottom: '12px',
      }}>
        <button
          onClick={() => {
            localStorage.removeItem(STORAGE_KEY_POSITIONS)
            setPositions({})
            positionsRef.current = {}
            console.log('已清除位置 → 將重新布局')
          }}
          style={{
            backgroundColor: '#d1b684',
            color: '#fff',
            padding: '6px 12px',
            border: 'none',
            borderRadius: '6px',
            fontSize: '13px',
            cursor: 'pointer',
            boxShadow: '0 2px 6px rgba(0,0,0,0.1)'
          }}
        >
          重新排列碎片
        </button>
      </div>

      {/* 碎片網格 */}
      <div 
        ref={containerRef}
        className="fragments-grid-container relative" 
        style={{ 
          position: 'relative',
          background: '#f9f6e9',
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 0, 0, 0.05) 1px, transparent 1px)',
          backgroundSize: `${GRID_SIZE}px ${GRID_SIZE}px`,
          width: '100%',
          maxWidth: `${CONTAINER_WIDTH}px`,
          height: `${contentHeight}px`,
          padding: '10px',
          margin: '0 auto',
          overflowX: 'hidden',
          overflowY: 'auto'
        }}
      >
        {gridFragments.length === 0 ? (
          <div className="no-fragments-message" style={{
            padding: '40px 20px',
            textAlign: 'center',
            color: '#aaa',
            fontSize: '16px',
            backgroundColor: 'rgba(255, 255, 255, 0.5)',
            borderRadius: '8px',
            margin: '20px 0'
          }}>
            暫無碎片。請使用頂部的輸入框添加新碎片。
          </div>
        ) : (
          gridFragments
          .filter(fragment => fragment.position) // ✅ 避免沒有 position 的 fragment 被渲染
          .map(fragment => (
            <FragmentCard
              key={fragment.id}
              fragment={fragment}
              isSelected={selectedFragment?.id === fragment.id}
              isDragging={isDragging(fragment.id)}
              dragPosition={dragPosition}
              isValidDragTarget={isValidDragTarget}
              onFragmentClick={handleFragmentClick}
              onDragStart={handleDragStart}
            />
          ))
        )}
         
        {/* 詳情彈窗 */}
        <FragmentDetailModal 
          fragment={selectedFragment} 
          onClose={handleCloseDetail} 
        />
      </div>
    </div>
  );
}