// src/features/fragments/layout/useDragFragment.ts
import { useState, useRef, useCallback, useEffect } from 'react'
import { GridFragment, GridPosition, PixelPosition } from '../types/gridTypes'
import { GRID_SIZE, CONTAINER_WIDTH } from '../constants'
import { pixelToGrid, gridToPixel, isGridOccupied } from './useLayoutFragments'
import { findPlacementPosition } from './useLayoutFragments'
import { markGridAsOccupied } from './useLayoutFragments'


/**
 * 碎片拖曳功能 Hook - 徹底修復版本
 * 
 * @param gridFragments 帶有網格位置的碎片陣列
 * @param setPositions 更新位置的狀態處理函數
 */
export function useDragFragment(
  gridFragments: GridFragment[],
  setPositions: (updater: (prev: Record<string, GridPosition>) => Record<string, GridPosition>) => void
) {
  // 當前正在拖曳的碎片ID
  const [draggingId, setDraggingId] = useState<string | null>(null)
  // 拖曳點相對於碎片左上角的偏移
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  // 拖曳時的像素位置
  const [dragPosition, setDragPosition] = useState<PixelPosition>({ top: 0, left: 0 })
  // 拖曳開始的網格位置
  const dragStartPosition = useRef<GridPosition | null>(null)
  // 拖曳的DOM元素引用
  const dragElementRef = useRef<HTMLDivElement | null>(null)
  // 是否判定為拖曳（區分點擊和拖曳）
  const [isDraggingAction, setIsDraggingAction] = useState(false)
  // 拖曳開始時的鼠標位置
  const dragStartMousePosition = useRef<{ x: number, y: number } | null>(null)
  // 拖曳閾值（像素）- 超過這個距離才判定為拖曳
  const DRAG_THRESHOLD = 8
  // 拖曳位置是否有效
  const [isValidTarget, setIsValidTarget] = useState(true)

  // 處理拖曳開始
  const handleDragStart = useCallback((e: React.MouseEvent, fragment: GridFragment) => {
    e.preventDefault()
    e.stopPropagation()
    
    // 獲取元素的實際位置
    const element = e.currentTarget as HTMLElement
    const rect = element.getBoundingClientRect()
    
    // 記錄開始的鼠標位置
    dragStartMousePosition.current = { x: e.clientX, y: e.clientY }
    
    // 計算點擊位置相對於碎片左上角的偏移
    // 重要：使用 getBoundingClientRect() 而不是 offsetLeft/offsetTop
    const offsetX = e.clientX - rect.left
    const offsetY = e.clientY - rect.top
    
    // 保存要拖曳的元素引用和基本信息
    dragElementRef.current = element as HTMLDivElement;
    setDraggingId(fragment.id)
    setDragOffset({ x: offsetX, y: offsetY })
    setIsDraggingAction(false)
    setIsValidTarget(true)
    
    // 記錄開始拖曳時的網格位置 - 重要的回退點
    dragStartPosition.current = { ...fragment.position }
    console.log('拖曳開始，起始位置:', dragStartPosition.current);
    
    // 確保初始位置正確
    setDragPosition({ 
      top: e.clientY - offsetY,
      left: e.clientX - offsetX
    })
  }, []);
  
  // 處理拖曳中
  const handleDragMove = useCallback((e: MouseEvent) => {
    if (!draggingId || !dragElementRef.current || !dragStartMousePosition.current) return
    
    // 計算鼠標移動距離
    const dx = e.clientX - dragStartMousePosition.current.x
    const dy = e.clientY - dragStartMousePosition.current.y
    const distance = Math.sqrt(dx * dx + dy * dy)
    
    // 如果還沒判定為拖曳動作，檢查是否超過閾值
    if (!isDraggingAction) {
      if (distance > DRAG_THRESHOLD) {
        setIsDraggingAction(true)
        
        // 設置拖曳狀態
        dragElementRef.current.style.position = 'fixed'
        dragElementRef.current.style.zIndex = '1000'
        dragElementRef.current.style.pointerEvents = 'none'
        dragElementRef.current.style.transition = 'none'
        dragElementRef.current.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.15)'
        dragElementRef.current.style.cursor = 'grabbing'
        
        // 設置初始拖曳位置
        const initialTop = e.clientY - dragOffset.y
        const initialLeft = e.clientX - dragOffset.x
        
        dragElementRef.current.style.top = `${initialTop}px`
        dragElementRef.current.style.left = `${initialLeft}px`
      } else {
        // 未超過閾值，不執行拖曳
        return
      }
    }
    
    // 計算新的位置，考慮偏移量
    const newTop = e.clientY - dragOffset.y
    const newLeft = e.clientX - dragOffset.x
    
    // 更新元素位置
    dragElementRef.current.style.top = `${newTop}px`
    dragElementRef.current.style.left = `${newLeft}px`
    
    // 更新拖曳位置狀態
    setDragPosition({ top: newTop, left: newLeft })
    
    // 獲取容器的位置，用於計算相對位置
    const container = dragElementRef.current.closest('.fragments-grid-container')
    const containerRect = container?.getBoundingClientRect() || { left: 0, top: 0 }
    
    // 計算相對於容器的位置
    const relativeTop = newTop - containerRect.top + (container?.scrollTop || 0)
    const relativeLeft = newLeft - containerRect.left + (container?.scrollLeft || 0)
    
    // 將像素位置轉換為網格位置
    let targetPosition = pixelToGrid(relativeTop, relativeLeft)
    
    // 嚴格對齊到網格
    targetPosition = {
      row: Math.round(targetPosition.row),
      col: Math.round(targetPosition.col)
    }
    
    // 獲取被拖曳的碎片
    const draggedFragment = gridFragments.find(f => f.id === draggingId)
    if (!draggedFragment) return
    
    // 建立簡易的 200x200 空網格
      const tempGrid = Array.from({ length: 200 }, () => Array(200).fill(false))

      // 將其他 fragment 標記為已佔用
      gridFragments
        .filter(f => f.id !== draggingId)
        .forEach(f => {
          markGridAsOccupied(tempGrid, f.position, f.size)
        })

      // 使用統一碰撞檢查函式
      const valid = !isGridOccupied(tempGrid, targetPosition, draggedFragment.size)
    
    // 更新有效性狀態，用於視覺反饋
    setIsValidTarget(valid)
    
    // 視覺反饋：添加邊框顏色
    if (dragElementRef.current) {
      dragElementRef.current.style.border = valid
        ? '2px solid rgba(0, 200, 0, 0.5)'
        : '2px solid rgba(255, 0, 0, 0.5)'
    }
    
  }, [draggingId, dragOffset, isDraggingAction, gridFragments]);
  
  // 處理拖曳結束 - 徹底修復版本
      const handleDragEnd = useCallback(() => {
      if (!draggingId || !dragStartPosition.current || !dragElementRef.current) {
        resetDragState(dragElementRef.current!)
        setDraggingId(null)
        setIsDraggingAction(false)
        dragStartMousePosition.current = null
        return
      }

      const draggedElement = dragElementRef.current

      // 如果只是點擊（沒移動過閾值），不執行任何更新
      if (!isDraggingAction) {
        resetDragState(draggedElement)
        setDraggingId(null)
        setIsDraggingAction(false)
        dragStartMousePosition.current = null
        return
      }

      try {
        
        const container = draggedElement.closest('.fragments-grid-container')
        const containerRect = container?.getBoundingClientRect() || { left: 0, top: 0 }

        const relativeTop = dragPosition.top - containerRect.top + (container?.scrollTop || 0)
        const relativeLeft = dragPosition.left - containerRect.left + (container?.scrollLeft || 0)

        let targetPosition = pixelToGrid(relativeTop, relativeLeft)
        targetPosition = {
          row: Math.round(targetPosition.row),
          col: Math.round(targetPosition.col),
        }

        const draggedFragment = gridFragments.find(f => f.id === draggingId)
        if (!draggedFragment) {
          console.warn('找不到被拖曳的碎片')
          return
        }

     

        // 驗證目標位置
        // 建立空網格並標記其他碎片
        const tempGrid = Array.from({ length: 200 }, () => Array(200).fill(false))
        gridFragments
          .filter(f => f.id !== draggingId)
          .forEach(f => {
            markGridAsOccupied(tempGrid, f.position, f.size)
          })

        const isTargetValid = !isGridOccupied(tempGrid, targetPosition, draggedFragment.size)
        const isOriginalValid = !isGridOccupied(tempGrid, dragStartPosition.current, draggedFragment.size)

        let finalPosition: GridPosition | null = null

        if (isTargetValid) {
          finalPosition = targetPosition
          console.log('✅ 拖曳成功，使用新位置:', finalPosition)
        } else if (isOriginalValid) {
          finalPosition = dragStartPosition.current
          console.warn('⚠️ 拖曳目標無效，回退至原始位置:', finalPosition)
        } else {
          // 再試圖找其他空位
          const alternativePosition = findPlacementPosition(
            Array.from({ length: 200 }, () => Array(200).fill(false)), // 建一個乾淨 grid
            draggedFragment.size
          )

          if (alternativePosition) {
            finalPosition = alternativePosition
            console.warn('❗ 原始位置也無效，使用其他空位:', finalPosition)
          } else {
            console.error('🚫 完全無法放置，略過位置更新')
            finalPosition = null
          }
        }

        if (finalPosition) {
          if (finalPosition?.row === 0 && finalPosition?.col === 0) {
              console.warn(`⚠️ [DragEnd] 碎片 ${draggingId} 最終位置為 (0,0)！`)
            }
          // 🧠 儲存位置
          setPositions(prev => ({ ...prev, [draggingId]: finalPosition }))

          // 🧠 不論是新位置或回原位，立即強制套用 style
          const { top: pxTop, left: pxLeft } = gridToPixel(finalPosition)
          draggedElement.style.top = `${pxTop}px`
          draggedElement.style.left = `${pxLeft}px`
        } else if (dragStartPosition.current) {
          // 🚫 沒有任何可用位置 → 至少還原 UI
          const { top, left } = gridToPixel(dragStartPosition.current)
          draggedElement.style.top = `${top}px`
          draggedElement.style.left = `${left}px`
        }

      } catch (error) {
        console.error('拖曳結束錯誤:', error)
      } finally {
        resetDragState(dragElementRef.current)
        setDraggingId(null)
        setIsDraggingAction(false)
        dragStartMousePosition.current = null
        setIsValidTarget(true)
      }
    }, [draggingId, dragPosition, gridFragments, setPositions])



  // 重置拖曳狀態
  const resetDragState = (element: HTMLElement) => {
    // 恢復元素樣式
    element.style.position = ''
    element.style.position = 'absolute'
    element.style.pointerEvents = ''
    element.style.transition = ''
    element.style.transform = ''
    element.style.boxShadow = ''
    element.style.cursor = ''
    element.style.border = ''
  }

  // 設置全局滑鼠事件監聽
  useEffect(() => {
    window.addEventListener('mousemove', handleDragMove)
    window.addEventListener('mouseup', handleDragEnd)
    // 處理拖曳到視窗外的情況
    window.addEventListener('mouseleave', handleDragEnd)
    
    return () => {
      window.removeEventListener('mousemove', handleDragMove)
      window.removeEventListener('mouseup', handleDragEnd)
      window.removeEventListener('mouseleave', handleDragEnd)
    }
  }, [handleDragMove, handleDragEnd]);

  return {
    draggingId,
    dragPosition,
    handleDragStart,
    isValidDragTarget: isValidTarget,
    isDragging: (id: string) => draggingId === id && isDraggingAction
  }
}