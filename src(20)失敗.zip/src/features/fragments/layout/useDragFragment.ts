// src/features/fragments/layout/useDragFragment.ts
import { useState, useRef, useCallback, useEffect } from 'react'
import { GridFragment, GridPosition, PixelPosition } from '../types/gridTypes'
import { GRID_SIZE } from '../constants'
import { pixelToGrid, gridToPixel, isGridOccupied } from './useLayoutFragments'

/**
 * 碎片拖曳功能 Hook
 * 
 * @param gridFragments 帶有網格位置的碎片陣列
 * @param setPositions 更新位置的狀態處理函數
 */
export function useDragFragment(
  gridFragments: GridFragment[],
  setPositions: (updater: (prev: Record<string, GridPosition>) => Record<string, GridPosition>) => void
) {
  // 當前正在拖曳的碎片ID
  const [draggingId, setDraggingId] = useState<string | null>(null)
  // 拖曳點相對於碎片左上角的偏移
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  // 拖曳時的像素位置
  const [dragPosition, setDragPosition] = useState<PixelPosition>({ top: 0, left: 0 })
  // 拖曳開始的位置（用於計算移動距離）
  const [dragStartClientPosition, setDragStartClientPosition] = useState({ x: 0, y: 0 })
  // 開始拖曳時的網格位置
  const dragStartPosition = useRef<GridPosition | null>(null)
  // 拖曳的DOM元素引用
  const dragElementRef = useRef<HTMLDivElement | null>(null)
  // 是否判定為拖曳（區分點擊和拖曳）
  const [isDraggingAction, setIsDraggingAction] = useState(false)
  // 拖曳閾值（像素）- 超過這個距離才判定為拖曳
  const DRAG_THRESHOLD = 5

  // 處理拖曳開始
  const handleDragStart = useCallback((e: React.MouseEvent, fragment: GridFragment) => {
    e.preventDefault()
    e.stopPropagation()
    
    // 記錄開始的鼠標位置（用於判斷是點擊還是拖曳）
    setDragStartClientPosition({ x: e.clientX, y: e.clientY })
    
    // 計算點擊位置相對於卡片左上角的偏移
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect()
    const offsetX = e.clientX - rect.left
    const offsetY = e.clientY - rect.top
    
    // 保存要拖曳的元素引用
    dragElementRef.current = e.currentTarget as HTMLDivElement
    
    setDraggingId(fragment.id)
    setDragOffset({ x: offsetX, y: offsetY })
    setIsDraggingAction(false) // 初始設為false，等移動超過閾值後才設為true
    
    // 設置初始拖曳位置為卡片當前位置
    const { top, left } = gridToPixel(fragment.position)
    setDragPosition({ top, left })
    
    // 記錄開始拖曳時的網格位置
    dragStartPosition.current = fragment.position
    
    // 注意：在這裡不修改元素的樣式，只有在判定為拖曳動作後才修改
  }, []);
  
  // 移動元素到指定的鼠標位置
  const moveAt = useCallback((clientX: number, clientY: number, element: HTMLElement) => {
    // 如果還沒判定為拖曳動作，先檢查是否移動距離超過閾值
    if (!isDraggingAction) {
      const dx = clientX - dragStartClientPosition.x
      const dy = clientY - dragStartClientPosition.y
      const distance = Math.sqrt(dx * dx + dy * dy)
      
      if (distance > DRAG_THRESHOLD) {
        setIsDraggingAction(true)
        
        // 設置拖曳狀態 - 使用absolute而非fixed
        element.style.position = 'absolute'
        element.style.zIndex = '1000'
        element.style.pointerEvents = 'none'
        element.style.transition = 'none'
        element.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.15)'
      } else {
        // 未超過閾值，不執行拖曳
        return
      }
    }
    
    // 獲取滾動容器的滾動位置
    const container = document.querySelector('.fragments-grid-container');
    const scrollTop = container ? container.scrollTop : 0;
    const scrollLeft = container ? container.scrollLeft : 0;
    
    // 計算元素左上角的位置（考慮鼠標在元素內的偏移和滾動位置）
    const left = clientX - dragOffset.x + (container ? container.scrollLeft : 0);
    const top = clientY - dragOffset.y + (container ? container.scrollTop : 0);
    
    // 直接設置位置而不是使用transform
    element.style.left = `${left}px`;
    element.style.top = `${top}px`;
    element.style.transform = 'none';
    
    // 更新拖曳位置
    setDragPosition({ top, left })
  }, [dragOffset, dragStartClientPosition, isDraggingAction]);

  // 處理拖曳中
  const handleDragMove = useCallback((e: MouseEvent) => {
    if (!draggingId || !dragElementRef.current) return
    
    // 移動拖曳元素以跟隨鼠標
    moveAt(e.clientX, e.clientY, dragElementRef.current)
  }, [draggingId, moveAt]);
  
  // 處理拖曳結束
  const handleDragEnd = useCallback(() => {
    if (!draggingId || !dragStartPosition.current || !dragElementRef.current) {
      setDraggingId(null)
      setIsDraggingAction(false)
      return
    }
    
    // 獲取目標元素
    const draggedElement = dragElementRef.current
    
    // 如果不是拖曳動作（只是點擊），不處理位置更新
    if (!isDraggingAction) {
      resetDragState(draggedElement)
      return
    }
    
    // 將拖曳後的像素位置轉換為網格位置
    const newGridPosition = pixelToGrid(dragPosition.top, dragPosition.left)
    
    // 檢查新位置是否有效（不與其他碎片重疊）
    const draggedFragment = gridFragments.find(f => f.id === draggingId)
    if (!draggedFragment) {
      resetDragState(draggedElement)
      return
    }
    
    // 創建一個臨時網格來檢查新位置是否可用
    const rows = 100
    const cols = 100
    const tempGrid: boolean[][] = Array(rows).fill(0).map(() => Array(cols).fill(false))
    
    // 將所有碎片標記為已佔用，除了正在拖曳的碎片
    gridFragments.forEach(frag => {
      if (frag.id !== draggingId) {
        for (let r = frag.position.row; r < frag.position.row + frag.size.height; r++) {
          for (let c = frag.position.col; c < frag.position.col + frag.size.width; c++) {
            if (r >= 0 && c >= 0 && r < rows && c < cols) {
              tempGrid[r][c] = true // 標記為已佔用
            }
          }
        }
      }
    })
    
    // 檢查新位置是否可用
    if (!isGridOccupied(tempGrid, newGridPosition, draggedFragment.size)) {
      // 更新位置記錄
      setPositions(prev => ({
        ...prev,
        [draggingId]: newGridPosition
      }))
    }
    
    resetDragState(draggedElement)
  }, [draggingId, dragPosition, gridFragments, setPositions, isDraggingAction]);

  // 重置拖曳狀態
  const resetDragState = (element: HTMLElement) => {
    // 恢復元素樣式
    element.style.position = ''
    element.style.zIndex = ''
    element.style.pointerEvents = ''
    element.style.transition = ''
    element.style.transform = ''
    element.style.boxShadow = ''
    element.style.left = ''
    element.style.top = ''
    
    setDraggingId(null)
    setIsDraggingAction(false)
    dragElementRef.current = null
  }

  // 設置全局滑鼠事件監聽
  useEffect(() => {
    window.addEventListener('mousemove', handleDragMove)
    window.addEventListener('mouseup', handleDragEnd)
    
    return () => {
      window.removeEventListener('mousemove', handleDragMove)
      window.removeEventListener('mouseup', handleDragEnd)
    }
  }, [handleDragMove, handleDragEnd]);

  return {
    draggingId,
    dragPosition,
    handleDragStart,
    isDragging: (id: string) => draggingId === id && isDraggingAction
  }
}