// src/features/fragments/utils.ts
// 共享工具函數

/**
 * 智能截短文字，特別處理超長文字
 */
export function truncateText(text: string, maxLength: number): string {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  
  // 對於超長文字，進行更激進的截斷
  if (text.length > 10000) { // 如果文字超過1萬
    // 取開頭、中間和結尾各一部分
    const headPart = text.slice(0, Math.floor(maxLength * 0.6)); // 60%的長度給開頭
    const tailPart = text.slice(text.length - Math.floor(maxLength * 0.2)); // 20%的長度給結尾
    return headPart + "...... (省略約" + (text.length - maxLength) + "字) ......" + tailPart;
  }
  
  // 尋找自然斷點
  const naturalBreakPoints = [
    text.lastIndexOf('。', maxLength),
    text.lastIndexOf('？', maxLength),
    text.lastIndexOf('！', maxLength),
    text.lastIndexOf('；', maxLength),
    text.lastIndexOf('，', maxLength),
    text.lastIndexOf('.', maxLength),
    text.lastIndexOf('?', maxLength),
    text.lastIndexOf('!', maxLength),
    text.lastIndexOf(';', maxLength),
    text.lastIndexOf(',', maxLength),
    text.lastIndexOf('、', maxLength),
    text.lastIndexOf(' ', maxLength),
    text.lastIndexOf('\n', maxLength),
  ].filter(point => point !== -1);
  
  // 如果找到合適的斷點，則在斷點處截斷
  if (naturalBreakPoints.length > 0) {
    const breakPoint = Math.max(...naturalBreakPoints);
    if (breakPoint >= maxLength * 0.5) { // 降低閾值到50%
      return text.slice(0, breakPoint + 1) + "......";
    }
  }
  
  // 如果沒有找到合適的斷點，則直接截斷
  return text.slice(0, maxLength) + "......";
}

/**
 * 根據內容決定展示方向
 * @param content 主要內容
 * @param note 筆記內容
 * @param useRandom 是否使用隨機性（UI顯示時使用，存儲時不使用）
 */
export function decideDirection(
  content: string, 
  note?: string, 
  useRandom: boolean = false
): 'horizontal' | 'vertical' {
  const full = `${content} ${note ?? ''}`
  const hasEnglish = /[a-zA-Z]/.test(full)
  const isOnlyCJK = /^[\u4e00-\u9fa5\u3040-\u30ff\s]+$/.test(full)

  // 如果含有英文、數字或特殊符號，一律橫排
  if (hasEnglish || /\d/.test(full) || /[{}[\]()=;:]/.test(full)) return 'horizontal'
  
  // 純中文或日文
  if (isOnlyCJK) {
    // 存儲時使用確定性邏輯，UI顯示時可以加入隨機因素
    return useRandom && Math.random() < 0.3 ? 'vertical' : 'horizontal'
  }
  
  return 'horizontal'
}

/**
 * 格式化日期
 */
export function formatDate(dateString?: string): string {
  if (!dateString) return ''
  const date = new Date(dateString)
  return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日`
}

/**
 * 檢查日期是否在指定範圍內
 */
export function isDateInRange(
  dateStr: string, 
  timeRange: string, 
  customStart?: Date, 
  customEnd?: Date
): boolean {
  const date = new Date(dateStr)
  const now = new Date()
  
  // 重置當前時間為當天開始（00:00:00）
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  
  switch(timeRange) {
    case 'today':
      return date >= today
    case 'yesterday': {
      const yesterday = new Date(today)
      yesterday.setDate(yesterday.getDate() - 1)
      return date >= yesterday && date < today
    }
    case 'week': {
      const weekStart = new Date(today)
      weekStart.setDate(today.getDate() - today.getDay()) // 設為本週日（一週的開始）
      return date >= weekStart
    }
    case 'month': {
      const monthStart = new Date(today.getFullYear(), today.getMonth(), 1)
      return date >= monthStart
    }
    case 'custom':
      return (
        (!customStart || date >= customStart) && 
        (!customEnd || date <= customEnd)
      )
    case 'all':
    default:
      return true
  }
}