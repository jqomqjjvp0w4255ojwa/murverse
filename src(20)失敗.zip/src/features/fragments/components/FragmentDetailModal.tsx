'use client'

import { Fragment } from '@/features/fragments/types/fragment'
import { useEffect, useRef, useState } from 'react'
import { formatDate } from '@/features/fragments/utils'

interface FragmentDetailModalProps {
  fragment: Fragment | null
  onClose: () => void
}

export default function FragmentDetailModal({ fragment, onClose }: FragmentDetailModalProps) {
  const modalRef = useRef<HTMLDivElement>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [contentParagraphs, setContentParagraphs] = useState<string[]>([])
  const [showTags, setShowTags] = useState(false) // 默認折疊標籤

  // 點擊外部關閉
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
        onClose()
      }
    }

    document.addEventListener('mousedown', handleOutsideClick)
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick)
    }
  }, [onClose])

  // ESC 鍵關閉
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose()
      }
    }

    document.addEventListener('keydown', handleEscape)
    return () => {
      document.removeEventListener('keydown', handleEscape)
    }
  }, [onClose])
  
  // 處理內容分段
  useEffect(() => {
    if (fragment) {
      // 對於超長內容，顯示加載指示器
      if (fragment.content.length > 10000) {
        setIsLoading(true)
        const timer = setTimeout(() => {
          setIsLoading(false)
        }, 300) // 300ms後結束加載狀態
        
        // 清理函數
        return () => clearTimeout(timer)
      } else {
        setIsLoading(false)
      }
      
      // 將內容分段
      if (fragment.content) {
        // 按照段落分割內容
        const paragraphs = fragment.content
          .split(/\n\s*\n|\r\n\s*\r\n/)
          .filter(p => p.trim().length > 0)
          .map(p => p.trim())
        
        // 如果沒有分段，則嘗試按句號等標點符號分段
        if (paragraphs.length <= 1 && fragment.content.length > 300) {
          const sentences = fragment.content
            .replace(/([。！？；])/g, '$1\n\n')
            .split(/\n\s*\n/)
            .filter(s => s.trim().length > 0)
            .map(s => s.trim())
          
          if (sentences.length > 1) {
            setContentParagraphs(sentences)
          } else {
            setContentParagraphs(paragraphs)
          }
        } else {
          setContentParagraphs(paragraphs)
        }
      } else {
        setContentParagraphs([])
      }
    }
  }, [fragment])

  // 如果沒有碎片，不顯示彈窗
  if (!fragment) return null

  // 獲取筆記標題 - 如果沒有標題，則使用筆記內容的前幾個字
  const getNoteTitle = (note: any) => {
    if (note?.title && note.title.trim().length > 0) return note.title;
    if (note?.value) {
      const firstLine = note.value.split('\n')[0];
      return firstLine.length > 20 ? firstLine.substring(0, 20) + '...' : firstLine;
    }
    return '筆記';
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
      <div
        ref={modalRef}
        className="bg-white rounded-lg shadow-lg w-full max-w-lg max-h-screen overflow-auto"
        style={{
          backgroundColor: '#fffbef',
          border: '1px solid rgba(0, 0, 0, 0.1)',
          padding: '16px',
          margin: '0',
          height: '100vh', // 讓模態框佔滿整個螢幕高度
          display: 'flex',
          flexDirection: 'column',
          maxWidth: '600px' // 限制寬度，讓內容集中
        }}
      >
        {/* 模態框頂部 - 只有關閉按鈕 */}
        <div className="flex justify-end items-center mb-2">
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 focus:outline-none"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        {/* 加載指示器 */}
        {isLoading && (
          <div className="text-center py-4 flex-grow">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            <p className="mt-2 text-gray-600">加載中... 內容較長，請稍候</p>
          </div>
        )}

        {/* 碎片內容 */}
        {!isLoading && (
          <div className="space-y-4 flex-grow overflow-auto flex flex-col">
            {/* 主內容 - 直接顯示，沒有背景 */}
            <div className="flex-shrink-0">
              {/* 超長內容時顯示字數統計 */}
              {fragment.content.length > 5000 && (
                <div style={{ 
                  fontSize: '12px', 
                  color: '#999', 
                  marginBottom: '10px',
                }}>
                  內容長度：{fragment.content.length}字
                </div>
              )}
              
              {/* 將內容分段顯示 */}
              <div 
                style={{
                  fontSize: '16px',
                  lineHeight: '1.6',
                  wordBreak: 'break-word',
                  whiteSpace: 'pre-wrap',
                }}
              >
                {contentParagraphs.map((paragraph, index) => (
                  <p key={index} style={{ 
                    marginBottom: '0.8em',
                    textIndent: '2em' // 段落首行縮進
                  }}>
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>

            {/* 筆記 - 使用筆記標題而非固定文字 */}
            {fragment.notes && fragment.notes.length > 0 && (
              <div className="flex-grow" style={{ minHeight: '50vh' }}>
                <div className="space-y-3">
                  {fragment.notes.map((note) => (
                    <div key={note.id}>
                      {/* 筆記標題 */}
                      <h4 className="text-sm font-medium text-gray-500 mb-2">
                        {getNoteTitle(note)}
                      </h4>
                      <div
                        className="p-3 bg-gray-50 rounded"
                        style={{
                          backgroundColor: '#f9f6e9',
                          height: 'auto',
                          minHeight: '50vh', // 非常高的筆記區域，佔螢幕一半高度
                          maxHeight: '60vh',
                          overflowX: 'auto',
                          overflowY: 'auto',
                          wordBreak: 'break-word',
                          whiteSpace: 'pre-wrap',
                          fontSize: '15px',
                          lineHeight: '1.5'
                        }}
                      >
                        {note.value}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 頁腳區域 - 包含標籤和創建時間 */}
            <div className="flex-shrink-0 mt-auto">
              {/* 標籤區域 - 可折疊 */}
              <div>
                <div 
                  className="flex justify-between items-center cursor-pointer"
                  onClick={() => setShowTags(!showTags)}
                >
                  <h4 className="text-sm font-medium text-gray-500 mb-1">標籤 ({fragment.tags.length})</h4>
                  <span className="text-gray-400">
                    {showTags ? '▲' : '▼'}
                  </span>
                </div>
                
                {showTags && (
                  <div className="flex flex-wrap gap-2 mt-2 mb-3">
                    {fragment.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1 text-sm rounded"
                        style={{
                          backgroundColor: '#f3e8c7',
                          color: '#8d6a38',
                          borderRadius: '16px',
                        }}
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* 創建時間 - 放在底部 */}
              <div className="pt-2 border-t border-gray-100 flex justify-between items-center">
                <span className="text-xs text-gray-400">
                  創建於 {formatDate(fragment.createdAt)}
                </span>
                <span className="text-xs text-gray-400">
                  {fragment.updatedAt && fragment.updatedAt !== fragment.createdAt
                    ? `更新於 ${formatDate(fragment.updatedAt)}`
                    : ''}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}