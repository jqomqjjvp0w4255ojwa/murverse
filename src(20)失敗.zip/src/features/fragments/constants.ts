// src/features/fragments/constants.ts
// 統一管理常數，避免重複定義

export const GRID_SIZE = 20 // 每個格子20px
export const GRID_GAP = 3   // 格子間的間距係數

// 內容字數限制
export const MAX_CONTENT_LENGTH = 300 // 降低卡片預覽內容限制
export const MAX_NOTE_LENGTH = 150    // 降低筆記預覽內容限制
export const MAX_TAGS_COUNT = 20

// 卡片尺寸限制
export const MAX_CARD_WIDTH = 20    // 最大寬度格數
export const MAX_CARD_HEIGHT = 15   // 最大高度格數

// 視圖模式
export const VIEW_MODES = {
  GRID: 'grid',
  FLOW: 'flow'
} as const

// 排序方式
export const SORT_FIELDS = {
  CREATED_AT: 'createdAt',
  CONTENT: 'content',
  UPDATED_AT: 'updatedAt'
} as const

export const SORT_ORDERS = {
  ASC: 'asc',
  DESC: 'desc'
} as const

// 儲存相關
export const STORAGE_KEY = 'murverse_fragments'
