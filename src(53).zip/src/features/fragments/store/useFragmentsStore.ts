// 🚀 優化後的 useFragmentsStore.ts - 快速載入版本
'use client'

import { create } from 'zustand'
import { Fragment, Note } from '@/features/fragments/types/fragment'
import { apiClient } from '@/services/api-client'
import { ParsedSearch } from '@/features/search/useAdvancedSearch'
import { matchText, matchFragment } from '@/features/search/searchHelpers'
import { isDateInRange } from '@/features/fragments/utils'
import { SORT_FIELDS, SORT_ORDERS } from '@/features/fragments/constants'
import { getSupabaseClient } from '@/lib/supabase/client'

type SortField = typeof SORT_FIELDS[keyof typeof SORT_FIELDS]
type SortOrder = typeof SORT_ORDERS[keyof typeof SORT_ORDERS]
type Mode = 'grid' | 'flow'  // 🔧 修復：保留 grid 和 flow 模式
export type TagLogicMode = 'AND' | 'OR'

// 🎯 大幅簡化狀態枚舉 - 只保留必要的
export enum AppStatus {
  LOADING = 'loading',           // 載入中（包含初始化、認證檢查、數據載入）
  READY = 'ready',               // 準備就緒（已載入，有數據）
  EMPTY = 'empty',               // 準備就緒但無數據
  UNAUTHENTICATED = 'auth',      // 需要認證
  ERROR = 'error'                // 錯誤
}

// 🗑️ 刪除複雜的刪除選項，保持簡單
interface FragmentsState {
  // === 核心數據 ===
  fragments: Fragment[] | null  // null = 未載入, [] = 已載入但無數據
  
  // === 搜尋和篩選 ===
  searchQuery: string
  searchKeyword: string
  selectedTags: string[]
  excludedTags: string[]
  tagLogicMode: TagLogicMode
  sortField: SortField
  sortOrder: SortOrder
  advancedSearch: ParsedSearch | null
  
  // === UI 狀態 ===
  selectedFragment: Fragment | null
  mode: Mode  // 🔧 恢復：保留 grid/flow 模式切換
  
  // 🎯 簡化狀態管理 - 只保留必要的
  status: AppStatus
  error: string | null
  hasInitialized: boolean  // 🔧 新增：是否已完成初始化
  
  // === 操作方法 ===
  initialize: () => Promise<void>
  load: () => Promise<void>
  
  // === Setters ===
  setFragments: (fragments: Fragment[]) => void
  setSearchQuery: (query: string) => void
  setSelectedTags: (tags: string[]) => void
  setExcludedTags: (tags: string[]) => void
  setTagLogicMode: (mode: TagLogicMode) => void
  setSortField: (field: SortField) => void
  setSortOrder: (order: SortOrder) => void
  setSelectedFragment: (fragment: Fragment | null) => void
  setMode: (mode: Mode) => void  // 🔧 恢復：setMode 方法
  setAdvancedSearch: (search: ParsedSearch | null) => void
  setSearchKeyword: (keyword: string) => void
  setError: (error: string | null) => void
  
  // === 篩選方法 ===
  getFilteredFragments: () => Fragment[]
  getFilteredFragmentsByAdvancedSearch: () => Fragment[]
  
  // === Fragment 操作（保留樂觀更新） ===
  addFragment: (content: string, tags: string[], notes: Note[]) => Promise<void>
  deleteFragment: (fragmentId: string) => Promise<void>
  
  // === 樂觀更新重試機制 ===
  retryOperation: (fragmentId: string) => Promise<void>
  abandonOperation: (fragmentId: string) => void
  
  // === Note 操作 ===
  addNoteToFragment: (fragmentId: string, note: Note) => Promise<void>
  updateNoteInFragment: (fragmentId: string, noteId: string, updates: Partial<Note>) => Promise<void>
  removeNoteFromFragment: (fragmentId: string, noteId: string) => Promise<void>
  
  // === Tag 操作 ===
  addTagToFragment: (fragmentId: string, tag: string) => Promise<void>
  removeTagFromFragment: (fragmentId: string, tag: string) => Promise<void>
}

const isClient = typeof window !== 'undefined'

export const useFragmentsStore = create<FragmentsState>((set, get) => ({
  // === 初始狀態 ===
  fragments: [], 
  searchQuery: '',
  searchKeyword: '',
  selectedTags: [],
  excludedTags: [],
  tagLogicMode: 'AND',
  sortField: SORT_FIELDS.CREATED_AT,
  sortOrder: SORT_ORDERS.DESC,
  selectedFragment: null,
  mode: 'grid',  // 🔧 恢復：預設為 grid 模式
  advancedSearch: null,
  status: AppStatus.LOADING,  // 🔧 統一使用 LOADING 狀態
  error: null,
  hasInitialized: false,  // 🔧 新增初始化標記

  // 🚀 超級簡化的初始化 - 統一載入狀態
  initialize: async () => {
    if (!isClient) return
    
    const currentState = get()
    if (currentState.hasInitialized) return  // 防止重複初始化
    
    console.log('🎯 開始載入...')
    
    // 🔧 簡化：只有載入狀態，不區分階段
    set({ status: AppStatus.LOADING, error: null, hasInitialized: false })

    try {
      const supabase = getSupabaseClient()
      if (!supabase) {
        set({ 
          status: AppStatus.ERROR, 
          error: 'Supabase 不可用',
          hasInitialized: true 
        })
        return
      }

      // 檢查認證
      const { data: { session }, error: authError } = await supabase.auth.getSession()
      
      if (authError) {
        set({ 
          status: AppStatus.ERROR, 
          error: `認證失敗: ${authError.message}`,
          hasInitialized: true 
        })
        return
      }
      
      if (!session) {
        console.log('🚫 用戶未認證')
        set({ 
          status: AppStatus.UNAUTHENTICATED, 
          fragments: [],  // 明確設為空陣列
          hasInitialized: true 
        })
        return
      }

      // 載入碎片
      const fragments = await apiClient.getFragments()
      
      // 🔧 根據數據量決定最終狀態
      set({ 
        fragments,
        status: fragments.length > 0 ? AppStatus.READY : AppStatus.EMPTY,
        error: null,
        hasInitialized: true
      })
      
      console.log(`🎉 載入完成！獲得 ${fragments.length} 個碎片`)
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : '載入失敗'
      console.error('💥 載入錯誤:', error)
      
      set({ 
        status: AppStatus.ERROR,
        error: errorMessage,
        fragments: [],
        hasInitialized: true
      })
    }
  },

  // 🚀 重試操作方法
  retryOperation: async (fragmentId: string) => {
    const currentFragments = get().fragments
    if (!currentFragments) return

    const fragment = currentFragments.find(f => f.id === fragmentId)
    if (!fragment || !fragment._operationType) return

    console.log(`🔄 重試操作: ${fragment._operationType} for ${fragmentId}`)

    // 根據操作類型重試
    if (fragment._operationType === 'create') {
      // 重新創建：移除失敗的，重新添加
      const { content, tags, notes } = fragment
      
      // 移除失敗的臨時 fragment
      set(state => ({
        fragments: state.fragments ? state.fragments.filter(f => f.id !== fragmentId) : []
      }))
      
      // 重新嘗試創建
      await get().addFragment(content, tags, notes)
      
    } else if (fragment._operationType === 'delete') {
      // 重新刪除
      await get().deleteFragment(fragmentId)
    }
  },

  // 🚀 放棄操作方法
  abandonOperation: (fragmentId: string) => {
    const currentFragments = get().fragments
    if (!currentFragments) return

    const fragment = currentFragments.find(f => f.id === fragmentId)
    if (!fragment || !fragment._operationType) return

    console.log(`❌ 放棄操作: ${fragment._operationType} for ${fragmentId}`)

    if (fragment._operationType === 'create') {
      // 放棄創建：直接移除失敗的臨時 fragment
      set(state => ({
        fragments: state.fragments ? state.fragments.filter(f => f.id !== fragmentId) : []
      }))
    } else if (fragment._operationType === 'delete') {
      // 放棄刪除：恢復正常狀態，清除錯誤標記
      set(state => ({
        fragments: state.fragments ? state.fragments.map(f => 
          f.id === fragmentId ? {
            ...f,
            _operationStatus: undefined,
            _operationType: undefined,
            _failureReason: undefined,
            _pending: false
          } : f
        ) : []
      }))
    }
  },

  // 🎯 簡化 load 方法
  load: async () => {
    if (!isClient) return
    
    try {
      console.log('🔄 重新載入碎片...')
      set({ status: AppStatus.LOADING })  // 設置載入狀態
      
      const fragments = await apiClient.getFragments()
      
      set({ 
        fragments,
        status: fragments.length > 0 ? AppStatus.READY : AppStatus.EMPTY,
        error: null,
        hasInitialized: true  // 確保標記為已初始化
      })
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : '載入失敗'
      console.error('❌ 載入碎片失敗:', error)
      set({ 
        status: AppStatus.ERROR,
        error: errorMessage,
        fragments: [],
        hasInitialized: true
      })
    }
  },

  // === Setters（保持不變） ===
  setFragments: (fragments) => set({ fragments }),
  setSearchQuery: (query) => set({ searchQuery: query }),
  setSelectedTags: (tags) => set({ selectedTags: tags }),
  setExcludedTags: (tags) => set({ excludedTags: tags }),
  setTagLogicMode: (mode) => set({ tagLogicMode: mode }),
  setSortField: (field) => set({ sortField: field }),
  setSortOrder: (order) => set({ sortOrder: order }),
  setSelectedFragment: (fragment) => set({ selectedFragment: fragment }),
  setMode: (mode) => set({ mode }),  // 🔧 恢復：setMode 實作
  setAdvancedSearch: (search) => set({ advancedSearch: search }),
  setSearchKeyword: (keyword) => set({ searchKeyword: keyword }),
  setError: (error) => set({ error }),

  // === 篩選方法（需要處理 null 情況） ===
  getFilteredFragments: () => {
    const {
      fragments,
      searchQuery,
      selectedTags,
      excludedTags,
      tagLogicMode,
      advancedSearch
    } = get()

    // 🎯 處理未載入狀態
    if (!fragments) return []
  
    if (advancedSearch) {
      return get().getFilteredFragmentsByAdvancedSearch()
    }
  
    const mode = 'substring'
    
    return fragments.filter(fragment => {
      if (searchQuery && !matchText(fragment.content, searchQuery, mode)) {
        const noteMatches = fragment.notes.some(note => 
          matchText(note.title, searchQuery, mode) || 
          matchText(note.value, searchQuery, mode)
        )
        if (!noteMatches) return false
      }
  
      if (excludedTags.length > 0 && excludedTags.some(tag => fragment.tags.includes(tag))) {
        return false
      }
  
      if (selectedTags.length === 0) return true
  
      return tagLogicMode === 'AND'
        ? selectedTags.every(tag => fragment.tags.includes(tag))
        : selectedTags.some(tag => fragment.tags.includes(tag))
    })
  },

  getFilteredFragmentsByAdvancedSearch: () => {
    const { fragments, advancedSearch } = get()
    
    // 🎯 處理未載入狀態
    if (!fragments || !advancedSearch) return fragments || []
  
    const {
      tokens,
      scopes,
      matchMode,
      timeRange,
      customStartDate,
      customEndDate
    } = advancedSearch
  
    return fragments.filter(fragment => {
      if (!scopes.includes('fragment') && !scopes.includes('note') && !scopes.includes('tag')) {
        return false
      }
  
      const dateField = fragment.updatedAt || fragment.createdAt
      if (!isDateInRange(dateField, timeRange, customStartDate, customEndDate)) {
        return false
      }
  
      return matchFragment(fragment, tokens, matchMode, scopes)
    })
  },

  // 🚀 簡化的樂觀更新 - 需要處理 null
  addFragment: async (content, tags, notes) => {
    if (!isClient) return
    
    const currentFragments = get().fragments
    // 🎯 如果還沒載入，就不能添加
    if (!currentFragments) {
      console.warn('碎片尚未載入，無法添加新碎片')
      return
    }
    
    // 創建樂觀 Fragment
    const tempId = `temp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const optimisticFragment: Fragment = {
      id: tempId,
      content,
      tags,
      notes,
      type: 'fragment',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      creator: 'current-user',
      lastEditor: 'current-user',
      childIds: [],
      relations: [],
      _optimistic: true,  // 簡單標記
      _pending: true
    } as Fragment

    // 立即更新 UI
    set(state => ({
      fragments: state.fragments ? [optimisticFragment, ...state.fragments] : [optimisticFragment],
      status: AppStatus.READY  // 確保狀態正確
    }))

    try {
      const newFragment = await apiClient.createFragment({
        content, tags, notes, type: 'fragment'
      })
      
      // 成功：替換為真實 Fragment
      set(state => ({
        fragments: state.fragments ? state.fragments.map(f => 
          f.id === tempId ? newFragment : f
        ) : [newFragment]
      }))

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : '創建失敗'
      console.error('❌ 創建碎片失敗:', error)
      
      // 失敗：移除樂觀 Fragment
      set(state => ({
        fragments: state.fragments ? state.fragments.filter(f => f.id !== tempId) : [],
        error: errorMessage
      }))
    }
  },

  // 🚀 簡化的刪除
  deleteFragment: async (fragmentId: string) => {
    const currentFragments = get().fragments
    if (!currentFragments) return

    const originalFragment = currentFragments.find(f => f.id === fragmentId)
    if (!originalFragment) return

    // 樂觀刪除
    set(state => ({
      fragments: state.fragments ? state.fragments.filter(f => f.id !== fragmentId) : [],
      selectedFragment: state.selectedFragment?.id === fragmentId ? null : state.selectedFragment
    }))

    try {
      await apiClient.deleteFragment(fragmentId)
      console.log(`✅ 刪除成功: ${fragmentId}`)
    } catch (error) {
      console.error(`❌ 刪除失敗: ${fragmentId}`, error)
      
      // 失敗：恢復 Fragment
      set(state => ({
        fragments: state.fragments ? [originalFragment, ...state.fragments] : [originalFragment],
        error: error instanceof Error ? error.message : '刪除失敗'
      }))
    }
  },

  // === Note 操作（需要處理 null） ===
  addNoteToFragment: async (fragmentId, note) => {
    const currentFragments = get().fragments
    if (!currentFragments) return

    try {
      const addedNote = await apiClient.addNoteToFragment(fragmentId, note)
      set(state => ({
        fragments: state.fragments ? state.fragments.map(f =>
          f.id === fragmentId
            ? { ...f, notes: [...f.notes, addedNote], updatedAt: new Date().toISOString() }
            : f
        ) : []
      }))
    } catch (error) {
      console.error('添加筆記失敗:', error)
      set({ error: error instanceof Error ? error.message : '添加筆記失敗' })
    }
  },

  updateNoteInFragment: async (fragmentId, noteId, updates) => {
    const currentFragments = get().fragments
    if (!currentFragments) return

    try {
      await apiClient.updateNote(fragmentId, noteId, updates)
      set(state => ({
        fragments: state.fragments ? state.fragments.map(f =>
          f.id === fragmentId
            ? {
              ...f,
              notes: f.notes.map(n => n.id === noteId ? { ...n, ...updates } : n),
              updatedAt: new Date().toISOString()
            }
            : f
        ) : []
      }))
    } catch (error) {
      console.error('更新筆記失敗:', error)
      set({ error: error instanceof Error ? error.message : '更新筆記失敗' })
    }
  },

  removeNoteFromFragment: async (fragmentId, noteId) => {
    const currentFragments = get().fragments
    if (!currentFragments) return

    try {
      await apiClient.deleteNote(fragmentId, noteId)
      set(state => ({
        fragments: state.fragments ? state.fragments.map(f =>
          f.id === fragmentId
            ? {
              ...f,
              notes: f.notes.filter(n => n.id !== noteId),
              updatedAt: new Date().toISOString()
            }
            : f
        ) : []
      }))
    } catch (error) {
      console.error('刪除筆記失敗:', error)
      set({ error: error instanceof Error ? error.message : '刪除筆記失敗' })
    }
  },

  // === Tag 操作 ===
  addTagToFragment: async (fragmentId, tag) => {
    const currentFragments = get().fragments
    if (!currentFragments) return

    try {
      await apiClient.addTagToFragment(fragmentId, tag)
      set(state => ({
        fragments: state.fragments ? state.fragments.map(f =>
          f.id === fragmentId && !f.tags.includes(tag)
            ? { ...f, tags: [...f.tags, tag], updatedAt: new Date().toISOString() }
            : f
        ) : []
      }))
    } catch (error) {
      console.error('添加標籤失敗:', error)
      set({ error: error instanceof Error ? error.message : '添加標籤失敗' })
    }
  },

  removeTagFromFragment: async (fragmentId, tag) => {
    const currentFragments = get().fragments
    if (!currentFragments) return

    try {
      await apiClient.removeTagFromFragment(fragmentId, tag)
      set(state => ({
        fragments: state.fragments ? state.fragments.map(f =>
          f.id === fragmentId
            ? { ...f, tags: f.tags.filter(t => t !== tag), updatedAt: new Date().toISOString() }
            : f
        ) : []
      }))
    } catch (error) {
      console.error('移除標籤失敗:', error)
      set({ error: error instanceof Error ? error.message : '移除標籤失敗' })
    }
  }
}))

// 🎯 修復的狀態 Hook
export function useAppState() {
  const { status, error, fragments, hasInitialized } = useFragmentsStore()
  
  return {
    status,
    error,
    fragments,
    hasInitialized,
    
    // 🔧 修復：確保狀態檢查邏輯正確
    isLoading: status === AppStatus.LOADING,
    isReady: status === AppStatus.READY && hasInitialized,
    isEmpty: status === AppStatus.EMPTY && hasInitialized,
    needsAuth: status === AppStatus.UNAUTHENTICATED,
    hasError: status === AppStatus.ERROR,
    
    // 🎯 數據狀態檢查
    isDataLoaded: hasInitialized && fragments !== null,
    hasFragments: hasInitialized && Array.isArray(fragments) && fragments.length > 0,
    
    // 便捷方法
    initialize: useFragmentsStore(state => state.initialize)
  }
}