import { supabase } from '@/lib/supabaseClient'
import { Note } from '@/features/fragments/types/fragment'

const TABLE = 'notes'

export async function addNote(fragmentId: string, note: Note) {
  const { error } = await supabase.from(TABLE).insert({
    ...note,
    fragment_id: fragmentId,
  })
  if (error) console.error('❌ 新增 note 失敗:', error.message)
}

export async function updateNote(noteId: string, updates: Partial<Note>) {
  const { error } = await supabase
    .from(TABLE)
    .update(updates)
    .eq('id', noteId)
  if (error) console.error('❌ 更新 note 失敗:', error.message)
}

export async function deleteNote(noteId: string) {
  const { error } = await supabase
    .from(TABLE)
    .delete()
    .eq('id', noteId)
  if (error) console.error('❌ 刪除 note 失敗:', error.message)
}

export async function getNotesByFragmentId(fragmentId: string): Promise<Note[]> {
  const { data, error } = await supabase
    .from(TABLE)
    .select('*')
    .eq('fragment_id', fragmentId)

  if (error) {
    console.error('❌ 載入 note 失敗:', error.message)
    return []
  }

  return data as Note[]
}
