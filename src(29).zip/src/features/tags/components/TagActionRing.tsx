'use client'

import React, { useState, useEffect } from 'react'
import { useTagCollectionStore } from '@/features/tags/store/useTagCollectionStore'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { TagsService, SimilarTag } from '@/features/tags/services/TagsService'

interface TagActionRingProps {
  tag: string
  position: { x: number; y: number }
  onClose: () => void
  onOpenDetail: (tag: string) => void
}

const TagActionRing: React.FC<TagActionRingProps> = ({
  tag,
  position,
  onClose,
  onOpenDetail,
}) => {
  const { isCollected, addTag } = useTagCollectionStore()
  const { fragments } = useFragmentsStore()
  const alreadyCollected = isCollected(tag)
  const [showSimilar, setShowSimilar] = useState(false)
  const [similarTags, setSimilarTags] = useState<SimilarTag[]>([])
  const [isLoading, setIsLoading] = useState(false)

  // 找出相似標籤
  useEffect(() => {
    if (showSimilar && similarTags.length === 0) {
      setIsLoading(true)
      
      // 異步計算相似標籤，避免阻塞UI
      setTimeout(() => {
        // 使用TagsService找尋相似標籤
        const similar = TagsService.findSimilarTagsByCooccurrence(tag, 5)
        setSimilarTags(similar)
        setIsLoading(false)
      }, 0)
    }
  }, [showSimilar, tag, fragments, similarTags.length])

  // 計算此標籤在幾個片段中出現
  const fragmentsWithTag = fragments.filter(f => f.tags.includes(tag)).length

  return (
    <div
      style={{
        position: 'fixed', // 改為 fixed 確保在滾動時位置正確
        top: position.y,
        left: position.x,
        transform: 'translate(-50%, -50%)',
        backgroundColor: '#fff8e1',
        border: '1px solid #d2b48c',
        borderRadius: '9999px',
        padding: '12px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
        zIndex: 2000,
        display: 'flex',
        gap: '10px',
        justifyContent: 'center',
        alignItems: 'center',
      }}
      onClick={(e) => e.stopPropagation()}
    >
      {/* 標籤資訊小提示 */}
      <div
        style={{
          position: 'absolute',
          top: '-24px',
          left: '50%',
          transform: 'translateX(-50%)',
          backgroundColor: 'rgba(255, 248, 225, 0.9)',
          padding: '2px 8px',
          borderRadius: '4px',
          fontSize: '10px',
          color: '#8d6a38',
          whiteSpace: 'nowrap',
        }}
      >
        {`${tag} (${fragmentsWithTag}個碎片)`}
      </div>

      {/* 查看詳情 */}
      <button
        onClick={() => {
          onOpenDetail(tag)
          onClose()
        }}
        style={actionStyle}
      >
        🔍 詳情
      </button>

      {/* 加入收藏 */}
      <button
        onClick={() => {
          if (!alreadyCollected) {
            addTag(tag)
          }
          onClose()
        }}
        disabled={alreadyCollected}
        style={{
          ...actionStyle,
          opacity: alreadyCollected ? 0.5 : 1,
          cursor: alreadyCollected ? 'not-allowed' : 'pointer',
        }}
      >
        ⭐ {alreadyCollected ? '已收藏' : '收藏'}
      </button>

      {/* 相似標籤 */}
      <button
        onClick={() => setShowSimilar(!showSimilar)}
        style={{
          ...actionStyle,
          backgroundColor: showSimilar ? '#f1d2a2' : '#f3e8c7',
        }}
      >
        🔄 相似
      </button>

      {/* 關閉按鈕 */}
      <button
        onClick={onClose}
        style={{
          ...actionStyle,
          backgroundColor: '#eee',
        }}
      >
        ✖
      </button>

      {/* 相似標籤面板 */}
      {showSimilar && (
        <div
          style={{
            position: 'absolute',
            top: '100%',
            left: '50%',
            transform: 'translateX(-50%)',
            marginTop: '10px',
            backgroundColor: '#fff8e1',
            border: '1px solid #d2b48c',
            borderRadius: '8px',
            padding: '8px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            zIndex: 2001,
            minWidth: '120px',
          }}
        >
          <div style={{ fontSize: '12px', marginBottom: '6px', color: '#8d6a38' }}>
            相似標籤:
          </div>
          {isLoading ? (
            <div style={{ fontSize: '11px', color: '#999', textAlign: 'center', padding: '4px' }}>
              載入中...
            </div>
          ) : similarTags.length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
              {similarTags.map(t => (
                <div
                  key={t.name}
                  style={{
                    backgroundColor: '#f3e8c7',
                    color: '#8d6a38',
                    borderRadius: '8px',
                    padding: '4px 8px',
                    fontSize: '11px',
                    cursor: 'pointer',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}
                  onClick={() => {
                    // 可以在這裡實現點擊相似標籤的操作，例如顯示其詳情
                    onOpenDetail(t.name)
                    onClose()
                  }}
                >
                  <span>{t.name}</span>
                  <span style={{ fontSize: '9px', color: '#aa8866', marginLeft: '4px' }}>
                    {t.count}次
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ fontSize: '11px', color: '#999', textAlign: 'center', padding: '4px' }}>
              沒有相似標籤
            </div>
          )}
        </div>
      )}
    </div>
  )
}

const actionStyle: React.CSSProperties = {
  padding: '6px 10px',
  backgroundColor: '#f3e8c7',
  color: '#6b4d2e',
  border: 'none',
  borderRadius: '8px',
  fontSize: '12px',
  cursor: 'pointer',
  whiteSpace: 'nowrap',
}

export default TagActionRing