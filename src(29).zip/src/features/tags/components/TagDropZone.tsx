'use client'

import React, { useEffect, useRef, useState } from 'react'
import { useTagDragManager } from '@/features/fragments/layout/useTagDragManager'
import { useTagCollectionStore } from '@/features/tags/store/useTagCollectionStore'


const TagDropZone: React.FC = () => {
  const { draggingTag, isDragging } = useTagDragManager()
  const { isCollected, addTag } = useTagCollectionStore()

  const ref = useRef<HTMLDivElement>(null)
  const [isOver, setIsOver] = useState(false)

  // 用滑鼠位置判斷有沒有進入 drop 區域
  useEffect(() => {
    const checkHover = (e: MouseEvent) => {
      if (!ref.current) return
      const rect = ref.current.getBoundingClientRect()
      const inside =
        e.clientX >= rect.left &&
        e.clientX <= rect.right &&
        e.clientY >= rect.top &&
        e.clientY <= rect.bottom
      setIsOver(inside)
    }

    if (isDragging) {
      window.addEventListener('mousemove', checkHover)
    } else {
      setIsOver(false)
    }

    return () => window.removeEventListener('mousemove', checkHover)
  }, [isDragging])

  // 放開滑鼠時觸發收藏
  useEffect(() => {
    const handleMouseUp = () => {
      if (!draggingTag || !isDragging) return
      if (isOver) {
        if (!isCollected(draggingTag)) {
          addTag(draggingTag)
          console.log('✅ 已收藏標籤:', draggingTag)
        } else {
          console.log('⚠️ 已經收藏過:', draggingTag)
        }
      }
    }

    window.addEventListener('mouseup', handleMouseUp)
    return () => window.removeEventListener('mouseup', handleMouseUp)
  }, [draggingTag, isDragging, isOver, isCollected, addTag])

  if (!isDragging || !draggingTag) return null

  const label = isCollected(draggingTag) ? '已收藏' : '新增標籤'

  return (
    <div
      ref={ref}
      style={{
        border: '2px dashed rgba(160, 120, 80, 0.5)',
        backgroundColor: isOver ? 'rgba(255, 250, 230, 0.6)' : 'transparent',
        backdropFilter: isOver ? 'blur(4px)' : 'none',
        borderRadius: '12px',
        padding: '24px 32px',
        color: '#7a5d3a',
        fontSize: '14px',
        fontWeight: 600,
        zIndex: 2000,
        pointerEvents: 'auto',
        transition: 'all 0.2s ease',
        boxShadow: isOver ? '0 4px 12px rgba(0,0,0,0.15)' : 'none',
        textAlign: 'center',
      }}
    >
      {label}
    </div>
  )
}

export default TagDropZone
