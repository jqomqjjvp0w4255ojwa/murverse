'use client'

import React from 'react'
import { Fragment } from '@/features/fragments/types/fragment'

interface TagDetailModalProps {
  tag: string
  relatedFragments: Fragment[]
  onClose: () => void
}

const TagDetailModal: React.FC<TagDetailModalProps> = ({
  tag,
  relatedFragments,
  onClose,
}) => {
  return (
    <div
      style={{
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        backgroundColor: '#fff8e1',
        border: '1px solid #d2b48c',
        borderRadius: '8px',
        padding: '20px',
        width: '400px',
        maxHeight: '80vh',
        overflowY: 'auto',
        zIndex: 3000,
        boxShadow: '0 8px 24px rgba(0,0,0,0.2)',
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <h2 style={{ fontSize: '16px', color: '#5c4123' }}>標籤：{tag}</h2>
        <button
          onClick={onClose}
          style={{
            border: 'none',
            background: 'transparent',
            fontSize: '18px',
            cursor: 'pointer',
            color: '#999',
          }}
        >
          ✖
        </button>
      </div>

      <p style={{ fontSize: '13px', color: '#666' }}>
        此標籤出現在 {relatedFragments.length} 筆碎片中：
      </p>

      <ul style={{ marginTop: '10px', paddingLeft: '16px' }}>
        {relatedFragments.map((frag) => (
          <li key={frag.id} style={{ marginBottom: '8px', fontSize: '13px' }}>
            <strong>{(frag.content ?? '').slice(0, 20)}...</strong>
            <div
              style={{
                fontSize: '12px',
                color: '#888',
                marginTop: '2px',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
            >
              {frag.content.slice(0, 60)}...
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default TagDetailModal
