// src/app/page.tsx
'use client'

import { useEffect, useState } from 'react'
import dynamic from 'next/dynamic'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { Fragment } from '@/features/fragments/types/fragment'
import { useTagDragManager } from '@/features/fragments/layout/useTagDragManager'
import AuthButton from '@/features/fragments/components/AuthButton'
import { getSupabaseClient } from '@/lib/supabase/client'

// 動態導入組件
const TagsFloatingWindow = dynamic(() =>
  import('@/features/tags/TagsDrawerWindow').then(mod => ({
    default: (mod as any).default
  })),
  { ssr: false }
)

const FloatingFragmentsField = dynamic(() => import('@/features/fragments/FloatingFragmentsField'), { ssr: false })
const FragmentDetailModal = dynamic(() => import('@/features/fragments/components/FragmentDetailModal'), { ssr: false })
const FloatingInputBar = dynamic(() => import('@/features/input/FloatingInputBar'), { ssr: false })
const FloatingActionButton = dynamic(() => import('@/features/fragments/components/FloatingActionButton'), { ssr: false })
const GroupFrame = dynamic(() => import('@/features/windows/GroupFrame'), { ssr: false })
const FragmentsView = dynamic(() => import('@/features/fragments/FragmentsView'), { ssr: false })

// 標籤拖曳相關組件
const TagDragPreview = dynamic(() => import('@/features/fragments/components/TagDragPreview'), { ssr: false })
const DragToDeleteZone = dynamic(() => import('@/features/tags/components/DragToDeleteZone'), { ssr: false })

export default function Home() {
  // 檢查是否在客戶端
  const [isClient, setIsClient] = useState(false)
  const [currentMode, setCurrentMode] = useState('float')
  const [fragment, setFragment] = useState<Fragment | null>(null)
  const [isHandlingAuth, setIsHandlingAuth] = useState(false)

  // 使用標籤拖曳管理器（只在客戶端）
  const { draggingTag, dragPosition, isDragging } = useTagDragManager()
  
  // 使用 store（只在客戶端）
  const { mode, load, initialize } = useFragmentsStore()

  // 設定關閉函數
  const handleClose = () => {
    setFragment(null)
  }

  // 🔧 新增：處理認證回調
  useEffect(() => {
    const handleAuthCallback = async () => {
      if (typeof window === 'undefined') return
      
      // 檢查 URL 是否包含認證回調參數
      if (window.location.hash.includes('access_token')) {
        console.log('🔑 檢測到認證回調，處理中...')
        setIsHandlingAuth(true)
        
        try {
          const supabase = getSupabaseClient()
          if (!supabase) {
            console.error('❌ 無法獲取 Supabase 客戶端')
            return
          }

          // 等待 Supabase 自動處理認證回調
          await new Promise(resolve => setTimeout(resolve, 1000))
          
          // 檢查認證狀態
          const { data: { session }, error } = await supabase.auth.getSession()
          
          if (error) {
            console.error('❌ 認證回調處理失敗:', error)
          } else if (session) {
            console.log('✅ 認證成功！用戶:', session.user.email)
            
            // 清除 URL hash 並重定向到首頁
            window.history.replaceState({}, document.title, window.location.pathname)
            
            // 觸發應用初始化
            await initialize()
            
            console.log('🏠 已重定向到首頁')
          } else {
            console.log('ℹ️ 認證回調處理完成，但未找到有效會話')
          }
        } catch (error) {
          console.error('💥 處理認證回調時發生錯誤:', error)
        } finally {
          setIsHandlingAuth(false)
        }
      }
    }
    
    // 延遲執行，確保客戶端環境準備好
    const timer = setTimeout(handleAuthCallback, 100)
    return () => clearTimeout(timer)
  }, [initialize])

  useEffect(() => {
    // 設定客戶端標記
    setIsClient(true)
  }, [])

  useEffect(() => {
    if (!isClient || isHandlingAuth) return

    // 只有不在處理認證回調時才執行正常初始化
    if (!window.location.hash.includes('access_token')) {
      // 確保只在客戶端執行
      initialize() // 使用 initialize 而不是 load
    }
    
    // 同步 mode 到本地狀態
    setCurrentMode(mode)
    
    // 訂閱 mode 變化
    const unsubscribe = useFragmentsStore.subscribe(
      state => setCurrentMode(state.mode)
    )
    
    return () => {
      if (typeof unsubscribe === 'function') {
        unsubscribe()
      }
    }
  }, [isClient, isHandlingAuth, initialize, mode])
  
  // 在服務器端渲染或處理認證回調時返回載入畫面
  if (!isClient || isHandlingAuth) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg">
          {isHandlingAuth ? '處理登入中...' : 'Loading...'}
        </div>
      </div>
    )
  }
  
  return (
    <>
     <AuthButton />

      {/* 主內容區域和浮動窗口 */}
      {currentMode === 'float' && (
        <>
          <FloatingFragmentsField />
          <FloatingInputBar />
          <TagsFloatingWindow />
          <GroupFrame />
         </>
    )}

      {/* 清單模式 - 保持原樣 */}
      {currentMode === 'list' && (
        <FragmentsView />
      )}

      {/* 公用組件 - 不受 Tab 影響 */}
      <FragmentDetailModal fragment={fragment} onClose={() => setFragment(null)} />
      <FloatingActionButton />
      
      {/* 標籤拖曳預覽 - 在所有視圖模式下都顯示 */}
      {isDragging && draggingTag && dragPosition && (
        <TagDragPreview tag={draggingTag} position={dragPosition} />
      )}
      
      {/* 標籤刪除區域 - 只在拖曳標籤時顯示 */}
      <DragToDeleteZone position="bottom-right" />
      
      {/* 全局樣式 */}
      <style jsx global>{`
        /* 原有的拖曳目標高亮樣式 */
        .fragment-card.tag-drop-target {
          box-shadow: 0 0 0 2px rgba(201, 155, 53, 0.7) !important;
          transform: scale(1.02) !important;
          transition: all 0.2s ease !important;
        }
        
        /* 直排標籤文字修正 */
        .tag-button[style*="writing-mode: vertical-rl"] {
          white-space: normal !important;
          overflow: hidden !important;
          word-break: break-all !important;
          line-height: 1.2 !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          text-align: center !important;
        }
        
        /* 移除 Tab 模式的左側 margin，讓內容區域佔滿整個螢幕 */
        .floating-fragments-container {
          margin-left: 0; /* 改為 0，移除左側空白區域 */
          transition: margin-left 0.3s ease;
        }
      `}</style>
    </>
  )
}