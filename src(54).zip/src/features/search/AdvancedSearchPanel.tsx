'use client'

import React, { useState, useRef, useEffect } from 'react'
import { useSearchStore } from '@/features/search/useSearchStore'
import { useAdvancedSearch, SearchScope, MatchMode, TimeRange } from '@/features/search/useAdvancedSearch'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { SearchService } from '@/features/search/SearchService'

interface AdvancedSearchPanelProps {
  onSearch: (results: any) => void
  initialQuery?: string
  noResults?: boolean
  searchedKeyword?: string
  onResetNoResults?: () => void
  onClearLocalSearch?: () => void
}

const AdvancedSearchPanel: React.FC<AdvancedSearchPanelProps> = ({
  onSearch,
  initialQuery = '',
  noResults = false,
  searchedKeyword = '',
  onResetNoResults,
  onClearLocalSearch, 
}) => {

  const {
    query,
    scopes,
    matchMode,
    timeRange,
    customDateRange,
    setQuery,
    setScopes,
    setMatchMode,
    setTimeRange,
    setCustomTimeRange,
    executeSearch,
    clearSearch
  } = useAdvancedSearch()

  const searchOptionsRef = useRef<HTMLDivElement>(null)
  const [startDate, setStartDate] = useState<string>('')
  const [endDate, setEndDate] = useState<string>('')

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleExecuteSearch();
    }
  };

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery)
    }
  }, [initialQuery, setQuery])

  const handleExecuteSearch = () => {
    const fragments = useFragmentsStore.getState().fragments;
    const searchStore = useSearchStore.getState();
  
    // 🚀 修復：檢查 fragments 是否為 null 或空陣列
    if (!fragments || fragments.length === 0) {
      console.warn('⚠️ 沒有可搜尋的碎片數據')
      onSearch([])
      return
    }

    // 🔧 **關鍵修復**：確保同步完成後再執行搜尋
    console.log('🔄 同步前的狀態:', {
      advancedSearchState: { query, scopes, matchMode, timeRange },
      searchStoreState: { 
        keyword: searchStore.keyword, 
        scopes: searchStore.scopes, 
        matchMode: searchStore.matchMode 
      }
    })

    // 立即同步所有搜尋設定到 SearchStore（移除 setTimeout）
    searchStore.setKeyword(query)
    searchStore.setScopes(scopes)
    searchStore.setMatchMode(matchMode)
    searchStore.setTimeRange(timeRange)
    
    if (timeRange === 'custom') {
      searchStore.setCustomDateRange(customDateRange.start, customDateRange.end)
    }

    // 🔧 **重要**：重新獲取最新狀態確保同步
    const updatedSearchStore = useSearchStore.getState()
    console.log('🔄 同步後的狀態:', {
      updatedSearchStore: { 
        keyword: updatedSearchStore.keyword, 
        scopes: updatedSearchStore.scopes, 
        matchMode: updatedSearchStore.matchMode 
      }
    })

    // 🔧 **使用最新的同步狀態**
    const finalSearchOptions = {
      keyword: query,
      tokens: [], // 確保使用 keyword 路徑
      scopes: scopes, // 使用 AdvancedSearch 的狀態
      matchMode: matchMode, // 使用 AdvancedSearch 的狀態
      timeRange: timeRange, // 使用 AdvancedSearch 的狀態
      customStartDate: customDateRange.start,
      customEndDate: customDateRange.end,
      selectedTags: updatedSearchStore.selectedTags || [],
      excludedTags: updatedSearchStore.excludedTags || [],
      tagLogicMode: updatedSearchStore.tagLogicMode || 'AND'
    };
  
    console.log('🔍 執行搜尋 with 確認設定:', finalSearchOptions);
  
    // 🚀 直接使用 SearchService
    const results = SearchService.search(fragments, finalSearchOptions);

    // 🔧 同步更新所有相關狀態
    useFragmentsStore.getState().setSearchKeyword(query);
    updatedSearchStore.setSearchResults(results);

    console.log(`✅ 搜尋完成，共找到 ${results.length} 筆資料`);
  
    // 回傳結果給外部元件
    onSearch(results);
  };

  const handleClearSearch = () => {
    /* 1. 清空父层输入框（TagsSearchBar） */
    onClearLocalSearch?.();

    /* 2. 一键还原 AdvancedSearch 内部全部状态（含日期） */
    clearSearch();
    setQuery('');
    setStartDate('');
    setEndDate('');

    /* 3. 完全清理全域 SearchStore */
    const searchStore = useSearchStore.getState();
    searchStore.clearSearch();

    /* 4. 告诉父层回复显示全部碎片 */
    const allFragments = useFragmentsStore.getState().fragments;
    onSearch(allFragments || []);

    /* 5. 关闭「沒有結果」提示 */
    onResetNoResults?.();
  };

  const toggleScope = (scope: SearchScope) => {
    if (scopes.includes(scope)) {
      if (scopes.length > 1) {
        const newScopes = scopes.filter(s => s !== scope);
        setScopes(newScopes);
        
        // 🔧 立即同步到 SearchStore（移除 setTimeout）
        useSearchStore.getState().setScopes(newScopes);
        console.log("✅ 立即同步搜索範圍:", newScopes);
      }
    } else {
      const newScopes = [...scopes, scope];
      setScopes(newScopes);
      
      // 🔧 立即同步到 SearchStore（移除 setTimeout）
      useSearchStore.getState().setScopes(newScopes);
      console.log("✅ 立即同步搜索範圍:", newScopes);
    }
  };

  // 🔧 比對方式變更處理
  const handleMatchModeChange = (mode: MatchMode) => {
    setMatchMode(mode)
    
    // 🔧 立即同步到 SearchStore（移除 setTimeout）
    useSearchStore.getState().setMatchMode(mode);
    console.log("✅ 立即同步比對方式:", mode);
  }

  // 🔧 時間範圍變更處理
  const handleTimeRangeChange = (range: TimeRange) => {
    setTimeRange(range)
    
    // 🔧 立即同步到 SearchStore（移除 setTimeout）
    useSearchStore.getState().setTimeRange(range);
    console.log("✅ 立即同步時間範圍:", range);
  }

  return (
    <div className="w-full">
       {/* 搜尋提示 - 移到搜尋條件前 */}
       {noResults && searchedKeyword.trim() && (
      <div className="mb-2 flex items-center gap-2 px-3 py-2 bg-pink-50 text-pink-700 rounded-md">
        <svg
          className="w-4 h-4 flex-shrink-0"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4m0 4h.01M21 12A9 9 0 113 12a9 9 0 0118 0z" />
        </svg>
        <span className="text-xs">
          找不到符合「<span className="font-semibold">{searchedKeyword}</span>」的內容喔！
        </span>
      </div>
    )}
      
      <div ref={searchOptionsRef} className="mb-2 bg-white rounded-lg text-sm">
       
        {/* 搜尋設定列 */}
        <div className="mb-2 p-2 bg-gray-50 rounded-md space-y-3">
          <div className="text-sm font-bold text-gray-700">搜尋方式</div>
          <div className="flex flex-col gap-3">

            {/* 搜尋範圍 */}
            <div className="flex items-center gap-2 relative pb-2 mb-2 after:absolute after:left-0 after:bottom-0 after:w-full after:h-px after:bg-gray-200">
              <span className="text-sm font-medium text-gray-500 min-w-[36px]">範圍</span>
              {[{ label: '碎片', value: 'fragment' }, { label: '筆記', value: 'note' }, { label: '標籤', value: 'tag' }].map(({ label, value }) => (
                <button
                  key={value}
                  onClick={() => toggleScope(value as SearchScope)}
                  type="button"
                  className={`px-2 py-0.5 rounded-full border text-xs transition 
                    ${scopes.includes(value as SearchScope)
                      ? 'bg-pink-100 text-pink-700 border-pink-300'
                      : 'border-gray-300 text-gray-600 hover:border-pink-300 hover:text-pink-700'}`}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* 比對方式（整合） */}
            <div className="flex items-center gap-2 relative pb-2 mb-2 after:absolute after:left-0 after:bottom-0 after:w-full after:h-px after:bg-gray-200">
              <span className="text-sm font-medium text-gray-500 min-w-[36px]">比對</span>
              {[{ label: '完全符合', value: 'exact' },
                { label: '開頭符合', value: 'prefix' },
                { label: '包含', value: 'substring' }].map(({ label, value }) => (
                <button
                  key={value}
                  onClick={() => handleMatchModeChange(value as MatchMode)}
                  type="button"
                  className={`px-2 py-0.5 rounded-full border text-xs transition 
                    ${matchMode === value
                      ? 'bg-pink-100 text-pink-700 border-pink-300'
                      : 'border-gray-300 text-gray-600 hover:border-pink-300 hover:text-pink-700'}`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 時間範圍 */}
        <div className="mb-2 p-2 bg-gray-50 rounded-md">
          <div className="text-sm font-semibold text-gray-800 mb-1">時間範圍</div>
          <div className="flex gap-2 flex-wrap">
            {[{ label: '全部時間', value: 'all' }, { label: '今天', value: 'today' }, { label: '本週', value: 'week' }, { label: '本月', value: 'month' }, { label: '自訂範圍', value: 'custom' }].map(({ label, value }) => (
              <button
                key={value}
                onClick={() => handleTimeRangeChange(value as TimeRange)}
                type="button"
                className={`px-2 py-0.5 rounded-full border text-xs transition 
                  ${timeRange === value
                    ? 'bg-pink-100 text-pink-700 border-pink-300'
                    : 'border-gray-300 text-gray-600 hover:border-pink-300 hover:text-pink-700'}`}
              >
                {label}
              </button>
            ))}
          </div>

          {timeRange === 'custom' && (
            <div className="mt-2 grid grid-cols-2 gap-2">
              <input
                type="date"
                value={startDate}
                className="w-full p-1.5 border border-gray-300 rounded text-sm"
                onChange={(e) => {
                  setStartDate(e.target.value);
                  if (e.target.value) {
                    const start = new Date(e.target.value);
                    setCustomTimeRange(start, endDate ? new Date(endDate) : undefined);
                    
                    // 🔧 同步到 SearchStore
                    setTimeout(() => {
                      useSearchStore.getState().setCustomDateRange(start, endDate ? new Date(endDate) : undefined);
                      console.log("✅ 同步自訂開始日期:", start);
                    }, 0);
                  }
                }}
              />
              <input
                type="date"
                value={endDate}
                className="w-full p-1.5 border border-gray-300 rounded text-sm"
                onChange={(e) => {
                  setEndDate(e.target.value);
                  if (e.target.value) {
                    const end = new Date(e.target.value);
                    end.setHours(23, 59, 59, 999);
                    setCustomTimeRange(startDate ? new Date(startDate) : undefined, end);
                    
                    // 🔧 同步到 SearchStore
                    setTimeout(() => {
                      useSearchStore.getState().setCustomDateRange(startDate ? new Date(startDate) : undefined, end);
                      console.log("✅ 同步自訂結束日期:", end);
                    }, 0);
                  }
                }}
              />
            </div>
          )}
        </div>

        {/* 🔧 調試資訊（開發模式） */}
        {process.env.NODE_ENV === 'development' && (
          <div className="mb-2 p-2 bg-yellow-50 rounded-md text-xs">
            <div className="font-semibold text-yellow-800 mb-1">🔧 搜尋設定狀態</div>
            <div className="text-yellow-700">
              <div>範圍: {scopes.join(', ')}</div>
              <div>比對: {matchMode}</div>
              <div>時間: {timeRange}</div>
              {timeRange === 'custom' && (
                <div>自訂: {startDate || '未設定'} ~ {endDate || '未設定'}</div>
              )}
            </div>
          </div>
        )}

        {/* 操作按鈕 */}
        <div className="flex items-center pb-1">
          <button
            type="button"
            onClick={handleClearSearch}
            className="ml-auto px-3 py-0.5 text-gray-600 text-sm rounded hover:bg-gray-100"
          >
            清除條件
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdvancedSearchPanel;