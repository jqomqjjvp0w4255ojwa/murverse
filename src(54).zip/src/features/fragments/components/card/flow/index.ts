// 📄 src/features/fragments/components/card/flow/index.ts

export { default as FlowFragmentCard } from './FlowFragmentCard'