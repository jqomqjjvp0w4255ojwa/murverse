// src/features/input/FloatingInputBar.tsx
'use client'

import { useState, useEffect, useRef } from 'react'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { useTagsIntegration } from '@/features/tags/store/useTagsIntegration'
import { useGlobalTagsStore } from '@/features/tags/store/useGlobalTagsStore'
import { Fragment, Note } from '@/features/fragments/types/fragment'
import { v4 as uuidv4 } from 'uuid'
import { useFloatingWindow } from '@/features/windows/useFloatingWindow'
import InputBarHeader from './InputBarHeader'
import NotesList from './NotesList'
import TagsSelector from '../tags/components/TagsSelector'
import { useGroupsStore } from '@/features/windows/useGroupsStore'
import ActionButtons from './ActionButtons'

export default function FloatingInputBar() {
  // 使用 Tab 模式的 floating window hook
  const {
    windowRef: inputRef,
    pos,
    isCollapsed,
    isFullScreen,
    toggleCollapse,
    toggleFullScreen,
    handleMouseDown,
    isTabMode,
    isTabExpanded,
    isWindowVisible
  } = useFloatingWindow({
  id: 'floating-input-bar',
  defaultPosition: { 
    x: typeof window !== 'undefined' ? (window.innerWidth - 350) / 2 : 100, 
    y: typeof window !== 'undefined' ? (window.innerHeight - 200) / 2 : 100 
  },
  useTabMode: true // 啟用 Tab 模式
})

  // 從 store 獲取狀態和方法
  const { fragments, setFragments, save } = useFragmentsStore()

  const { openTagSelector: enhancedOpenTagSelector } = useTagsIntegration()
  const {
    openTagSelector,
    pendingTags, setPendingTags, clearPendingTags,
    setMode, tagsWindowRef, setConnected,
    searchMode
  } = useGlobalTagsStore()

  // 本地狀態
  const [content, setContent] = useState('')
  const [expanded, setExpanded] = useState(false)
  const [notes, setNotes] = useState<Note[]>([])
  const [hydrated, setHydrated] = useState(false)
  const [showLine, setShowLine] = useState(false)
  const [linePath, setLinePath] = useState('')
  const [animateLine, setAnimateLine] = useState(false)
  const tagButtonRef = useRef<HTMLButtonElement>(null)
  const fragmentId = useRef<string>(uuidv4())
  const totalCharCount = content.length + notes.reduce((acc, note) => acc + note.title.length + note.value.length, 0)
  const { addWindow, updateWindow, checkAndResolveOverlaps } = useGroupsStore()
  const hasRegistered = useRef(false)

  // Tab 模式：當窗口展開時自動設為展開狀態
  useEffect(() => {
    if (isTabMode && isTabExpanded) {
      setExpanded(true)
    } else if (isTabMode && !isTabExpanded) {
      setExpanded(false)
      // Tab 收合時也清理連線
      setShowLine(false)
      setConnected(false)
    }
  }, [isTabMode, isTabExpanded, setConnected])

  // 監聽斷開連線事件
  useEffect(() => {
    const handleDisconnectLine = (event: CustomEvent) => {
      const { windowId } = event.detail
      if (windowId === 'floating-input-bar') {
        setShowLine(false)
        setConnected(false)
        setMode('search')
      }
    }
    
    globalThis.window?.addEventListener('disconnect-line', handleDisconnectLine as EventListener)
    
    return () => {
      globalThis.window?.removeEventListener('disconnect-line', handleDisconnectLine as EventListener)
    }
  }, [setConnected, setMode])

  /* 在第一次渲染後初始化模式 */
  useEffect(() => { 
    setMode('search') 
  }, [setMode])

  /* 讀取草稿 */
  useEffect(() => {
    const draft = localStorage.getItem('murverse_draft')
    if (draft) {
      const parsed = JSON.parse(draft)
      setContent(parsed.content || '')
      setPendingTags(parsed.tags || [])
      setNotes(parsed.notes || [])
    }
    setHydrated(true)
  }, [setPendingTags])

  /* 展開時若沒有筆記，自動加一行 */
  useEffect(() => {
    if (expanded && notes.length === 0) {
      setNotes([{ id: uuidv4(), title: '', value: '' }])
    }
  }, [expanded, notes.length])

  /* 自動保存草稿 */
  useEffect(() => {
    localStorage.setItem('murverse_draft', JSON.stringify({
      content, tags: pendingTags, notes,
    }))
  }, [content, pendingTags, notes])

  /* 監聽展開狀態 */
  useEffect(() => {
    if (!expanded) {
      setMode('search')
    }
  }, [expanded, setMode])

  /* 點擊外部處理（Tab 模式下簡化） */
  useEffect(() => {
    if (isTabMode) return // Tab 模式下不需要點擊外部邏輯
    
    const handleClickOutside = (e: MouseEvent) => {
      const inputEl = inputRef.current
      const tagsWindowEl = tagsWindowRef.current

      if (!inputEl || !tagsWindowEl) return
      if (isFullScreen) return

      if (!inputEl.contains(e.target as Node) && !tagsWindowEl.contains(e.target as Node)) {
        setShowLine(false)
        setConnected(false)
        setMode('search')
      }
    }

    if (expanded) {
      document.addEventListener('mousedown', handleClickOutside)
      return () => {
        document.removeEventListener('mousedown', handleClickOutside)
      }
    }
  }, [expanded, isFullScreen, inputRef, tagsWindowRef, isTabMode])
  
  /* 收合時或切換全螢幕時移除連線 */
  useEffect(() => {
    if (isCollapsed || isFullScreen) {
      setShowLine(false);
      setConnected(false)
      setMode('search');
    }
  }, [isCollapsed, isFullScreen])

  /* 監聽 searchMode 的變化 */
  useEffect(() => {
    if (searchMode === 'fragment' && showLine) {
      console.log('InputBar 監聽到搜尋模式變為 fragment，斷開連線');
      setShowLine(false);
      setConnected(false);
    }
  }, [searchMode, showLine, setConnected]);

  // 註冊窗口
  useEffect(() => {
    const el = inputRef.current
    if (!el || hasRegistered.current) return
  
    requestAnimationFrame(() => {
      const rect = el.getBoundingClientRect()
      addWindow({
        id: 'floating-input-bar',
        x: rect.left,
        y: rect.top,
        width: rect.width || 350,
        height: rect.height || 56
      })
      hasRegistered.current = true
    })
  }, [addWindow])
  
  // 尺寸或收合狀態改變時更新群組狀態
  useEffect(() => {
    const el = inputRef.current
    if (!el) return
    setTimeout(() => {
      const rect = el.getBoundingClientRect()
      updateWindow('floating-input-bar', {
        width: rect.width,
        height: rect.height
      })
      checkAndResolveOverlaps()
    }, 100)
  }, [isCollapsed, isFullScreen, updateWindow, checkAndResolveOverlaps])

  /* 畫連線的邏輯和動畫 */
  useEffect(() => {
    if (showLine) {
      const update = () => {
        const tagButton = tagButtonRef.current
        const tagsWindow = tagsWindowRef.current
        if (tagButton && tagsWindow) {
          const b = tagButton.getBoundingClientRect()
          const w = tagsWindow.getBoundingClientRect()
          const cx = (b.left + w.left) / 2
          const cy = (b.top + w.top) / 2
          const startX = b.left + b.width / 2
          const startY = b.top + b.height / 2
          const endX = w.left + w.width / 2
          const endY = w.top + w.height / 2

          setLinePath(
            `M${startX} ${startY}
             C${cx} ${cy} ${cx} ${cy}
             ${endX} ${endY}`
          )
        }
      }

      update()
      const interval = setInterval(update, 16)
      return () => clearInterval(interval)
    }
  }, [showLine, tagsWindowRef])

  /* 提交新碎片 */
  const handleSubmit = () => {
    if (!content.trim()) return
    const now = new Date().toISOString()
    
    const filteredNotes = notes.filter(note => 
      note.title.trim() !== '' || note.value.trim() !== ''
    )
    
    const notesToSave = filteredNotes.length > 0 ? filteredNotes : []
  
    const newFragment: Fragment = {
      id: fragmentId.current,
      content,
      type: 'fragment',
      tags: pendingTags,
      notes: notesToSave,
      createdAt: now,
      updatedAt: now,
    }
  
    setFragments([newFragment, ...fragments])
    save()
    resetInput()
    
    fragmentId.current = uuidv4()
  }

  /* 清空全部 */
  const handleClear = () => {
    resetInput()
  }

  /* 新增筆記 */
  const addNote = () => {
    setNotes(prev => [...prev, { id: uuidv4(), title: '', value: '' }])
  }

  /* 更新單行筆記 */
  const updateNote = (id: string, field: 'title' | 'value', value: string) => {
    setNotes(prev => prev.map(note =>
      note.id === id ? { ...note, [field]: value } : note
    ))
  }

  /* 刪除筆記 */
  const deleteNote = (id: string) => {
    setNotes(prev => prev.filter(note => note.id !== id))
  }

  /* 處理筆記排序 */
  const handleReorderNotes = (newNotes: Note[]) => {
    setNotes(newNotes)
  }

  /* 重置輸入欄 */
  const resetInput = () => {
    setContent('')
    clearPendingTags()
    setNotes([{ id: uuidv4(), title: '', value: '' }])
    setShowLine(false)
    setConnected(false)
    localStorage.removeItem('murverse_draft')
  }

  /* 畫連線 */
  const handleOpenTagsWindow = (e: React.MouseEvent) => {
    e.stopPropagation();
    console.log('使用增強版開啟標籤選擇器');
    
    if (searchMode === 'fragment') {
      console.log('當前為碎片搜尋模式，需要先切換回標籤模式');
    }
    
    enhancedOpenTagSelector();
    
    setTimeout(() => {
      setMode('add');
      
      setTimeout(() => {
        requestAnimationFrame(() => {
          const tagButton = tagButtonRef.current
          const tagsWindow = tagsWindowRef.current
          if (tagButton && tagsWindow) {
            const b = tagButton.getBoundingClientRect()
            const w = tagsWindow.getBoundingClientRect()
            const cx = (b.left + w.left) / 2
            const cy = (b.top + w.top) / 2
            setLinePath(
              `M${b.left + b.width / 2} ${b.top + b.height / 2}
               C${cx} ${cy} ${cx} ${cy}
               ${w.left + w.width / 2} ${w.top + w.height / 2}`
              )
            setTimeout(() => {
              window.dispatchEvent(new Event('resize'))
            }, 100)
               
            setShowLine(true)
            setConnected(true)
            setAnimateLine(true)
            setTimeout(() => setAnimateLine(false), 500)
          }
        })
      }, 100);
    }, 50);
  }

  /* 折疊視窗 */
  const handleCollapseWindow = () => {
    if (isFullScreen) {
      toggleFullScreen()
    }
    if (isTabMode) {
      // Tab 模式下觸發 tab 收合
      toggleCollapse()
    } else {
      setExpanded(false)
    }
    setShowLine(false)
    setConnected(false)
  }

  /* 移除標籤 */
  const removeTag = (tagToRemove: string) => {
    setPendingTags(pendingTags.filter(tag => tag !== tagToRemove))
  }

  /* 渲染 */
  if (!hydrated) return null
  
// Tab 模式下：如果窗口不可見，只渲染 tab
if (isTabMode && !isWindowVisible) {
 return (
   <>
     {/* 碎片 Tab 書籤 - 收合狀態 */}
     <div
       className="fixed cursor-pointer transition-all duration-300 ease-out transform hover:scale-105 select-none"
       style={{
         top: '35vh',
         left: '0',
         zIndex: 25
       }}
       onClick={() => toggleCollapse()}
     >
       <div 
         className="relative transition-all duration-300 ease-out hover:scale-105"
         style={{
           width: '2vw',
           height: '8vh',
           background: 'linear-gradient(135deg, #f9f6e9 0%, #f0ead2 100%)',
           clipPath: 'polygon(0 0, 85% 0, 100% 15%, 100% 85%, 85% 100%, 0 100%)',
           borderTop: '0.1vh solid rgba(0, 0, 0, 0.05)',
           borderRight: '0.1vh solid rgba(0, 0, 0, 0.05)',
           borderBottom: '0.1vh solid rgba(0, 0, 0, 0.05)',
           borderLeft: 'none',
           borderRadius: '0 0.4vh 0.4vh 0',
         }}
       >
         <div className="absolute inset-0 flex flex-col items-center justify-center" 
              style={{ color: '#666' }}>
           <div style={{ width: '1.4vh', height: '1.4vh', marginBottom: '0.2vh' }}>
             <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-full h-full">
               <line x1="12" y1="5" x2="12" y2="19"></line>
               <line x1="5" y1="12" x2="19" y2="12"></line>
             </svg>
           </div>
           <span style={{ fontSize: '0.9vh' }}>碎片</span>
         </div>
       </div>
     </div>
   </>
 )
}

return (
 <>
   {/* 標籤連線線條 */}
   {showLine && (
     <svg
       style={{
         position: 'fixed',
         top: 0,
         left: 0,
         width: '100vw',
         height: '100vh',
         pointerEvents: 'none',
         zIndex: 1,
       }}
     >
       <path
         d={linePath}
         stroke="black"
         strokeWidth={2}
         fill="none"
         className={animateLine ? 'animate-draw' : ''}
       />
     </svg>
   )}
   
   {/* 主窗體 */}
   <div
      id="floating-input-bar"
      ref={inputRef}
      onMouseDown={handleMouseDown}
      onDragStart={e => e.preventDefault()}
      className={`fixed z-[20] border border-gray-400 rounded-2xl shadow-lg select-none 
        ${expanded && !isCollapsed ? 'p-4' : 'p-2'}
        ${isFullScreen ? 'transition-all duration-300 ease-in-out' : ''}
        ${isTabMode && isTabExpanded ? 'window-enter' : ''}
        ${isTabMode && !isTabExpanded ? 'window-exit' : ''}`}
      style={{
        top: pos.y,
        left: pos.x,
        width: isFullScreen ? '50vw' : '350px',
        height: isFullScreen ? '85vh' : (expanded && !isCollapsed ? 'auto' : '56px'),
        transition: 'width 0.3s, height 0.3s',
        display: isTabMode && !isWindowVisible ? 'none' : 'block',
        
        // 稿紙風格背景
        background: (isTabExpanded || expanded) ? '#f9f6e9' : 'linear-gradient(135deg, #fefcf6 0%, #faf8f1 100%)',
        backgroundImage: (isTabExpanded || expanded) ? `
          linear-gradient(rgba(180, 190, 220, 0.15) 1px, transparent 1px),
          linear-gradient(90deg, rgba(180, 190, 220, 0.15) 1px, transparent 1px)
        ` : 'none',
        backgroundSize: (isTabExpanded || expanded) ? '20px 20px' : 'auto',
        
        // 更淡的邊框和更細緻的陰影
        border: '1px solid rgba(0, 0, 0, 0.08)',
        boxShadow: (isTabExpanded || expanded) 
          ? '0 8px 32px rgba(0, 0, 0, 0.12), 0 2px 8px rgba(0, 0, 0, 0.08)'
          : '0 4px 16px rgba(0, 0, 0, 0.1), 0 1px 4px rgba(0, 0, 0, 0.06)'
      }}
    >
     {/* Tab 書籤 - 在窗口內部，用 absolute 定位到右側 */}
     <div
       className="absolute cursor-pointer transition-all duration-300 ease-out transform hover:scale-105 select-none"
       style={{
         top: '50%',
         right: '-2vw',
         transform: 'translateY(-50%)',
         zIndex: 5
       }}
       onClick={(e) => {
         e.stopPropagation();
         if (isTabMode) {
           toggleCollapse()
         } else {
           setExpanded(!expanded)
         }
       }}
     >
       <div 
         className={`relative transition-all duration-300 ease-out ${(isTabExpanded || expanded) ? 'scale-110' : 'hover:scale-105'}`}
         style={{
           width: '2vw',
           height: '8vh',
           background: (isTabExpanded || expanded)
          ? 'linear-gradient(135deg, #fefcf6 0%, #f8f6ef 100%)'
          : 'linear-gradient(135deg, #fcfaf5 0%, #f6f4ed 100%)',
           clipPath: 'polygon(0 0, 85% 0, 100% 15%, 100% 85%, 85% 100%, 0 100%)',
           borderTop: (isTabExpanded || expanded) ? '0.1vh solid rgba(0, 0, 0, 0.06)' : '0.1vh solid rgba(0, 0, 0, 0.04)',
          borderRight: (isTabExpanded || expanded) ? '0.1vh solid rgba(0, 0, 0, 0.06)' : '0.1vh solid rgba(0, 0, 0, 0.04)',
          borderBottom: (isTabExpanded || expanded) ? '0.1vh solid rgba(0, 0, 0, 0.06)' : '0.1vh solid rgba(0, 0, 0, 0.04)',
           borderLeft: 'none',
           borderRadius: '0 0.4vh 0.4vh 0',
         }}
       >
         <div className="absolute inset-0 flex flex-col items-center justify-center" 
              style={{ color: (isTabExpanded || expanded) ? '#333' : '#666' }}>
           <div 
             style={{
               width: (isTabExpanded || expanded) ? '1.6vh' : '1.4vh',
               height: (isTabExpanded || expanded) ? '1.6vh' : '1.4vh',
               marginBottom: '0.2vh'
             }}
           >
             <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-full h-full">
               <line x1="12" y1="5" x2="12" y2="19"></line>
               <line x1="5" y1="12" x2="19" y2="12"></line>
             </svg>
           </div>
           <span style={{ fontSize: (isTabExpanded || expanded) ? '1vh' : '0.9vh' }}>
             碎片
           </span>
         </div>
         
         {/* 激活指示器 */}
         {(isTabExpanded || expanded) && (
           <div 
             className="absolute top-1 rounded-l-full"
             style={{
               right: '-0.1vw',
               width: '0.2vw',
               height: '2vh',
               backgroundColor: '#d1b684'
             }}
           />
         )}
       </div>
     </div>

     {/* 窗口內容 */}
     {!expanded || isCollapsed ? (
       // 收合狀態（Tab 模式下不會顯示）
       <div className="flex items-center justify-between">
         <input
           className="flex-1 bg-transparent px-4 py-2 text-center mr-2"
           placeholder="輸入新碎片..."
           readOnly
           value={content}
           onFocus={() => {
             setExpanded(true)
             if (isCollapsed) {
               toggleCollapse()
             }
           }}
         />
       </div>
     ) : (
       // 展開狀態
       <div className="space-y-4">
         {/* 頂部控制區 */}
         <InputBarHeader 
           isFullScreen={isFullScreen}
           onCollapse={handleCollapseWindow}
           onToggleFullScreen={toggleFullScreen}
           isTabMode={isTabMode}
         />

         {/* 主要輸入區 */}
         <div className="flex items-center gap-2">
           <input
            className="flex-1 p-2 rounded-lg transition-all duration-200 outline-none"
            placeholder="碎片內容..."
            value={content}
            onChange={e => setContent(e.target.value)}
            style={{
              background: 'rgba(255, 255, 255, 0.7)',
              border: '1px solid rgba(180, 190, 220, 0.15)',
              backdropFilter: 'blur(2px)'
            }}
            onFocus={(e) => {
              e.target.style.background = 'rgba(255, 255, 255, 0.9)'
              e.target.style.borderColor = 'rgba(100, 150, 200, 0.3)'
              e.target.style.boxShadow = '0 0 0 2px rgba(100, 150, 200, 0.1)'
            }}
            onBlur={(e) => {
              e.target.style.background = 'rgba(255, 255, 255, 0.7)'
              e.target.style.borderColor = 'rgba(180, 190, 220, 0.15)'
              e.target.style.boxShadow = 'none'
            }}
          />
         </div>

         {/* 標籤區 */}
         <TagsSelector 
           tags={pendingTags}
           tagButtonRef={tagButtonRef}
           onOpenTagsWindow={handleOpenTagsWindow}
           onRemoveTag={removeTag}
         />

         {/* 筆記列表 */}
         <NotesList 
           notes={notes}
           isFullScreen={isFullScreen}
           onUpdateNote={updateNote}
           onDeleteNote={deleteNote}
           onReorderNotes={handleReorderNotes}
           onAddNote={addNote}
         />

         {/* 操作按鈕 */}
         <ActionButtons 
           isFullScreen={isFullScreen}
           totalCharCount={totalCharCount}
           clearDragActive={false}
           clearButtonRef={null}
           onSubmit={handleSubmit}
           onClear={handleClear}
           onClearDragStart={() => {}}
           onClearDragEnd={() => {}}
         />
       </div>
     )}
   </div>
 </>
)}