// 替換 page.tsx 的內容
'use client'

import { useEffect, useState } from 'react'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import dynamic from 'next/dynamic'

// 創建一個簡化版的 FloatingInputBar 來測試
const SimpleFloatingInputBar = dynamic(() => 
  Promise.resolve({
    default: () => (
      <div 
        style={{
          position: 'fixed',
          top: '100px',
          left: '100px',
          width: '300px',
          height: '200px',
          backgroundColor: 'white',
          border: '2px solid #333',
          borderRadius: '8px',
          padding: '16px',
          zIndex: 1000
        }}
      >
        <h3>簡化版 FloatingInputBar</h3>
        <input 
          type="text" 
          placeholder="測試輸入..." 
          style={{
            width: '100%',
            padding: '8px',
            margin: '8px 0',
            border: '1px solid #ccc',
            borderRadius: '4px'
          }}
        />
        <button 
          style={{
            padding: '8px 16px',
            backgroundColor: '#007bff',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          測試按鈕
        </button>
      </div>
    )
  }), 
  { ssr: false }
)

// 同時測試原始的 FloatingInputBar
const OriginalFloatingInputBar = dynamic(() => import('@/features/input/FloatingInputBar').catch(err => {
  console.error('Failed to load original FloatingInputBar:', err)
  return { default: () => <div style={{color: 'red'}}>原始 FloatingInputBar 載入失敗: {err.message}</div> }
}), { 
  ssr: false,
  loading: () => <div>Loading original FloatingInputBar...</div>
})

export default function Home() {
  const [isClient, setIsClient] = useState(false)
  const [step, setStep] = useState('初始化中...')
  const [showSimple, setShowSimple] = useState(false)
  const [showOriginal, setShowOriginal] = useState(false)

  const { fragments, load } = useFragmentsStore()

  useEffect(() => {
    const testLoad = async () => {
      try {
        console.log('步驟 1: 設置客戶端')
        setStep('設置客戶端...')
        setIsClient(true)
        
        console.log('步驟 2: 載入 store')
        setStep('載入 store...')
        await load()
        
        console.log('步驟 3: 載入完成')
        setStep('載入完成！')
      } catch (error) {
        console.error('載入失敗:', error)
        setStep(`載入失敗: ${error}`)
      }
    }
    
    testLoad()
  }, [])

  return (
    <div className="min-h-screen bg-[#f9f6e9] flex items-center justify-center">
      <div className="text-center p-8">
        <h1 className="text-3xl font-bold mb-4">測試 FloatingInputBar 顯示</h1>
        <p className="text-lg mb-4">當前步驟: {step}</p>
        
        <div className="space-y-4">
          <button 
            onClick={() => {
              console.log('顯示簡化版 FloatingInputBar')
              setShowSimple(true)
            }}
            className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 mr-4"
          >
            顯示簡化版
          </button>
          
          <button 
            onClick={() => {
              console.log('顯示原始 FloatingInputBar')
              setShowOriginal(true)
            }}
            className="px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600"
          >
            顯示原始版
          </button>
          
          <div className="mt-4 space-y-2">
            <p>簡化版狀態: {showSimple ? '已顯示' : '未顯示'}</p>
            <p>原始版狀態: {showOriginal ? '已顯示' : '未顯示'}</p>
          </div>
        </div>
      </div>
      
      {/* 簡化版 */}
      {showSimple && <SimpleFloatingInputBar />}
      
      {/* 原始版 */}
      {showOriginal && <OriginalFloatingInputBar />}
    </div>
  )
}