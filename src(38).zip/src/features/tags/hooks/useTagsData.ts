// src/features/tags/hooks/useTagsData.ts
'use client'

import { useState, useEffect } from 'react'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { safeGetItem } from '@/utils/safeStorage'

type TagInfo = { name: string; count: number }

export const useTagsData = () => {
  const [allTags, setAllTags] = useState<TagInfo[]>([])
  const [recentlyUsedTags, setRecentlyUsedTags] = useState<string[]>([])
  
  const { fragments } = useFragmentsStore()

  // 初始化標籤列表
  useEffect(() => {
    try {
      const map = new Map<string, number>()
      fragments.forEach((f: any) => {
        if (f?.tags && Array.isArray(f.tags)) {
          f.tags.forEach((t: string) => map.set(t, (map.get(t) || 0) + 1))
        }
      })
      
      // 安全地讀取 localStorage
      let extra: string[] = []
      try {
        extra = safeGetItem<string[]>('mur_tags_global', [])
        if (!Array.isArray(extra)) {
          extra = []
        }
      } catch (e) {
        console.warn('Error reading tags from localStorage:', e)
        extra = []
      }
      
      extra.forEach(t => map.set(t, map.get(t) || 0))
      setAllTags([...map.entries()].map(([name, count]) => ({ name, count })))
    } catch (error) {
      console.error('Error initializing tags:', error)
      setAllTags([])
    }
  }, [fragments])

  // 載入最近使用的標籤
  useEffect(() => {
    try {
      const storedRecentTags = safeGetItem<string[]>('mur_recent_tags', [])
      if (Array.isArray(storedRecentTags)) {
        setRecentlyUsedTags(storedRecentTags)
      }
    } catch (e) {
      console.error('Error loading recent tags from localStorage', e)
      setRecentlyUsedTags([])
    }
  }, [])

  return {
    allTags,
    setAllTags,
    recentlyUsedTags,
    setRecentlyUsedTags
  }
}