// src/features/tags/hooks/useTagOperations.ts
'use client'

import { useCallback } from 'react'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { useGlobalTagsStore } from '@/features/tags/store/useGlobalTagsStore'
import { useSearchStore } from '@/features/search/useSearchStore'
import { safeGetItem, safeSetItem } from '@/utils/safeStorage'
import { isSystemTag } from '@/features/tags/constants/systemTags'
import { SearchService } from '@/features/search/SearchService'
import { useSingleUserTagSync } from '@/shared/hook/useSingleUserTagSync'


interface UseTagOperationsProps {
  allTags: { name: string; count: number }[]
  setAllTags: (tags: { name: string; count: number }[]) => void
  recentlyUsedTags: string[]
  setRecentlyUsedTags: (updater: (prev: string[]) => string[]) => void
  search: string
  setSearch: (search: string) => void
  setFilteredFragments: (fragments: any[]) => void
  sortMode: string
  onlyShowSel: boolean
  selectedTags: string[]
  excludedTags: string[]
  editMode: boolean
  mode: string
}

export const useTagOperations = ({
  allTags,
  setAllTags,
  recentlyUsedTags,
  setRecentlyUsedTags,
  search,
  setSearch,
  setFilteredFragments,
  sortMode,
  onlyShowSel,
  selectedTags: propsSelectedTags,
  excludedTags: propsExcludedTags,
  editMode,
  mode: propsMode
}: UseTagOperationsProps) => {

  // 從 store 獲取狀態並提供回退值
  const {
    fragments,
    selectedTags: storeSelectedTags,
    setSelectedTags,
    excludedTags: storeExcludedTags,
    setExcludedTags,
    tagLogicMode
  } = useFragmentsStore()

  const {
    mode: storeMode,
    pendingTags,
    addPendingTag,
    removePendingTag
  } = useGlobalTagsStore()

  // 使用 props 值優先，store 值作為回退
  const selectedTags = propsSelectedTags || storeSelectedTags
  const excludedTags = propsExcludedTags || storeExcludedTags
  const mode = propsMode || storeMode
  const { syncAddTag } = useSingleUserTagSync()

  // 記錄標籤使用
  const recordTagUsage = useCallback((tagName: string) => {
    try {
      setRecentlyUsedTags((prev: string[]) => {
        const filtered = prev.filter(t => t !== tagName)
        return [tagName, ...filtered].slice(0, 50)
      })
    
      const storedTags = safeGetItem<string[]>('mur_recent_tags', [])
      const updatedTags = [tagName, ...storedTags.filter((t: string) => t !== tagName)].slice(0, 50)
      safeSetItem('mur_recent_tags', updatedTags)
    } catch (e) {
      console.error('Error saving recent tags to localStorage', e)
    }
  }, [setRecentlyUsedTags])

  // 添加標籤
  const handleAddTag = useCallback(() => {
    try {
      const raw = search.trim()
      if (!raw) return

      const clean = raw.replace(/^#/, '')
      if (isSystemTag(clean)) {
        setSearch('')
        return
      }
      
      if (!allTags.some(tag => tag.name === clean)) {
        setAllTags([...allTags, { name: clean, count: 1 }])
      }
      
      const stored = safeGetItem<string[]>('mur_tags_global', [])
      if (!stored.includes(clean)) {
        safeSetItem('mur_tags_global', [...stored, clean])
      }
    
      if (mode === 'add') {
        addPendingTag(clean)
      }
    
      syncAddTag(clean)
      setSearch('')
    } catch (error) {
      console.error('Error in handleAddTag:', error)
    }
  }, [search, allTags, setAllTags, setSearch, mode, addPendingTag, syncAddTag])

  // 選擇標籤
  const handleTagSelect = useCallback((t: string) => {
    try {
      if (mode === 'add' && isSystemTag(t)) return
    
      recordTagUsage(t)
    
      if (mode === 'add') {
        pendingTags.includes(t) ? removePendingTag(t) : addPendingTag(t)
      } else {
        const newSelected = selectedTags.includes(t)
          ? selectedTags.filter((k: string) => k !== t)
          : [...selectedTags, t]
        const newExcluded = excludedTags.filter((k: string) => k !== t)
    
        setSelectedTags(newSelected)
        setExcludedTags(newExcluded)
    
        const ss = useSearchStore.getState()
        ss.setSelectedTags(newSelected)
        ss.setExcludedTags(newExcluded)
        ss.setTagLogicMode(tagLogicMode)
        ss.setKeyword('')
        ss.setScopes(['fragment'])
        const results = ss.executeSearch(fragments)
        setFilteredFragments(results)
      }
    } catch (error) {
      console.error('Error in handleTagSelect:', error)
    }
  }, [mode, recordTagUsage, pendingTags, removePendingTag, addPendingTag, selectedTags, excludedTags, setSelectedTags, setExcludedTags, tagLogicMode, fragments, setFilteredFragments])

  // 排除標籤
  const handleTagExclude = useCallback((t: string) => {
    try {
      if (mode === 'add') return
    
      const newExcluded = excludedTags.includes(t)
        ? excludedTags.filter((k: string) => k !== t)
        : [...excludedTags, t]
      const newSelected = selectedTags.filter((k: string) => k !== t)
    
      setExcludedTags(newExcluded)
      setSelectedTags(newSelected)
    
      const ss = useSearchStore.getState()
      ss.setSelectedTags(newSelected)
      ss.setExcludedTags(newExcluded)
      ss.setTagLogicMode(tagLogicMode)
      ss.setKeyword('')
      ss.setScopes(['fragment'])
      const results = ss.executeSearch(fragments)
      setFilteredFragments(results)
    } catch (error) {
      console.error('Error in handleTagExclude:', error)
    }
  }, [mode, excludedTags, selectedTags, setExcludedTags, setSelectedTags, tagLogicMode, fragments, setFilteredFragments])

  // 獲取標籤狀態
  const isPos = useCallback((t: string) => 
    mode === 'add' ? pendingTags.includes(t) : selectedTags.includes(t)
  , [mode, pendingTags, selectedTags])

  const isNeg = useCallback((t: string) => 
    mode === 'add' ? false : excludedTags.includes(t)
  , [mode, excludedTags])

  // 過濾並排序標籤
  const getShownTags = useCallback(() => {
    try {
      const tokens = SearchService.parseSearchQuery(search, 'substring')
      
      return allTags
  .filter(t => {
    if (!tokens.length) return true

    return tokens.some(token => {
      const tag = t.name.toLowerCase()
      const val = token.value.toLowerCase()

      if (token.type === 'include' || token.type === 'text') {
        return tag.includes(val)
      } else if (token.type === 'exact') {
        return tag === val
      } else if (token.type === 'wildcard') {
        return tag.includes(val.replace(/\*/g, ''))
      }
      return false
    })
  })
  .filter(t => {
    if (editMode) return true
    return mode === 'add'
      ? true
      : (onlyShowSel ? (selectedTags.includes(t.name) || excludedTags.includes(t.name)) : true)
  })
  .sort((a, b) => {
          const baseMode = sortMode.replace('asc_', '').replace('desc_', '')
          const isDesc = sortMode.startsWith('desc_')
    
          if (baseMode === 'az') {
            return isDesc ? b.name.localeCompare(a.name) : a.name.localeCompare(b.name)
          } else if (baseMode === 'freq') {
            return isDesc ? b.count - a.count : a.count - b.count
          } else if (baseMode === 'recent') {
            const aIndex = recentlyUsedTags.indexOf(a.name)
            const bIndex = recentlyUsedTags.indexOf(b.name)
            const aRecentIndex = aIndex === -1 ? Number.MAX_SAFE_INTEGER : aIndex
            const bRecentIndex = bIndex === -1 ? Number.MAX_SAFE_INTEGER : bIndex
            return isDesc ? bRecentIndex - aRecentIndex : aRecentIndex - bRecentIndex
          }
          return 0
        })
    } catch (error) {
      console.error('Error in getShownTags:', error)
      return []
    }
  }, [allTags, search, sortMode, recentlyUsedTags, editMode, mode, onlyShowSel, selectedTags, excludedTags])

  return {
    handleAddTag,
    handleTagSelect,
    handleTagExclude,
    isPos,
    isNeg,
    getShownTags
  }
}