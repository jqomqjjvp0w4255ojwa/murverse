// src/features/tags/hooks/useDrawerResize.ts
'use client'

import { useEffect } from 'react'
import { DRAWER_CONFIG } from '@/features/tags/constants/drawerConfig'

interface UseDrawerResizeProps {
  isResizing: boolean
  setDrawerWidth: (width: number) => void
}

export const useDrawerResize = ({ isResizing, setDrawerWidth }: UseDrawerResizeProps) => {
  // 處理拖拽調整寬度
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return
      
      const viewportWidth = window.innerWidth
      const viewportHeight = window.innerHeight
      const newWidthPx = e.clientX
      
      // 計算新寬度，限制在最小最大值之間
      const minWidthPx = (DRAWER_CONFIG.MIN_WIDTH / 100) * viewportHeight
      const maxWidthPx = (DRAWER_CONFIG.MAX_WIDTH / 100) * viewportWidth
      
      const clampedWidthPx = Math.min(Math.max(newWidthPx, minWidthPx), maxWidthPx)
      const newWidthVh = (clampedWidthPx / viewportHeight) * 100
      
      setDrawerWidth(newWidthVh)
    }
    
    const handleMouseUp = () => {
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
    }
    
    if (isResizing) {
      document.body.style.cursor = 'col-resize'
      document.body.style.userSelect = 'none'
      document.addEventListener('mousemove', handleMouseMove)
      document.addEventListener('mouseup', handleMouseUp)
    }
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isResizing, setDrawerWidth])
}