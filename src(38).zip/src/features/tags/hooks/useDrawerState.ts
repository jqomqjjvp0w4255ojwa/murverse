// src/features/tags/hooks/useDrawerState.ts
'use client'

import { useState, useEffect } from 'react'
import { DRAWER_CONFIG } from '@/features/tags/constants/drawerConfig'
import { useGlobalTagsStore } from '@/features/tags/store/useGlobalTagsStore'

export const useDrawerState = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [drawerWidth, setDrawerWidth] = useState(DRAWER_CONFIG.DEFAULT_WIDTH)
  const [isResizing, setIsResizing] = useState(false)
  
  const { setConnected } = useGlobalTagsStore()

  // 監聽 tab 切換事件
  useEffect(() => {
    const handleTabToggle = (event: CustomEvent) => {
      const { windowId, isActive } = event.detail
      
      if (windowId === 'tags-floating-window') {
        setIsOpen(isActive)
      }
    }
    
    const handleTabCollapse = (event: CustomEvent) => {
      const { windowId } = event.detail
      if (windowId === 'tags-floating-window') {
        setIsOpen(false)
        setConnected(false)
      }
    }
    
    if (typeof window !== 'undefined') {
      window.addEventListener('tab-toggle', handleTabToggle as EventListener)
      window.addEventListener('tab-collapse', handleTabCollapse as EventListener)
    }
    
    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('tab-toggle', handleTabToggle as EventListener)
        window.removeEventListener('tab-collapse', handleTabCollapse as EventListener)
      }
    }
  }, [setConnected])

  return {
    isOpen,
    setIsOpen,
    drawerWidth,
    setDrawerWidth,
    isResizing,
    setIsResizing
  }
}