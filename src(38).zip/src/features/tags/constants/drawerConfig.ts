// src/features/tags/constants/drawerConfig.ts
export const DRAWER_CONFIG = {
  MIN_WIDTH: 40,  // vh
  MAX_WIDTH: 50,  // vw 
  DEFAULT_WIDTH: 40,  // vh
  RESIZE_TRANSITION_DURATION: 500  // ms
}