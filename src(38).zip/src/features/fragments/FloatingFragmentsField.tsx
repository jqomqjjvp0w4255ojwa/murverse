'use client'

import React from 'react'
import { useState, useMemo, useEffect, useCallback } from 'react'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { useSearchStore } from '@/features/search/useSearchStore'
import FragmentsGridView from '@/features/fragments/components/FragmentsGridView'
import FragmentsFlowView from '@/features/fragments/components/FragmentsFlowView'
import { VIEW_MODES, CONTAINER_WIDTH } from '@/features/fragments/constants'
import { GridPosition } from '@/features/fragments/types/gridTypes'
import { safeRemoveItem } from '@/utils/safeStorage'

// 封裝的 Fragment 數量信息組件，用於提高渲染效能
const FragmentCount = React.memo(({ count, tags }: { count: number, tags: string[] }) => (
  <div style={{ 
    textAlign: 'center', 
    margin: '1.25rem 0', 
    color: '#888',
    fontSize: '0.875rem' 
  }}>
    共有 {count} 個碎片
    {tags.length > 0 && ` (已篩選: ${tags.join(', ')})`}
  </div>
));

// 封裝的視圖模式按鈕組件，用於提高渲染效能
const ViewModeButtons = React.memo(({ 
  currentMode, 
  onModeChange 
}: { 
  currentMode: 'grid' | 'flow', 
  onModeChange: (mode: 'grid' | 'flow') => void 
}) => (
  <div style={{ 
    display: 'flex', 
    justifyContent: 'center', 
    marginBottom: '1.25rem', 
    gap: '0.625rem' 
  }}>
    <button
      onClick={() => onModeChange(VIEW_MODES.GRID)}
      style={{
        padding: '0.5rem 1rem',
        border: 'none',
        borderRadius: '1.25rem',
        backgroundColor: currentMode === VIEW_MODES.GRID ? '#f0e6d2' : '#eaeaea',
        color: currentMode === VIEW_MODES.GRID ? '#333' : '#888',
        fontWeight: currentMode === VIEW_MODES.GRID ? '600' : 'normal',
        cursor: 'pointer',
        boxShadow: currentMode === VIEW_MODES.GRID ? '0 0.125rem 0.25rem rgba(0, 0, 0, 0.1)' : 'none'
      }}
    >
      拼圖排列模式
    </button>
    <button
      onClick={() => onModeChange(VIEW_MODES.FLOW)}
      style={{
        padding: '0.5rem 1rem',
        border: 'none',
        borderRadius: '1.25rem',
        backgroundColor: currentMode === VIEW_MODES.FLOW ? '#f0e6d2' : '#eaeaea',
        color: currentMode === VIEW_MODES.FLOW ? '#333' : '#888',
        fontWeight: currentMode === VIEW_MODES.FLOW ? '600' : 'normal',
        cursor: 'pointer',
        boxShadow: currentMode === VIEW_MODES.FLOW ? '0 0.125rem 0.25rem rgba(0, 0, 0, 0.1)' : 'none'
      }}
    >
      社群流動模式
    </button>
  </div>
));

export default function FloatingFragmentsField() {
  // 狀態管理
  const [mode, setMode] = useState<'grid' | 'flow'>(VIEW_MODES.GRID)
  const { fragments } = useFragmentsStore()
  const keyword = useSearchStore(state => state.keyword)
  const searchResults = useSearchStore(state => state.searchResults)
  const selectedTags = useSearchStore(state => state.selectedTags)
  const excludedTags = useSearchStore(state => state.excludedTags)
  const [positions, setPositions] = useState<Record<string, GridPosition>>({});

  // 判斷是否需要重置佈局
  const shouldResetLayout = useMemo(() => {
    return keyword.trim().length > 0 || selectedTags.length > 0 || excludedTags.length > 0;
  }, [keyword, selectedTags, excludedTags]);
  
  // 窗口大小響應 - 只在客戶端執行
  const [windowSize, setWindowSize] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : CONTAINER_WIDTH,
    height: typeof window !== 'undefined' ? window.innerHeight : 800
  });

  // 處理視圖模式變更的回調函數
  const handleModeChange = useCallback((newMode: 'grid' | 'flow') => {
    setMode(newMode);
  }, []);

  // 決定要顯示哪些碎片 - 使用 useMemo 提高效能
  const filteredFragments = useMemo(() => {
    const hasKeyword = keyword.trim().length > 0
    const hasTagFilter = selectedTags.length > 0 || excludedTags.length > 0
    const hasEffectiveFilter = hasKeyword || hasTagFilter
    
    return hasEffectiveFilter ? searchResults : fragments
  }, [fragments, keyword, searchResults, selectedTags, excludedTags])

  // 監聽窗口大小變化 - 只在客戶端執行
  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight
      });
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // 篩選變化時清除位置信息的 useEffect
  useEffect(() => {
    // 當篩選結果變化時，清除位置信息 - 使用安全的存儲函數
    safeRemoveItem('fragment_positions');
    setPositions({});
    
    console.log('篩選變化，清除位置 → 將重新布局');
  }, [filteredFragments.length]); // 使用 length 屬性避免參照相等的問題

  return (
    <div className="floating-fragments-container relative w-full h-full" 
         style={{ 
           backgroundColor: '#f9f6e9', 
           minHeight: '100vh', 
           padding: '1.25rem', 
           overflowX: 'hidden'
         }}>
      <h1 style={{ textAlign: 'center', marginBottom: '1.25rem', color: '#333' }}>
        語意筆記系統
      </h1>
      
      {/* 使用記憶化的按鈕組件提高渲染效能 */}
      <ViewModeButtons currentMode={mode} onModeChange={handleModeChange} />

      <div className="fragments-view-container"
        style={{
          position: 'relative',
          width: '100%',
          maxWidth: `${CONTAINER_WIDTH}px`,
          margin: '0 auto',
          backgroundColor: '#f9f6e9',
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 0, 0, 0.05) 1px, transparent 1px)',
          backgroundSize: '1.25rem 1.25rem',
          borderRadius: '0.5rem',
          padding: '0',
          height: 'auto',
          minHeight: `${windowSize.height * 0.7}px`,
          overflow: 'hidden'
        }}
      >
        {mode === VIEW_MODES.GRID ? (
          <FragmentsGridView 
            fragments={filteredFragments} 
            relevanceMap={{}}
            key={`grid-${filteredFragments.length}`}
            resetLayout={shouldResetLayout}
          />
        ) : (
          <div style={{ padding: '0.5rem' }}>
            <FragmentsFlowView 
              fragments={filteredFragments} 
              relevanceMap={{}}
            />
          </div>
        )}
      </div>
      
      {/* 使用記憶化的碎片數量組件提高渲染效能 */}
      <FragmentCount count={filteredFragments.length} tags={selectedTags} />
    </div>
  );
}