import { supabase } from '@/lib/supabaseClient'
import { Fragment } from '@/features/fragments/types/fragment'

const TABLE_NAME = 'fragments'

export async function loadFragments(): Promise<Fragment[]> {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .select('*')
    .order('updated_at', { ascending: false })

  if (error) {
    console.error('載入 fragments 失敗:', error.message)
    return []
  }

  return data as Fragment[]
}

export async function saveFragments(fragments: Fragment[]): Promise<void> {
  const { error } = await supabase
    .from(TABLE_NAME)
    .upsert(fragments, { onConflict: 'id' }) // id 重複會覆蓋
  if (error) console.error('儲存 fragments 失敗:', error.message)
}
