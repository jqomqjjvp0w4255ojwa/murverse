// src/utils/safeStorage.ts

/**
 * 安全的瀏覽器存儲工具
 * 處理 SSR、隱私模式和錯誤情況
 */

import { useState, useEffect, useCallback } from 'react';

// 記憶體存儲備用
let memoryStorage: Record<string, string> = {};

/**
 * 檢查 localStorage 是否可用
 */
export const isLocalStorageAvailable = (): boolean => {
  if (typeof window === 'undefined') return false;
  
  try {
    const testKey = '__storage_test__';
    window.localStorage.setItem(testKey, testKey);
    window.localStorage.removeItem(testKey);
    return true;
  } catch (e) {
    return false;
  }
};

/**
 * 安全地從存儲中獲取項目
 */
export const safeGetItem = <T>(key: string, defaultValue: T): T => {
  try {
    if (!isLocalStorageAvailable()) {
      return memoryStorage[key] ? JSON.parse(memoryStorage[key]) : defaultValue;
    }
    
    const item = window.localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.warn(`Error reading from storage (key: ${key}):`, error);
    return defaultValue;
  }
};

/**
 * 安全地保存項目到存儲
 */
export const safeSetItem = <T>(key: string, value: T): boolean => {
  try {
    const serializedValue = JSON.stringify(value);
    
    if (!isLocalStorageAvailable()) {
      memoryStorage[key] = serializedValue;
      return true;
    }
    
    window.localStorage.setItem(key, serializedValue);
    return true;
  } catch (error) {
    console.error(`Error writing to storage (key: ${key}):`, error);
    return false;
  }
};

/**
 * 安全地從存儲中移除項目
 */
export const safeRemoveItem = (key: string): boolean => {
  try {
    if (!isLocalStorageAvailable()) {
      delete memoryStorage[key];
      return true;
    }
    
    window.localStorage.removeItem(key);
    return true;
  } catch (error) {
    console.error(`Error removing from storage (key: ${key}):`, error);
    return false;
  }
};

/**
 * 安全地獲取所有存儲鍵
 */
export const safeGetAllKeys = (): string[] => {
  try {
    if (!isLocalStorageAvailable()) {
      return Object.keys(memoryStorage);
    }
    
    return Object.keys(window.localStorage);
  } catch (error) {
    console.error('Error getting all storage keys:', error);
    return [];
  }
};

/**
 * 安全地清空所有存儲
 */
export const safeClearStorage = (): boolean => {
  try {
    if (!isLocalStorageAvailable()) {
      memoryStorage = {};
      return true;
    }
    
    window.localStorage.clear();
    return true;
  } catch (error) {
    console.error('Error clearing storage:', error);
    return false;
  }
};

/**
 * localStorage Hook
 * 提供與 React.useState 類似的 API，但會自動同步到 localStorage
 */
export function useLocalStorage<T>(key: string, initialValue: T) {
  // 初始化時從 localStorage 讀取值，如果失敗則使用預設值
  const [storedValue, setStoredValue] = useState<T>(() => {
    return safeGetItem(key, initialValue);
  });

  // 返回包裹了 localStorage 處理邏輯的 setter 函數
  const setValue = useCallback((value: T | ((val: T) => T)) => {
    try {
      // 允許函數式更新，與 React.useState 相同
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      
      // 保存到 state
      setStoredValue(valueToStore);
      
      // 保存到 localStorage
      safeSetItem(key, valueToStore);
    } catch (error) {
      console.error(`Error in setValue for key "${key}":`, error);
    }
  }, [key, storedValue]);

  // 監聽其他窗口/標籤頁對 localStorage 的更改
  useEffect(() => {
    if (!isLocalStorageAvailable()) return;
    
    function handleStorageChange(event: StorageEvent) {
      if (event.key === key && event.newValue !== null) {
        try {
          setStoredValue(JSON.parse(event.newValue));
        } catch (e) {
          console.warn(`Error parsing storage event value for key "${key}":`, e);
        }
      }
    }

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [key]);

  return [storedValue, setValue] as const;
}