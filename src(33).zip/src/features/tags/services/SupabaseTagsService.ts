import { supabase } from '@/lib/supabaseClient'

export async function loadGlobalTags(): Promise<{ name: string, count: number }[]> {
  const { data, error } = await supabase
    .from('user_tags')
    .select('name, count')
    .order('name', { ascending: true })

  if (error) {
    console.error('載入 tags 失敗:', error)
    return []
  }

  return data || []
}

export async function saveGlobalTag(name: string) {
  const { error } = await supabase.from('user_tags').upsert([
    { name: name.trim(), count: 0 }
  ])
  if (error) console.error('儲存 tag 失敗:', error)
}

export async function deleteGlobalTags(names: string[]) {
  const { error } = await supabase
    .from('user_tags')
    .delete()
    .in('name', names)
  if (error) console.error('刪除 tag 失敗:', error)
}

export async function renameGlobalTag(oldName: string, newName: string) {
  await deleteGlobalTags([oldName])
  await saveGlobalTag(newName)
}

export async function loadRecentTags(): Promise<string[]> {
  const { data, error } = await supabase
    .from('user_recent_tags')
    .select('recent_tags')
    .single()
  if (error) return []
  return data?.recent_tags || []
}

export async function saveRecentTags(tags: string[]) {
  await supabase.from('user_recent_tags').upsert([
    { recent_tags: tags }
  ])
}
