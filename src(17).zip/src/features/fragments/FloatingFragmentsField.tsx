'use client'

import { useState, useMemo } from 'react'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { useSearchStore } from '@/features/search/useSearchStore'
import { getRelevanceMap } from '@/features/fragments/layout/getRelevanceMap'
import FragmentsGridView from '@/features/fragments/components/FragmentsGridView'
import FragmentsFlowView from '@/features/fragments/components/FragmentsFlowView'
import { VIEW_MODES } from '@/features/fragments/constants'

export default function FloatingFragmentsField() {
  const [mode, setMode] = useState<'grid' | 'flow'>(VIEW_MODES.GRID)
  const { fragments } = useFragmentsStore()
  const keyword = useSearchStore(state => state.keyword)
  const searchResults = useSearchStore(state => state.searchResults)
  const selectedTags = useSearchStore(state => state.selectedTags)
  const excludedTags = useSearchStore(state => state.excludedTags)

  // 決定要顯示哪些碎片
  const filteredFragments = useMemo(() => {
    const hasKeyword = keyword.trim().length > 0
    const hasTagFilter = selectedTags.length > 0 || excludedTags.length > 0
    const hasEffectiveFilter = hasKeyword || hasTagFilter
    
    return hasEffectiveFilter ? searchResults : fragments
  }, [fragments, keyword, searchResults, selectedTags, excludedTags])

  // 計算碎片與選定標籤的相關性
  const relevanceMap = useMemo(() => 
    getRelevanceMap(filteredFragments, selectedTags),
    [filteredFragments, selectedTags]
  )

  return (
    <div className="relative w-full h-full" 
         style={{ backgroundColor: '#f9f6e9', minHeight: '100vh', padding: '20px' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '20px', color: '#333' }}>
        語意筆記系統
      </h1>
      
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        marginBottom: '20px', 
        gap: '10px' 
      }}>
        <button
          onClick={() => setMode(VIEW_MODES.GRID)}
          style={{
            padding: '8px 16px',
            border: 'none',
            borderRadius: '20px',
            backgroundColor: mode === VIEW_MODES.GRID ? '#f0e6d2' : '#eaeaea',
            color: mode === VIEW_MODES.GRID ? '#333' : '#888',
            fontWeight: mode === VIEW_MODES.GRID ? '600' : 'normal',
            cursor: 'pointer',
            boxShadow: mode === VIEW_MODES.GRID ? '0 2px 4px rgba(0, 0, 0, 0.1)' : 'none'
          }}
        >
          拼圖排列模式
        </button>
        <button
          onClick={() => setMode(VIEW_MODES.FLOW)}
          style={{
            padding: '8px 16px',
            border: 'none',
            borderRadius: '20px',
            backgroundColor: mode === VIEW_MODES.FLOW ? '#f0e6d2' : '#eaeaea',
            color: mode === VIEW_MODES.FLOW ? '#333' : '#888',
            fontWeight: mode === VIEW_MODES.FLOW ? '600' : 'normal',
            cursor: 'pointer',
            boxShadow: mode === VIEW_MODES.FLOW ? '0 2px 4px rgba(0, 0, 0, 0.1)' : 'none'
          }}
        >
          社群流動模式
        </button>
      </div>

      <div style={{
        position: 'relative',
        margin: '0 auto',
        width: '100%',
        maxWidth: '1200px',
        minHeight: '700px',
        backgroundColor: '#f9f6e9',
        backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 0, 0, 0.05) 1px, transparent 1px)',
        backgroundSize: '20px 20px',
        borderRadius: '8px',
        padding: '8px',
        overflow: 'hidden'
      }}>
        {mode === VIEW_MODES.GRID ? (
          <FragmentsGridView fragments={filteredFragments} relevanceMap={relevanceMap} />
        ) : (
          <FragmentsFlowView fragments={filteredFragments} relevanceMap={relevanceMap} />
        )}
      </div>
    </div>
  )
}