'use client'

import React, { useState, useMemo, useCallback, memo, useRef, useEffect } from 'react'
import { useFragmentsStore } from '@/features/fragments/store/useFragmentsStore'
import { Fragment } from '@/features/fragments/types/fragment'
import { 
  PixelPosition, 
  GridFragment, 
  RelevanceMap 
} from '@/features/fragments/types/gridTypes'
import FragmentDetailModal from './FragmentDetailModal'
import { 
  useLayoutFragments, 
  createDirectionMap,
  gridToPixel,
} from '@/features/fragments/layout/useLayoutFragments'
import { useDragFragment } from '@/features/fragments/layout/useDragFragment'
import { 
  GRID_SIZE,
  MAX_CONTENT_LENGTH,
  MAX_NOTE_LENGTH,
  MAX_TAGS_COUNT,
  CONTAINER_WIDTH
} from '@/features/fragments/constants'
import { truncateText, formatDate } from '@/features/fragments/utils'

// 單個碎片卡片組件
const FragmentCard = memo(({
  fragment,
  isSelected,
  isDragging,
  dragPosition,
  onFragmentClick,
  onDragStart,
  observerRef,
}: {
  fragment: GridFragment
  isSelected: boolean
  isDragging: boolean
  dragPosition: PixelPosition
  onFragmentClick: (fragment: GridFragment) => void
  onDragStart: (e: React.MouseEvent, fragment: GridFragment) => void
  observerRef?: React.RefObject<HTMLDivElement>
}) => {
  const { position, size, direction, fontSize } = fragment
  const [showMoreContent, setShowMoreContent] = useState(false)
  const [showMoreNote, setShowMoreNote] = useState(false)
  
  // 計算像素位置
  const { top, left } = isDragging 
    ? dragPosition 
    : gridToPixel(position)
  
  const width = size.width * GRID_SIZE
  const height = size.height * GRID_SIZE
  
  // 確定是否顯示筆記內容
  const showNotes = fragment.showNote !== false && fragment.notes && fragment.notes.length > 0
  
  // 計算可顯示的內容長度（基於卡片尺寸）
  const maxVisibleChars = useMemo(() => {
    if (direction === 'horizontal') {
      // 橫排時，計算可見行數
      const availableHeight = height - 80; // 扣除標籤和邊距
      const lineHeight = fontSize * 1.4;
      const maxLines = Math.floor(availableHeight / lineHeight);
      const charsPerLine = Math.floor((width - 40) / (fontSize * 0.6));
      return Math.max(50, maxLines * charsPerLine);
    } else {
      // 豎排時，計算可見列數
      const availableWidth = width - 60; // 扣除標籤和邊距
      const columnWidth = fontSize * 1.6;
      const maxColumns = Math.floor(availableWidth / columnWidth);
      const charsPerColumn = Math.floor((height - 40) / (fontSize * 1.1));
      return Math.max(50, maxColumns * charsPerColumn);
    }
  }, [width, height, fontSize, direction])
  
  // 處理內容截斷
  const content = showMoreContent ? fragment.content : truncateText(fragment.content, maxVisibleChars)
  const noteText = showNotes ? fragment.notes[0]?.value || '' : ''
  const note = showMoreNote ? noteText : truncateText(noteText, Math.floor(maxVisibleChars * 0.6))
  const tags = fragment.tags.slice(0, MAX_TAGS_COUNT)
  
  // 判斷是否需要展開按鈕
  const needContentExpand = fragment.content.length > maxVisibleChars
  const needNoteExpand = noteText.length > Math.floor(maxVisibleChars * 0.6)

  return (
    <div
      ref={observerRef}
      data-fragment-id={fragment.id}
      onClick={() => onFragmentClick(fragment)}
      onMouseDown={(e) => onDragStart(e, fragment)}
      className={`fragment-card ${isDragging ? 'z-50' : isSelected ? 'z-10' : 'z-1'}`}
      style={{
        position: 'absolute',
        top: `${top}px`,
        left: `${left}px`,
        width: `${width}px`,
        height: `${height}px`,
        padding: '12px',
        backgroundColor: '#fffbef',
        borderRadius: '10px',
        boxShadow: isDragging
          ? '0 8px 24px rgba(0, 0, 0, 0.15)'
          : isSelected 
          ? '0 4px 16px rgba(0, 0, 0, 0.1)' 
          : '0 2px 8px rgba(0, 0, 0, 0.06)',
        border: '1px solid rgba(0, 0, 0, 0.05)',
        transform: isSelected && !isDragging ? 'scale(1.02)' : 'none',
        cursor: 'grab',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: direction === 'vertical' ? 'row' : 'column',
        transition: isDragging ? 'none' : 'transform 0.2s, box-shadow 0.2s'
      }}
    >
      {/* 豎排模式 */}
      {direction === 'vertical' ? (
        <>
          {/* 主內容區域（右） */}
          <div 
            style={{
              writingMode: 'vertical-rl',
              textOrientation: 'mixed',
              height: '100%',
              overflowWrap: 'break-word',
              overflow: 'hidden',
              fontSize: `${fontSize}px`,
              lineHeight: '1.4',
              color: '#333',
              order: 3,
              marginLeft: '8px',
              flex: 1,
              minWidth: 0,
            }}
          >
            {fragment.showContent !== false && (
              <div style={{ 
                overflow: 'hidden', 
                textOverflow: 'ellipsis',
                wordBreak: 'break-all'
              }}>
                {content}
                {needContentExpand && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      setShowMoreContent(!showMoreContent)
                    }}
                    style={{
                      border: 'none',
                      background: 'none',
                      color: '#666',
                      fontSize: '12px',
                      cursor: 'pointer',
                      padding: '2px 0',
                      writingMode: 'vertical-rl'
                    }}
                  >
                    {showMoreContent ? '收起' : '...更多'}
                  </button>
                )}
              </div>
            )}
          </div>
          
          {/* 筆記內容（中） */}
          {showNotes && note && (
            <div 
              style={{ 
                writingMode: 'vertical-rl',
                textOrientation: 'mixed',
                fontSize: `${Math.max(12, fontSize - 2)}px`, 
                color: '#666',
                height: '100%',
                overflowWrap: 'break-word',
                overflow: 'hidden',
                order: 2,
                marginLeft: '8px',
                flex: 1,
                minWidth: 0,
              }}
            >
              <div style={{ 
                overflow: 'hidden', 
                textOverflow: 'ellipsis',
                wordBreak: 'break-all'
              }}>
                {fragment.notes[0]?.title && (
                  <div style={{
                    fontSize: '12px', 
                    fontWeight: 'bold', 
                    color: '#333', 
                    marginBottom: '4px'
                  }}>
                    {fragment.notes[0]?.title}
                  </div>
                )}
                {note}
                {needNoteExpand && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      setShowMoreNote(!showMoreNote)
                    }}
                    style={{
                      border: 'none',
                      background: 'none',
                      color: '#666',
                      fontSize: '11px',
                      cursor: 'pointer',
                      padding: '2px 0',
                      writingMode: 'vertical-rl'
                    }}
                  >
                    {showMoreNote ? '收起' : '...更多'}
                  </button>
                )}
              </div>
            </div>
          )}
          
          {/* 標籤區域（左） */}
          {fragment.showTags !== false && tags.length > 0 && (
            <div 
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '4px',
                height: '100%',
                order: 1,
                justifyContent: 'flex-start',
                overflow: 'hidden',
                minWidth: '24px',
              }}
            >
              {tags.map(tag => (
                <span
                  key={tag}
                  style={{
                    backgroundColor: '#f3e8c7',
                    color: '#8d6a38',
                    borderRadius: '12px',
                    padding: '6px 2px',
                    fontSize: '10px',
                    whiteSpace: 'nowrap',
                    display: 'inline-block',
                    writingMode: 'vertical-rl',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    maxHeight: '60px'
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
        </>
      ) : (
        // 橫排模式
        <>
          {/* 主內容區域 */}
          <div 
            style={{
              overflowWrap: 'break-word',
              overflow: 'hidden',
              fontSize: `${fontSize}px`,
              lineHeight: '1.4',
              color: '#333',
              flex: 1,
              minHeight: 0,
              display: 'flex',
              flexDirection: 'column'
            }}
          >
            {fragment.showContent !== false && (
              <div style={{ 
                overflow: 'hidden', 
                textOverflow: 'ellipsis',
                wordBreak: 'break-all',
                flex: '1 1 auto',
                minHeight: 0
              }}>
                {content}
                {needContentExpand && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      setShowMoreContent(!showMoreContent)
                    }}
                    style={{
                      border: 'none',
                      background: 'none',
                      color: '#666',
                      fontSize: '12px',
                      cursor: 'pointer',
                      padding: '2px 0',
                      display: 'block'
                    }}
                  >
                    {showMoreContent ? '收起' : '...更多'}
                  </button>
                )}
              </div>
            )}
            
            {/* 筆記區域 */}
            {showNotes && note && (
              <div style={{ 
                marginTop: '8px',
                fontSize: `${Math.max(12, fontSize - 2)}px`, 
                color: '#666',
                overflow: 'hidden',
                flex: '0 1 auto',
                minHeight: 0
              }}>
                {fragment.notes[0]?.title && (
                  <div style={{
                    fontSize: '11px', 
                    fontWeight: 'bold', 
                    color: '#333', 
                    marginBottom: '2px'
                  }}>
                    {fragment.notes[0]?.title}
                  </div>
                )}
                <div style={{ 
                  overflow: 'hidden', 
                  textOverflow: 'ellipsis',
                  wordBreak: 'break-all'
                }}>
                  {note}
                  {needNoteExpand && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        setShowMoreNote(!showMoreNote)
                      }}
                      style={{
                        border: 'none',
                        background: 'none',
                        color: '#666',
                        fontSize: '11px',
                        cursor: 'pointer',
                        padding: '2px 0',
                        display: 'block'
                      }}
                    >
                      {showMoreNote ? '收起' : '...更多'}
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
          
          {/* 標籤區域 */}
          {fragment.showTags !== false && tags.length > 0 && (
            <div 
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '4px',
                marginTop: '8px',
                justifyContent: 'flex-start',
                maxHeight: '48px',
                overflow: 'hidden',
                flex: '0 0 auto'
              }}
            >
              {tags.map(tag => (
                <span
                  key={tag}
                  style={{
                    backgroundColor: '#f3e8c7',
                    color: '#8d6a38',
                    borderRadius: '12px',
                    padding: '2px 6px',
                    fontSize: '10px',
                    whiteSpace: 'nowrap',
                    display: 'inline-block',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    maxWidth: '100px'
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
        </>
      )}
      
      {/* 展開碎片後才顯示日期 */}
      {isSelected && (
        <div 
          style={{
            position: 'absolute',
            bottom: '4px',
            right: '6px',
            fontSize: '9px',
            color: '#aaa',
            writingMode: direction === 'vertical' ? 'vertical-rl' : 'horizontal-tb',
          }}
        >
          {formatDate(fragment.createdAt)}
        </div>
      )}
    </div>
  )
})

FragmentCard.displayName = 'FragmentCard'

/**
 * 使用瀑布流排列的虛擬化碎片網格
 * 使用固定寬度、無限下拉的方式來優化大量碎片的瀏覽體驗
 */
export default function FragmentsGridView({ 
  fragments, 
  relevanceMap = {} 
}: { 
  fragments: Fragment[], 
  relevanceMap?: RelevanceMap 
}) {
  const { setSelectedFragment } = useFragmentsStore()
  const [selectedFragment, setSelectedFragmentState] = useState<Fragment | null>(null)
  const [positions, setPositions] = useState<Record<string, { row: number, col: number }>>({})
  const containerRef = useRef<HTMLDivElement>(null)
  
  // 使用 useMemo 創建方向映射，避免每次渲染重新計算
  const directionMap = useMemo(() => createDirectionMap(fragments), [fragments]);
  
  // 使用 useLayoutFragments 計算網格布局
  const { gridFragments, newPositions } = useLayoutFragments(
    fragments, 
    positions, 
    relevanceMap, 
    directionMap
  )
  
  // 使用 useDragFragment 處理拖曳功能
  const { draggingId, dragPosition, handleDragStart, isDragging } = useDragFragment(
    gridFragments,
    setPositions
  )

  // 處理碎片點擊
  const handleFragmentClick = useCallback((fragment: Fragment) => {
    if (draggingId) return // 拖曳時不觸發點擊
    
    setSelectedFragmentState(fragment)
    setSelectedFragment(fragment)
  }, [draggingId, setSelectedFragment]);

  // 關閉詳情彈窗
  const handleCloseDetail = useCallback(() => {
    setSelectedFragmentState(null)
  }, []);

  // 如果有新位置需要添加，更新位置記錄
  useEffect(() => {
    if (Object.keys(newPositions).length > Object.keys(positions).length) {
      let hasChanges = false;
      for (const id in newPositions) {
        if (!positions[id]) {
          hasChanges = true;
          break;
        }
      }
      
      if (hasChanges) {
        setTimeout(() => {
          setPositions(prev => ({...prev, ...newPositions}));
        }, 0);
      }
    }
  }, [newPositions, positions]);

  // 計算內容區域的高度和寬度
  const { contentWidth, contentHeight } = useMemo(() => {
    if (gridFragments.length === 0) {
      return { contentWidth: CONTAINER_WIDTH, contentHeight: window.innerHeight * 0.6 };
    }
    
    let maxWidth = 0;
    let maxHeight = 0;
    
    gridFragments.forEach(fragment => {
      // 計算這個碎片的邊界
      const fragmentRight = (fragment.position.col + fragment.size.width) * GRID_SIZE;
      const fragmentBottom = (fragment.position.row + fragment.size.height) * GRID_SIZE;
      
      maxWidth = Math.max(maxWidth, fragmentRight);
      maxHeight = Math.max(maxHeight, fragmentBottom);
    });
    
    // 確保內容區域高度至少為容器高度
    const minHeight = window.innerHeight * 0.6;
    return { 
      contentWidth: Math.max(CONTAINER_WIDTH, maxWidth + 100), // 添加一些邊距
      contentHeight: Math.max(minHeight, maxHeight + 200) // 添加更多底部空間
    };
  }, [gridFragments]);

  // 直接渲染所有碎片，不使用虛擬列表
  return (
    <div 
      ref={containerRef}
      className="fragments-grid-container relative" 
      style={{ 
        position: 'relative',
        background: '#f9f6e9',
        backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 0, 0, 0.05) 1px, transparent 1px)',
        backgroundSize: `${GRID_SIZE}px ${GRID_SIZE}px`,
        width: '100%',
        maxWidth: `${CONTAINER_WIDTH}px`,
        height: `${contentHeight}px`,
        padding: '10px',
        margin: '0 auto',
        overflowX: 'hidden',
        overflowY: 'auto'
      }}
    >
      {gridFragments.length === 0 ? (
        <div className="no-fragments-message" style={{
          padding: '40px 20px',
          textAlign: 'center',
          color: '#aaa',
          fontSize: '16px',
          backgroundColor: 'rgba(255, 255, 255, 0.5)',
          borderRadius: '8px',
          margin: '20px 0'
        }}>
          暫無碎片。請使用頂部的輸入框添加新碎片。
        </div>
      ) : (
        gridFragments.map(fragment => (
          <FragmentCard
            key={fragment.id}
            fragment={fragment}
            isSelected={selectedFragment?.id === fragment.id}
            isDragging={isDragging(fragment.id)}
            dragPosition={dragPosition}
            onFragmentClick={handleFragmentClick}
            onDragStart={handleDragStart}
          />
        ))
      )}
       
      {/* 詳情彈窗 */}
      <FragmentDetailModal 
        fragment={selectedFragment} 
        onClose={handleCloseDetail} 
      />
    </div>
  );
}