// src/features/fragments/layout/useLayoutFragments.ts
import { useMemo } from 'react'
import { Fragment } from '../types/fragment'
import { 
  FragmentSize, 
  GridPosition, 
  GridFragment,
  DirectionMap,
  RelevanceMap
} from '../types/gridTypes'
import { 
  GRID_SIZE, 
  GRID_GAP, 
  MAX_CONTENT_LENGTH, 
  MAX_NOTE_LENGTH 
} from '../constants'
import { truncateText, decideDirection } from '../utils'

// 卡片尺寸限制
const MIN_CARD_WIDTH = 5;   // 最小寬度（格子數）
const MAX_CARD_WIDTH = 15;  // 最大寬度（格子數）
const MIN_CARD_HEIGHT = 4;  // 最小高度（格子數）
const MAX_CARD_HEIGHT = 12; // 最大高度（格子數）

// 計算字體大小（根據重要性)
export function calculateFontSize(relevanceScore: number = 0): number {
  // 基本字型大小 14px，根據重要性增加
  return Math.floor(14 + relevanceScore * 6); // 最大增加 6px
}

// 計算根據文字內容的卡片尺寸
export function calculateFragmentSize(
  fragment: Fragment, 
  direction: 'horizontal' | 'vertical',
  fontSize: number
): FragmentSize {
  // 處理內容字數限制
  const content = truncateText(fragment.content, MAX_CONTENT_LENGTH);
  const contentLength = content.length;
  
  // 處理筆記內容
  const noteText = fragment.notes?.[0]?.value || '';
  const note = truncateText(noteText, MAX_NOTE_LENGTH);
  const noteLength = note.length;
  
  // 處理標籤數量
  const tagsLength = fragment.tags.length;
  
  // 根據字體大小計算所需空間 (字級越大占空間越多)
  const fontFactor = fontSize / 14;
  
  let cardWidth: number;
  let cardHeight: number;
  
  // 根據內容長度動態計算所需空間，但設置合理上下限
  if (direction === 'horizontal') {
    // 橫排：計算所需行數
    const charsPerLine = Math.max(10, Math.ceil(15 / fontFactor)); // 每行字數有下限，調整為更合理的值
    const contentLines = Math.ceil(contentLength / charsPerLine) || 1;
    const noteLines = noteLength ? Math.ceil(noteLength / charsPerLine) : 0;
    const tagLines = Math.min(2, Math.ceil(tagsLength / 4)); // 標籤最多顯示2行
    
    // 限制最大行數
    const maxContentLines = 8;
    const finalContentLines = Math.min(contentLines, maxContentLines);
    const finalNoteLines = Math.min(noteLines, Math.max(0, maxContentLines - finalContentLines));
    
    // 總高度（行數 * 行高）+ 內邊距
    const lineHeight = fontFactor * 1.4; // 稍微調整行高
    const contentHeight = finalContentLines * lineHeight;
    const noteHeight = finalNoteLines * lineHeight * 0.8;
    const tagHeight = tagLines * 1.5;
    const paddingHeight = 2.5;
    
    // 總寬度計算
    const avgCharsPerLine = Math.min(charsPerLine, 20);
    const charWidth = fontFactor * 0.6;
    const contentWidth = avgCharsPerLine * charWidth;
    const paddingWidth = 2;
    
    cardWidth = Math.round(contentWidth + paddingWidth);
    cardHeight = Math.round(contentHeight + noteHeight + tagHeight + paddingHeight);
  } else {
    // 豎排：計算所需列數
    const charsPerColumn = Math.max(10, Math.ceil(15 / fontFactor));
    const contentColumns = Math.ceil(contentLength / charsPerColumn) || 1;
    const noteColumns = noteLength ? Math.ceil(noteLength / charsPerColumn) : 0;
    const tagColumns = Math.min(tagsLength, 3); // 豎排標籤最多3列
    
    // 限制最大列數
    const maxColumns = 8;
    const finalContentColumns = Math.min(contentColumns, maxColumns);
    const finalNoteColumns = Math.min(noteColumns, Math.max(0, maxColumns - finalContentColumns));
    
    // 總寬度（列數 * 列寬）+ 內邊距
    const columnWidth = fontFactor * 1.6;
    const contentWidth = finalContentColumns * columnWidth;
    const noteWidth = finalNoteColumns * columnWidth * 0.8;
    const tagWidth = tagColumns > 0 ? tagColumns * 1.5 : 0;
    const paddingWidth = 2.5;
    
    // 總高度計算
    const avgCharsPerColumn = Math.min(charsPerColumn, 20);
    const charHeight = fontFactor * 1.1;
    const contentHeight = avgCharsPerColumn * charHeight;
    const paddingHeight = 2;
    
    cardWidth = Math.round(contentWidth + noteWidth + tagWidth + paddingWidth);
    cardHeight = Math.round(contentHeight + paddingHeight);
  }
  
  // 應用尺寸限制
  return {
    width: Math.max(MIN_CARD_WIDTH, Math.min(MAX_CARD_WIDTH, cardWidth)),
    height: Math.max(MIN_CARD_HEIGHT, Math.min(MAX_CARD_HEIGHT, cardHeight))
  };
}

// 計算網格是否被佔用
export function isGridOccupied(
  grid: boolean[][],
  position: GridPosition,
  size: FragmentSize
): boolean {
  // 檢查範圍是否超出網格
  if (
    position.row < 0 ||
    position.col < 0 ||
    position.row + size.height >= grid.length ||
    position.col + size.width >= grid[0].length
  ) {
    return true // 超出邊界視為佔用
  }

  // 檢查各個格子是否已被佔用
  for (let r = position.row; r < position.row + size.height; r++) {
    for (let c = position.col; c < position.col + size.width; c++) {
      if (grid[r][c]) {
        return true // 有任何一個格子被佔用，就視為整體被佔用
      }
    }
  }

  return false // 所有格子都未被佔用
}

// 標記網格為已佔用
export function markGridAsOccupied(
  grid: boolean[][],
  position: GridPosition,
  size: FragmentSize
): void {
  for (let r = position.row; r < position.row + size.height; r++) {
    for (let c = position.col; c < position.col + size.width; c++) {
      if (r >= 0 && c >= 0 && r < grid.length && c < grid[0].length) {
        grid[r][c] = true // 標記為已佔用
      }
    }
  }
}

// 尋找可放置碎片的位置（優化版）
export function findPlacementPosition(
  grid: boolean[][],
  size: FragmentSize
): GridPosition | null {
  const rows = grid.length;
  const cols = grid[0].length;

  // 增加間距，避免碎片太緊密
  const SPACING = 1; // 網格間距

  // 從左上角開始，逐行逐列尋找可放置的位置
  for (let r = 0; r < rows - size.height; r += SPACING + 1) {
    for (let c = 0; c < cols - size.width; c += SPACING + 1) {
      const position = { row: r, col: c };
      if (!isGridOccupied(grid, position, size)) {
        return position; // 找到第一個可放置的位置
      }
    }
  }

  // 如果沒找到，嘗試更密集的搜索
  for (let r = 0; r < rows - size.height; r++) {
    for (let c = 0; c < cols - size.width; c++) {
      const position = { row: r, col: c };
      if (!isGridOccupied(grid, position, size)) {
        return position; // 找到第一個可放置的位置
      }
    }
  }

  return null; // 找不到可放置的位置
}

// 將網格位置轉換為像素位置
export function gridToPixel(position: GridPosition): { top: number, left: number } {
  return {
    top: position.row * GRID_SIZE,
    left: position.col * GRID_SIZE
  }
}

// 將像素位置轉換為網格位置
export function pixelToGrid(top: number, left: number): GridPosition {
  return {
    row: Math.max(0, Math.round(top / GRID_SIZE)),
    col: Math.max(0, Math.round(left / GRID_SIZE))
  }
}

// 創建碎片方向映射的函數
export function createDirectionMap(fragments: Fragment[]): DirectionMap {
  const map: DirectionMap = {};
  
  fragments.forEach(frag => {
    if (frag.direction) {
      map[frag.id] = frag.direction;
    } else {
      map[frag.id] = decideDirection(
        frag.content, 
        frag.notes?.[0]?.value,
        true // UI顯示時使用隨機性
      );
    }
  });
  
  return map;
}

// 主要布局函數
export function useLayoutFragments(
  fragments: Fragment[],
  positions: Record<string, GridPosition>,
  relevanceMap: RelevanceMap = {},
  directionMap: DirectionMap = {}
): {
  gridFragments: GridFragment[],
  newPositions: Record<string, GridPosition>
} {
  return useMemo(() => {
    // 創建網格（預設大小200x200，增加空間避免重疊）
    const rows = 200
    const cols = 200
    const grid: boolean[][] = Array(rows).fill(0).map(() => Array(cols).fill(false))
    
    // 為每個碎片計算方向和大小
    const fragsWithProps = fragments.map(frag => {
      const direction = frag.direction || directionMap[frag.id] || 'horizontal'
      const relevance = relevanceMap[frag.id] || 0
      const fontSize = calculateFontSize(relevance)
      const size = calculateFragmentSize(frag, direction, fontSize)
    
      return {
        ...frag,
        direction,
        fontSize,
        size,
        showContent: frag.showContent !== false,  // 預設為 true
        showNote: frag.showNote !== false,        // 預設為 true
        showTags: frag.showTags !== false,        // 預設為 true
        position: positions[frag.id] || { row: 0, col: 0 }
      }
    })
    
    // 對碎片進行優先級排序（優先放置較大的碎片）
    const sortedFrags = [...fragsWithProps].sort((a, b) => {
      const aArea = a.size.width * a.size.height
      const bArea = b.size.width * b.size.height
      return bArea - aArea
    })
    
    // 為每個碎片尋找位置
    const placedFrags: GridFragment[] = []
    const newPositions: Record<string, GridPosition> = {}
    
    // 確保網格是乾淨的
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        grid[r][c] = false;
      }
    }
    
    for (const frag of sortedFrags) {
      let position: GridPosition | null = null;
      
      // 如果已有保存的位置，檢查是否可用
      if (positions[frag.id]) {
        const pos = positions[frag.id]
        // 檢查位置是否有效且未被佔用
        if (pos.row >= 0 && pos.col >= 0 && 
            pos.row + frag.size.height < rows && 
            pos.col + frag.size.width < cols && 
            !isGridOccupied(grid, pos, frag.size)) {
          position = pos;
        }
      }
      
      // 如果沒有有效的保存位置，尋找新位置
      if (!position) {
        position = findPlacementPosition(grid, frag.size);
      }
      
      if (position) {
        // 找到位置，標記為已佔用
        markGridAsOccupied(grid, position, frag.size)
        
        // 添加到已放置碎片列表
        placedFrags.push({
          ...frag,
          position
        })
        
        // 記錄新位置
        newPositions[frag.id] = position
      } else {
        // 如果找不到位置，嘗試在網格邊緣放置
        const edgePosition = { row: 0, col: 0 };
        placedFrags.push({
          ...frag,
          position: edgePosition
        });
        newPositions[frag.id] = edgePosition;
        console.warn(`無法為碎片 ${frag.id} 找到合適位置，已放置在邊緣`);
      }
    }
    
    return { gridFragments: placedFrags, newPositions }
  }, [fragments, positions, relevanceMap, directionMap])
}